package com.abt.traders.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.abt.traders.entity.LoanTransaction;
import com.fasterxml.jackson.annotation.JsonFormat;

public class LoanTransactionDTO {
    private Long id;
    private Long loanId;
    private String loanNumber;
    private String transactionType;
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate transactionDate;
    
    private BigDecimal amount;
    private BigDecimal interestAmount;
    private BigDecimal principalAmount;
    private BigDecimal remainingBalance;
    private Long purchaseId;
    private String paymentMethod;
    private String referenceNo;
    private String notes;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;
    
    public static LoanTransactionDTO fromEntity(LoanTransaction transaction) {
        if (transaction == null) return null;
        
        LoanTransactionDTO dto = new LoanTransactionDTO();
        dto.setId(transaction.getId());
        dto.setLoanId(transaction.getLoan() != null ? transaction.getLoan().getId() : null);
        dto.setLoanNumber(transaction.getLoan() != null ? transaction.getLoan().getLoanNumber() : null);
        dto.setTransactionType(transaction.getTransactionType() != null ? transaction.getTransactionType().name() : null);
        dto.setTransactionDate(transaction.getTransactionDate());
        dto.setAmount(transaction.getAmount());
        dto.setInterestAmount(transaction.getInterestAmount());
        dto.setPrincipalAmount(transaction.getPrincipalAmount());
        dto.setRemainingBalance(transaction.getRemainingBalance());
        dto.setPurchaseId(transaction.getPurchase() != null ? transaction.getPurchase().getId() : null);
        dto.setPaymentMethod(transaction.getPaymentMethod() != null ? transaction.getPaymentMethod().name() : null);
        dto.setReferenceNo(transaction.getReferenceNo());
        dto.setNotes(transaction.getNotes());
        dto.setCreatedAt(transaction.getCreatedAt());
        return dto;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getLoanId() {
		return loanId;
	}

	public void setLoanId(Long loanId) {
		this.loanId = loanId;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public LocalDate getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getInterestAmount() {
		return interestAmount;
	}

	public void setInterestAmount(BigDecimal interestAmount) {
		this.interestAmount = interestAmount;
	}

	public BigDecimal getPrincipalAmount() {
		return principalAmount;
	}

	public void setPrincipalAmount(BigDecimal principalAmount) {
		this.principalAmount = principalAmount;
	}

	public BigDecimal getRemainingBalance() {
		return remainingBalance;
	}

	public void setRemainingBalance(BigDecimal remainingBalance) {
		this.remainingBalance = remainingBalance;
	}

	public Long getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(Long purchaseId) {
		this.purchaseId = purchaseId;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
    
    
}