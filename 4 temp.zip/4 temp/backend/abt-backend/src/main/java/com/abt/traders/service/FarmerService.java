package com.abt.traders.service;

import com.abt.traders.entity.Farmer;
import com.abt.traders.repository.FarmerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.List;

@Service
@Transactional
public class FarmerService {
    
    @Autowired
    private FarmerRepository farmerRepository;
    
    public List<Farmer> getAllFarmers() {
        return farmerRepository.findAll();
    }
    
    public Farmer getFarmerById(Long id) {
        return farmerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Farmer not found with id: " + id));
    }
    
    public Farmer createFarmer(Farmer farmer) {
        if (farmer.getFarmerCode() == null || farmer.getFarmerCode().isEmpty()) {
            String farmerCode = generateFarmerCode();
            farmer.setFarmerCode(farmerCode);
        }
        
        // Initialize zero values if null
        if (farmer.getTotalCopraSold() == null) farmer.setTotalCopraSold(BigDecimal.ZERO);
        if (farmer.getTotalAmountPaid() == null) farmer.setTotalAmountPaid(BigDecimal.ZERO);
        if (farmer.getBalanceDue() == null) farmer.setBalanceDue(BigDecimal.ZERO);
        
        return farmerRepository.save(farmer);
    }
    
    public Farmer updateFarmer(Long id, Farmer farmerDetails) {
        Farmer farmer = getFarmerById(id);
        
        farmer.setName(farmerDetails.getName());
        farmer.setFatherName(farmerDetails.getFatherName());
        farmer.setMobile(farmerDetails.getMobile());
        farmer.setAddress(farmerDetails.getAddress());
        farmer.setDistrict(farmerDetails.getDistrict());
        farmer.setTaluk(farmerDetails.getTaluk());
        farmer.setHobli(farmerDetails.getHobli());
        farmer.setVillage(farmerDetails.getVillage());
        farmer.setBankName(farmerDetails.getBankName());
        farmer.setAccountNumber(farmerDetails.getAccountNumber());
        farmer.setIfscCode(farmerDetails.getIfscCode());
        farmer.setUpiId(farmerDetails.getUpiId());
        farmer.setPhoto(farmerDetails.getPhoto());
        
        return farmerRepository.save(farmer);
    }
    
    public void deleteFarmer(Long id) {
        Farmer farmer = getFarmerById(id);
        farmerRepository.delete(farmer);
    }
    
    public List<Farmer> getFarmersByVillage(String village) {
        return farmerRepository.findByVillage(village);
    }
    
    public List<Farmer> getFarmersWithBalance() {
        return farmerRepository.findByBalanceDueGreaterThan(BigDecimal.ZERO);
    }
    
    private String generateFarmerCode() {
        long count = farmerRepository.count();
        return "FR" + String.format("%03d", count + 1);
    }
    
    public Farmer updateFarmerBalance(Long farmerId, BigDecimal copraSold, BigDecimal amountPaid) {
        Farmer farmer = getFarmerById(farmerId);
        
        farmer.setTotalCopraSold(farmer.getTotalCopraSold().add(copraSold));
        farmer.setTotalAmountPaid(farmer.getTotalAmountPaid().add(amountPaid));
        farmer.setBalanceDue(farmer.getBalanceDue().subtract(amountPaid));
        
        return farmerRepository.save(farmer);
    }
}