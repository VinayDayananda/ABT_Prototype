package com.abt.traders.controller;

import com.abt.traders.dto.PurchaseDTO;
import com.abt.traders.entity.Purchase;
import com.abt.traders.service.PurchaseService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/purchases")
@CrossOrigin(origins = "*")
public class PurchaseController {
    
    private final PurchaseService purchaseService;
    
    public PurchaseController(PurchaseService purchaseService) {
        this.purchaseService = purchaseService;
    }
    
    @GetMapping
    public ResponseEntity<List<PurchaseDTO>> getAllPurchases() {
        return ResponseEntity.ok(purchaseService.getAllPurchases());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<PurchaseDTO> getPurchaseById(@PathVariable Long id) {
        return ResponseEntity.ok(purchaseService.getPurchaseById(id));
    }
    
    @PostMapping
    public ResponseEntity<PurchaseDTO> createPurchase(@RequestBody Purchase purchase) {
        return new ResponseEntity<>(purchaseService.createPurchase(purchase), HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<PurchaseDTO> updatePurchase(
            @PathVariable Long id,
            @RequestBody Purchase purchaseDetails) {
        return ResponseEntity.ok(purchaseService.updatePurchase(id, purchaseDetails));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePurchase(@PathVariable Long id) {
        purchaseService.deletePurchase(id);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/farmer/{farmerId}")
    public ResponseEntity<List<PurchaseDTO>> getPurchasesByFarmer(@PathVariable Long farmerId) {
        return ResponseEntity.ok(purchaseService.getPurchasesByFarmer(farmerId));
    }
    
    @GetMapping("/date-range")
    public ResponseEntity<List<PurchaseDTO>> getPurchasesByDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return ResponseEntity.ok(purchaseService.getPurchasesByDateRange(startDate, endDate));
    }
    
    @GetMapping("/total-copra")
    public ResponseEntity<BigDecimal> getTotalCopraPurchased(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return ResponseEntity.ok(purchaseService.getTotalCopraPurchased(startDate, endDate));
    }
}