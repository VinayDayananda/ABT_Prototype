package com.abt.traders.dto;

import com.abt.traders.entity.ProductType;
import com.abt.traders.entity.PurchaseItem;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PurchaseItemDTO {
    private Long id;
    private ProductType productType;
    private Integer numberOfBags;
    private BigDecimal weightPerBag;
    private BigDecimal extraQuantity;
    private BigDecimal qualityDeduction;
    private BigDecimal netWeight;
    private BigDecimal ratePerKg;
    private BigDecimal amount;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;
    
    // Constructors
    public PurchaseItemDTO() {}
    
    public PurchaseItemDTO(Long id, ProductType productType, Integer numberOfBags, 
                          BigDecimal weightPerBag, BigDecimal extraQuantity, 
                          BigDecimal qualityDeduction, BigDecimal netWeight, 
                          BigDecimal ratePerKg, BigDecimal amount, LocalDateTime createdAt) {
        this.id = id;
        this.productType = productType;
        this.numberOfBags = numberOfBags;
        this.weightPerBag = weightPerBag;
        this.extraQuantity = extraQuantity;
        this.qualityDeduction = qualityDeduction;
        this.netWeight = netWeight;
        this.ratePerKg = ratePerKg;
        this.amount = amount;
        this.createdAt = createdAt;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public ProductType getProductType() { return productType; }
    public void setProductType(ProductType productType) { this.productType = productType; }
    
    public Integer getNumberOfBags() { return numberOfBags; }
    public void setNumberOfBags(Integer numberOfBags) { this.numberOfBags = numberOfBags; }
    
    public BigDecimal getWeightPerBag() { return weightPerBag; }
    public void setWeightPerBag(BigDecimal weightPerBag) { this.weightPerBag = weightPerBag; }
    
    public BigDecimal getExtraQuantity() { return extraQuantity; }
    public void setExtraQuantity(BigDecimal extraQuantity) { this.extraQuantity = extraQuantity; }
    
    public BigDecimal getQualityDeduction() { return qualityDeduction; }
    public void setQualityDeduction(BigDecimal qualityDeduction) { this.qualityDeduction = qualityDeduction; }
    
    public BigDecimal getNetWeight() { return netWeight; }
    public void setNetWeight(BigDecimal netWeight) { this.netWeight = netWeight; }
    
    public BigDecimal getRatePerKg() { return ratePerKg; }
    public void setRatePerKg(BigDecimal ratePerKg) { this.ratePerKg = ratePerKg; }
    
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    // Convert from Entity
    public static PurchaseItemDTO fromEntity(PurchaseItem item) {
        if (item == null) return null;
        
        PurchaseItemDTO dto = new PurchaseItemDTO();
        dto.setId(item.getId());
        dto.setProductType(item.getProductType());
        dto.setNumberOfBags(item.getNumberOfBags());
        dto.setWeightPerBag(item.getWeightPerBag());
        dto.setExtraQuantity(item.getExtraQuantity());
        dto.setQualityDeduction(item.getQualityDeduction());
        dto.setNetWeight(item.getNetWeight());
        dto.setRatePerKg(item.getRatePerKg());
        dto.setAmount(item.getAmount());
        dto.setCreatedAt(item.getCreatedAt());
        
        return dto;
    }
}