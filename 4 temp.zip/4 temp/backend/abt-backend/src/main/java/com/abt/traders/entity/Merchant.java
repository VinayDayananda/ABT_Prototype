package com.abt.traders.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "merchants")
public class Merchant {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "merchant_code", unique = true, nullable = false)
    private String merchantCode;
    
    @Column(nullable = false)
    private String name;
    
    @Column(name = "company_name")
    private String companyName;
    
    private String mobile;
    
    @Column(columnDefinition = "TEXT")
    private String address;
    
    @Column(name = "total_purchased", precision = 10, scale = 2)
    private BigDecimal totalPurchased = BigDecimal.ZERO;
    
    @Column(name = "total_paid", precision = 12, scale = 2)
    private BigDecimal totalPaid = BigDecimal.ZERO;
    
    @Column(name = "balance_due", precision = 12, scale = 2)
    private BigDecimal balanceDue = BigDecimal.ZERO;
    
    @Column(name = "bank_name", length = 100)
    private String bankName;
    
    @Column(name = "account_number", length = 30)
    private String accountNumber;
    
    @Column(name = "ifsc_code", length = 20)
    private String ifscCode;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    // Constructors
    public Merchant() {}
    
    public Merchant(Long id, String merchantCode, String name, String companyName, 
                   String mobile, String address, BigDecimal totalPurchased, 
                   BigDecimal totalPaid, BigDecimal balanceDue, 
                   String bankName, String accountNumber, String ifscCode, 
                   String upiId, LocalDateTime createdAt) {
        this.id = id;
        this.merchantCode = merchantCode;
        this.name = name;
        this.companyName = companyName;
        this.mobile = mobile;
        this.address = address;
        this.totalPurchased = totalPurchased != null ? totalPurchased : BigDecimal.ZERO;
        this.totalPaid = totalPaid != null ? totalPaid : BigDecimal.ZERO;
        this.balanceDue = balanceDue != null ? balanceDue : BigDecimal.ZERO;
        this.bankName = bankName;
        this.accountNumber = accountNumber;
        this.ifscCode = ifscCode;
        this.createdAt = createdAt;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getMerchantCode() { return merchantCode; }
    public void setMerchantCode(String merchantCode) { this.merchantCode = merchantCode; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    
    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public BigDecimal getTotalPurchased() { return totalPurchased; }
    public void setTotalPurchased(BigDecimal totalPurchased) { 
        this.totalPurchased = totalPurchased != null ? totalPurchased : BigDecimal.ZERO;
    }
    
    public BigDecimal getTotalPaid() { return totalPaid; }
    public void setTotalPaid(BigDecimal totalPaid) { 
        this.totalPaid = totalPaid != null ? totalPaid : BigDecimal.ZERO;
    }
    
    public BigDecimal getBalanceDue() { return balanceDue; }
    public void setBalanceDue(BigDecimal balanceDue) { 
        this.balanceDue = balanceDue != null ? balanceDue : BigDecimal.ZERO;
    }
    
    public String getBankName() { return bankName; }
    public void setBankName(String bankName) { this.bankName = bankName; }
    
    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    
    public String getIfscCode() { return ifscCode; }
    public void setIfscCode(String ifscCode) { this.ifscCode = ifscCode; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
}