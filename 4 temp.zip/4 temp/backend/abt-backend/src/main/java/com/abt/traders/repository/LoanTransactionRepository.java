package com.abt.traders.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abt.traders.entity.LoanTransaction;

@Repository
public interface LoanTransactionRepository extends JpaRepository<LoanTransaction, Long> {
    
    // CORRECTED: Use underscore for relationship traversal
    List<LoanTransaction> findByLoan_Id(Long loanId);
    
    List<LoanTransaction> findByLoan_IdOrderByTransactionDateDesc(Long loanId);
    
    List<LoanTransaction> findByTransactionDateBetween(LocalDate startDate, LocalDate endDate);
    
    List<LoanTransaction> findByPurchase_Id(Long purchaseId);
}