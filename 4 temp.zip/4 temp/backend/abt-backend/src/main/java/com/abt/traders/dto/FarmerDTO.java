package com.abt.traders.dto;

import com.abt.traders.entity.Farmer;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class FarmerDTO {
    private Long id;
    private String farmerCode;
    private String name;
    private String fatherName;
    private String mobile;
    private String address;
    private String district;
    private String taluk;
    private String hobli;
    private String village;
    private String bankName;
    private String accountNumber;
    private String ifscCode;
    private String upiId;
    private String photo;
    private BigDecimal totalCopraSold;
    private BigDecimal totalAmountPaid;
    private BigDecimal balanceDue;
    private BigDecimal totalLoanBalance;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;
    
    // Constructors
    public FarmerDTO() {}
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getFarmerCode() { return farmerCode; }
    public void setFarmerCode(String farmerCode) { this.farmerCode = farmerCode; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getFatherName() { return fatherName; }
    public void setFatherName(String fatherName) { this.fatherName = fatherName; }
    
    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }
    
    public String getTaluk() { return taluk; }
    public void setTaluk(String taluk) { this.taluk = taluk; }
    
    public String getHobli() { return hobli; }
    public void setHobli(String hobli) { this.hobli = hobli; }
    
    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }
    
    public String getBankName() { return bankName; }
    public void setBankName(String bankName) { this.bankName = bankName; }
    
    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    
    public String getIfscCode() { return ifscCode; }
    public void setIfscCode(String ifscCode) { this.ifscCode = ifscCode; }
    
    public String getUpiId() { return upiId; }
    public void setUpiId(String upiId) { this.upiId = upiId; }
    
    public String getPhoto() { return photo; }
    public void setPhoto(String photo) { this.photo = photo; }
    
    public BigDecimal getTotalCopraSold() { return totalCopraSold; }
    public void setTotalCopraSold(BigDecimal totalCopraSold) { this.totalCopraSold = totalCopraSold; }
    
    public BigDecimal getTotalAmountPaid() { return totalAmountPaid; }
    public void setTotalAmountPaid(BigDecimal totalAmountPaid) { this.totalAmountPaid = totalAmountPaid; }
    
    public BigDecimal getBalanceDue() { return balanceDue; }
    public void setBalanceDue(BigDecimal balanceDue) { this.balanceDue = balanceDue; }
    
    public BigDecimal getTotalLoanBalance() { return totalLoanBalance; }
    public void setTotalLoanBalance(BigDecimal totalLoanBalance) { this.totalLoanBalance = totalLoanBalance; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    // Convert from Entity
    public static FarmerDTO fromEntity(Farmer farmer) {
        if (farmer == null) return null;
        
        FarmerDTO dto = new FarmerDTO();
        dto.setId(farmer.getId());
        dto.setFarmerCode(farmer.getFarmerCode());
        dto.setName(farmer.getName());
        dto.setFatherName(farmer.getFatherName());
        dto.setMobile(farmer.getMobile());
        dto.setAddress(farmer.getAddress());
        dto.setDistrict(farmer.getDistrict());
        dto.setTaluk(farmer.getTaluk());
        dto.setHobli(farmer.getHobli());
        dto.setVillage(farmer.getVillage());
        dto.setBankName(farmer.getBankName());
        dto.setAccountNumber(farmer.getAccountNumber());
        dto.setIfscCode(farmer.getIfscCode());
        dto.setUpiId(farmer.getUpiId());
        dto.setPhoto(farmer.getPhoto());
        dto.setTotalCopraSold(farmer.getTotalCopraSold());
        dto.setTotalAmountPaid(farmer.getTotalAmountPaid());
        dto.setBalanceDue(farmer.getBalanceDue());
        dto.setTotalLoanBalance(farmer.getTotalLoanBalance());
        dto.setCreatedAt(farmer.getCreatedAt());
        
        return dto;
    }
}