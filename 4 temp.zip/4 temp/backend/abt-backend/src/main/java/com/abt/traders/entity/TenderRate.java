package com.abt.traders.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "tender_rates", 
    uniqueConstraints = {
        @UniqueConstraint(columnNames = {"market", "rate_date"})
    }
)
public class TenderRate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Market market;
    
    @Column(name = "rate_date", nullable = false)
    private LocalDate rateDate;
    
    @Column(name = "rate_per_quintal", nullable = false)
    private Integer ratePerQuintal;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    // Constructors
    public TenderRate() {}
    
    public TenderRate(Long id, Market market, LocalDate rateDate, 
                     Integer ratePerQuintal, LocalDateTime createdAt) {
        this.id = id;
        this.market = market;
        this.rateDate = rateDate;
        this.ratePerQuintal = ratePerQuintal;
        this.createdAt = createdAt;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public Market getMarket() { return market; }
    public void setMarket(Market market) { this.market = market; }
    
    public LocalDate getRateDate() { return rateDate; }
    public void setRateDate(LocalDate rateDate) { this.rateDate = rateDate; }
    
    public Integer getRatePerQuintal() { return ratePerQuintal; }
    public void setRatePerQuintal(Integer ratePerQuintal) { this.ratePerQuintal = ratePerQuintal; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public enum Market {
        TIPTUR, ARSIKERE
    }
    
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
}