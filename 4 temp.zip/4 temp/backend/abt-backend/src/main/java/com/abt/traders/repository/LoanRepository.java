package com.abt.traders.repository;

import com.abt.traders.entity.Loan;
import com.abt.traders.entity.Loan.LoanStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface LoanRepository extends JpaRepository<Loan, Long> {
    Optional<Loan> findByLoanNumber(String loanNumber);
    
    // CORRECT: Using underscore for relationship
    List<Loan> findByFarmer_Id(Long farmerId);
    
    List<Loan> findByFarmer_IdAndStatus(Long farmerId, LoanStatus status);
    
    List<Loan> findByStatus(LoanStatus status);
    
    List<Loan> findByLoanDateBetween(LocalDate startDate, LocalDate endDate);
    
    @Query("SELECT SUM(l.remainingAmount) FROM Loan l WHERE l.farmer.id = :farmerId AND l.status = 'ACTIVE'")
    BigDecimal findTotalActiveLoanBalanceByFarmerId(@Param("farmerId") Long farmerId);
    
    @Query("SELECT SUM(l.remainingAmount) FROM Loan l WHERE l.status = 'ACTIVE'")
    BigDecimal findTotalActiveLoanBalance();
    
    @Query("SELECT COUNT(l) FROM Loan l WHERE l.status = 'ACTIVE' AND l.dueDate < :date")
    Long countOverdueLoans(@Param("date") LocalDate date);
}