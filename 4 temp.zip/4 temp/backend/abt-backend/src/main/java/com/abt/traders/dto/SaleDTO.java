package com.abt.traders.dto;

public class SaleDTO {
	 private Long id;
	 private String saleInfo;
	// private MerchantDTO merchant;
	 
	 
	 public Long getId() {
		 return id;
	 }
	 public void setId(Long id) {
		 this.id = id;
	 }
	 public String getSaleInfo() {
		 return saleInfo;
	 }
	 public void setSaleInfo(String saleInfo) {
		 this.saleInfo = saleInfo;
	 }
	 
	 
}
