package com.abt.traders.entity;

import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "loans")
@JsonIdentityInfo(
    generator = ObjectIdGenerators.PropertyGenerator.class,
    property = "id"
)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Loan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "loan_number", unique = true, nullable = false)
    private String loanNumber;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "farmer_id", nullable = false)
    @JsonBackReference("farmer-loans")
    private Farmer farmer;
    
    @Column(name = "loan_amount", nullable = false, precision = 12, scale = 2)
    private BigDecimal loanAmount;
    
    @Column(name = "interest_rate", precision = 5, scale = 2)
    private BigDecimal interestRate = new BigDecimal("2.0");
    
    @Column(name = "loan_date", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate loanDate;
    
    @Column(name = "due_date")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dueDate;
    
    @Enumerated(EnumType.STRING)
    private LoanStatus status = LoanStatus.ACTIVE;
    
    @Column(name = "remaining_amount", precision = 12, scale = 2)
    private BigDecimal remainingAmount;
    
    @Column(name = "total_interest", precision = 12, scale = 2)
    private BigDecimal totalInterest = BigDecimal.ZERO;
    
    private String purpose;
    
    @Column(columnDefinition = "TEXT")
    private String notes;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    @JsonIgnore
    private User createdBy;
    
    @Column(name = "created_at")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updatedAt;
    
    @OneToMany(mappedBy = "loan", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference("loan-transactions")
    private List<LoanTransaction> transactions = new ArrayList<>();
    
    // Constructors
    public Loan() {
        this.transactions = new ArrayList<>();
    }
    
    public Loan(Long id, String loanNumber, Farmer farmer, BigDecimal loanAmount, 
                BigDecimal interestRate, LocalDate loanDate, LocalDate dueDate, 
                LoanStatus status, BigDecimal remainingAmount, BigDecimal totalInterest, 
                String purpose, String notes, User createdBy, LocalDateTime createdAt, 
                LocalDateTime updatedAt) {
        this.id = id;
        this.loanNumber = loanNumber;
        this.farmer = farmer;
        this.loanAmount = loanAmount;
        this.interestRate = interestRate != null ? interestRate : new BigDecimal("2.0");
        this.loanDate = loanDate;
        this.dueDate = dueDate;
        this.status = status != null ? status : LoanStatus.ACTIVE;
        this.remainingAmount = remainingAmount;
        this.totalInterest = totalInterest != null ? totalInterest : BigDecimal.ZERO;
        this.purpose = purpose;
        this.notes = notes;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.transactions = new ArrayList<>();
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getLoanNumber() { return loanNumber; }
    public void setLoanNumber(String loanNumber) { this.loanNumber = loanNumber; }
    
    public Farmer getFarmer() { return farmer; }
    public void setFarmer(Farmer farmer) { this.farmer = farmer; }
    
    public BigDecimal getLoanAmount() { return loanAmount; }
    public void setLoanAmount(BigDecimal loanAmount) { this.loanAmount = loanAmount; }
    
    public BigDecimal getInterestRate() { return interestRate; }
    public void setInterestRate(BigDecimal interestRate) { 
        this.interestRate = interestRate != null ? interestRate : new BigDecimal("2.0");
    }
    
    public LocalDate getLoanDate() { return loanDate; }
    public void setLoanDate(LocalDate loanDate) { this.loanDate = loanDate; }
    
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    
    public LoanStatus getStatus() { return status; }
    public void setStatus(LoanStatus status) { this.status = status; }
    
    public BigDecimal getRemainingAmount() { return remainingAmount; }
    public void setRemainingAmount(BigDecimal remainingAmount) { this.remainingAmount = remainingAmount; }
    
    public BigDecimal getTotalInterest() { return totalInterest; }
    public void setTotalInterest(BigDecimal totalInterest) { 
        this.totalInterest = totalInterest != null ? totalInterest : BigDecimal.ZERO;
    }
    
    public String getPurpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }
    
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    
    public User getCreatedBy() { return createdBy; }
    public void setCreatedBy(User createdBy) { this.createdBy = createdBy; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    
    public List<LoanTransaction> getTransactions() { return transactions; }
    public void setTransactions(List<LoanTransaction> transactions) { 
        this.transactions = transactions != null ? transactions : new ArrayList<>();
    }
    
    public enum LoanStatus {
        ACTIVE, PAID, OVERDUE, DEFAULTED
    }
    
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (updatedAt == null) {
            updatedAt = LocalDateTime.now();
        }
        if (remainingAmount == null && loanAmount != null) {
            remainingAmount = loanAmount;
        }
        if (loanNumber == null || loanNumber.isEmpty()) {
            loanNumber = generateLoanNumber();
        }
        if (loanDate == null) {
            loanDate = LocalDate.now();
        }
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
    
    private String generateLoanNumber() {
        return "LN" + LocalDate.now().getYear() + String.format("%05d", (int)(Math.random() * 100000));
    }
    
    // Helper method to get farmer ID without exposing full farmer object
    @Transient
    @JsonProperty("farmerId")
    public Long getFarmerId() {
        return farmer != null ? farmer.getId() : null;
    }
    
    @Transient
    @JsonProperty("farmerName")
    public String getFarmerName() {
        return farmer != null ? farmer.getName() : null;
    }
    
    @Transient
    @JsonProperty("farmerCode")
    public String getFarmerCode() {
        return farmer != null ? farmer.getFarmerCode() : null;
    }
    
    // Calculate interest up to a specific date
    @Transient
    public BigDecimal getInterestUpToDate(LocalDate toDate) {
        if (this.remainingAmount == null || this.remainingAmount.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }
        
        if (this.loanDate == null || toDate == null) {
            return BigDecimal.ZERO;
        }
        
        // Ensure toDate is not before loanDate
        if (toDate.isBefore(this.loanDate)) {
            return BigDecimal.ZERO;
        }
        
        long days = ChronoUnit.DAYS.between(this.loanDate, toDate);
        if (days <= 0) {
            return BigDecimal.ZERO;
        }
        
        // Calculate interest: (Principal * Rate * Days) / (100 * 365)
        BigDecimal interest = this.remainingAmount
                .multiply(this.interestRate)
                .multiply(BigDecimal.valueOf(days))
                .divide(BigDecimal.valueOf(100 * 365L), 2, RoundingMode.HALF_UP);
        
        return interest;
    }
    
    // Helper method to check if loan is overdue
    @Transient
    public boolean isOverdue() {
        if (this.dueDate == null || this.status != LoanStatus.ACTIVE) {
            return false;
        }
        return LocalDate.now().isAfter(this.dueDate);
    }
    
    // Helper method to get total amount due (principal + interest)
    @Transient
    public BigDecimal getTotalAmountDue() {
        if (this.remainingAmount == null || this.remainingAmount.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }
        
        BigDecimal interest = getInterestUpToDate(LocalDate.now());
        return this.remainingAmount.add(interest);
    }
}