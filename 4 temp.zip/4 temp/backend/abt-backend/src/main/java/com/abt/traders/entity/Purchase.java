package com.abt.traders.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "purchases")
public class Purchase {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "purchase_id", unique = true, nullable = false)
    private String purchaseId;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "farmer_id", nullable = false)
    private Farmer farmer;
    
    @Column(name = "purchase_date", nullable = false)
    private LocalDate purchaseDate;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "payment_method")
    private PaymentMethod paymentMethod;
    
    @Column(name = "payment_reference")
    private String paymentReference;
    
    @Column(name = "amount_paid", precision = 12, scale = 2)
    private BigDecimal amountPaid = BigDecimal.ZERO;
    
    @Column(name = "balance_amount", precision = 12, scale = 2)
    private BigDecimal balanceAmount = BigDecimal.ZERO;
    
    @Column(columnDefinition = "TEXT")
    private String notes;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    // Loan and Commission fields
    @Column(name = "loan_deduction", precision = 12, scale = 2)
    private BigDecimal loanDeduction = BigDecimal.ZERO;
    
    @Column(name = "commission_rate", precision = 5, scale = 2)
    private BigDecimal commissionRate = new BigDecimal("2.00");
    
    @Column(name = "commission_amount", precision = 12, scale = 2)
    private BigDecimal commissionAmount = BigDecimal.ZERO;
    
    @Column(name = "net_payment", precision = 12, scale = 2)
    private BigDecimal netPayment = BigDecimal.ZERO;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "loan_id")
    private Loan loan;
    
    // One-to-Many relationship with PurchaseItems
    @OneToMany(mappedBy = "purchase", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<PurchaseItem> purchaseItems = new ArrayList<>();
    
    // Calculated totals
    @Column(name = "weight_kg", nullable = false)
    private BigDecimal totalWeightKg = BigDecimal.ZERO;
    
    @Column(name = "total_weight_quintal", precision = 10, scale = 2)
    private BigDecimal totalWeightQuintal = BigDecimal.ZERO;
    
    @Column(name = "total_amount", insertable = false, updatable = false)
    private BigDecimal totalAmount = BigDecimal.ZERO;
    
    // Loan payment type
    @Enumerated(EnumType.STRING)
    @Column(name = "loan_payment_type")
    private LoanPaymentType loanPaymentType;
    
    // Constructors
    public Purchase() {}
    
    // Updated constructor
    public Purchase(Long id, String purchaseId, Farmer farmer, LocalDate purchaseDate,
                   PaymentMethod paymentMethod, String paymentReference, BigDecimal amountPaid,
                   BigDecimal balanceAmount, String notes, LocalDateTime createdAt,
                   BigDecimal loanDeduction, BigDecimal commissionRate, BigDecimal commissionAmount,
                   BigDecimal netPayment, Loan loan, List<PurchaseItem> purchaseItems,
                   BigDecimal totalWeightKg, BigDecimal totalWeightQuintal, BigDecimal totalAmount,
                   LoanPaymentType loanPaymentType) {
        this.id = id;
        this.purchaseId = purchaseId;
        this.farmer = farmer;
        this.purchaseDate = purchaseDate;
        this.paymentMethod = paymentMethod;
        this.paymentReference = paymentReference;
        this.amountPaid = amountPaid != null ? amountPaid : BigDecimal.ZERO;
        this.balanceAmount = balanceAmount != null ? balanceAmount : BigDecimal.ZERO;
        this.notes = notes;
        this.createdAt = createdAt;
        this.loanDeduction = loanDeduction != null ? loanDeduction : BigDecimal.ZERO;
        this.commissionRate = commissionRate != null ? commissionRate : new BigDecimal("2.00");
        this.commissionAmount = commissionAmount != null ? commissionAmount : BigDecimal.ZERO;
        this.netPayment = netPayment != null ? netPayment : BigDecimal.ZERO;
        this.loan = loan;
        this.purchaseItems = purchaseItems != null ? purchaseItems : new ArrayList<>();
        this.totalWeightKg = totalWeightKg != null ? totalWeightKg : BigDecimal.ZERO;
        this.totalWeightQuintal = totalWeightQuintal != null ? totalWeightQuintal : BigDecimal.ZERO;
        this.totalAmount = totalAmount != null ? totalAmount : BigDecimal.ZERO;
        this.loanPaymentType = loanPaymentType;
    }
    
    // Enums
    public enum PaymentMethod {
        CASH, BANK_TRANSFER, UPI
    }
    
    public enum LoanPaymentType {
        NONE, FULL_PAYMENT, INTEREST_ONLY, PARTIAL_PAYMENT
    }
    
    // Getters and Setters (only new/changed ones shown)
    public List<PurchaseItem> getPurchaseItems() { return purchaseItems; }
    public void setPurchaseItems(List<PurchaseItem> purchaseItems) { 
        this.purchaseItems = purchaseItems != null ? purchaseItems : new ArrayList<>();
    }
    
    public BigDecimal getTotalWeightKg() { return totalWeightKg; }
    public void setTotalWeightKg(BigDecimal totalWeightKg) { 
        this.totalWeightKg = totalWeightKg != null ? totalWeightKg : BigDecimal.ZERO;
    }
    
    public BigDecimal getTotalWeightQuintal() { return totalWeightQuintal; }
    public void setTotalWeightQuintal(BigDecimal totalWeightQuintal) { 
        this.totalWeightQuintal = totalWeightQuintal != null ? totalWeightQuintal : BigDecimal.ZERO;
    }
    
    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { 
        this.totalAmount = totalAmount != null ? totalAmount : BigDecimal.ZERO;
    }
    
    public LoanPaymentType getLoanPaymentType() { return loanPaymentType; }
    public void setLoanPaymentType(LoanPaymentType loanPaymentType) { this.loanPaymentType = loanPaymentType; }
    
    public String getPaymentReference() { return paymentReference; }
    public void setPaymentReference(String paymentReference) { this.paymentReference = paymentReference; }
    
    public BigDecimal getAmountPaid() { return amountPaid; }
    public void setAmountPaid(BigDecimal amountPaid) { 
        this.amountPaid = amountPaid != null ? amountPaid : BigDecimal.ZERO;
    }
    
    public BigDecimal getBalanceAmount() { return balanceAmount; }
    public void setBalanceAmount(BigDecimal balanceAmount) { 
        this.balanceAmount = balanceAmount != null ? balanceAmount : BigDecimal.ZERO;
    }
    
    // Keep all existing getters and setters...
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getPurchaseId() { return purchaseId; }
    public void setPurchaseId(String purchaseId) { this.purchaseId = purchaseId; }
    
    public Farmer getFarmer() { return farmer; }
    public void setFarmer(Farmer farmer) { this.farmer = farmer; }
    
    public LocalDate getPurchaseDate() { return purchaseDate; }
    public void setPurchaseDate(LocalDate purchaseDate) { this.purchaseDate = purchaseDate; }
    
    public PaymentMethod getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(PaymentMethod paymentMethod) { this.paymentMethod = paymentMethod; }
    
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public BigDecimal getLoanDeduction() { return loanDeduction; }
    public void setLoanDeduction(BigDecimal loanDeduction) { 
        this.loanDeduction = loanDeduction != null ? loanDeduction : BigDecimal.ZERO;
    }
    
    public BigDecimal getCommissionRate() { return commissionRate; }
    public void setCommissionRate(BigDecimal commissionRate) { 
        this.commissionRate = commissionRate != null ? commissionRate : new BigDecimal("2.00");
    }
    
    public BigDecimal getCommissionAmount() { return commissionAmount; }
    public void setCommissionAmount(BigDecimal commissionAmount) { 
        this.commissionAmount = commissionAmount != null ? commissionAmount : BigDecimal.ZERO;
    }
    
    public BigDecimal getNetPayment() { return netPayment; }
    public void setNetPayment(BigDecimal netPayment) { 
        this.netPayment = netPayment != null ? netPayment : BigDecimal.ZERO;
    }
    
    public Loan getLoan() { return loan; }
    public void setLoan(Loan loan) { this.loan = loan; }
    
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        
        // Calculate totals
        calculateTotals();
    }
    
    @PreUpdate
    protected void onUpdate() {
        calculateTotals();
    }
    
 // Add this method to the Purchase entity class (around line 250-300)
    public void calculateTotals() {
        BigDecimal weightKg = BigDecimal.ZERO;
        BigDecimal amount = BigDecimal.ZERO;
        
        if (purchaseItems != null) {
            for (PurchaseItem item : purchaseItems) {
                if (item.getNetWeight() != null) {
                    weightKg = weightKg.add(item.getNetWeight());
                }
                if (item.getAmount() != null) {
                    amount = amount.add(item.getAmount());
                }
            }
        }
        
        this.totalWeightKg = weightKg;
        this.totalWeightQuintal = weightKg.divide(BigDecimal.valueOf(100), 2, BigDecimal.ROUND_HALF_UP);
        this.totalAmount = amount;
        
        // Calculate net payment
        BigDecimal afterLoan = this.totalAmount.subtract(this.loanDeduction);
        
        // Calculate commission if not set
        if (this.commissionAmount.compareTo(BigDecimal.ZERO) == 0 && 
            this.commissionRate != null && this.commissionRate.compareTo(BigDecimal.ZERO) > 0) {
            this.commissionAmount = afterLoan.multiply(this.commissionRate)
                .divide(BigDecimal.valueOf(100), 2, BigDecimal.ROUND_HALF_UP);
        }
        
        this.netPayment = afterLoan.subtract(this.commissionAmount);
        
        // Calculate balance
        if (this.amountPaid != null && this.netPayment != null) {
            this.balanceAmount = this.netPayment.subtract(this.amountPaid);
            if (this.balanceAmount.compareTo(BigDecimal.ZERO) < 0) {
                this.balanceAmount = BigDecimal.ZERO;
            }
        }
    }
    
}