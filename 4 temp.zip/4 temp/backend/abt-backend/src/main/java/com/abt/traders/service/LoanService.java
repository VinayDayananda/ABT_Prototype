package com.abt.traders.service;

import com.abt.traders.entity.*;
import com.abt.traders.repository.FarmerRepository;
import com.abt.traders.repository.LoanRepository;
import com.abt.traders.repository.LoanTransactionRepository;
import com.abt.traders.repository.PurchaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@Transactional
public class LoanService {
    
    @Autowired
    private LoanRepository loanRepository;
    
    @Autowired
    private LoanTransactionRepository loanTransactionRepository;
    
    @Autowired
    private FarmerRepository farmerRepository;
    
    @Autowired
    private PurchaseRepository purchaseRepository;
    
    public List<Loan> getAllLoans() {
        return loanRepository.findAll();
    }
    
    public Loan getLoanById(Long id) {
        return loanRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Loan not found with id: " + id));
    }
    
    public Loan getLoanByNumber(String loanNumber) {
        return loanRepository.findByLoanNumber(loanNumber)
                .orElseThrow(() -> new RuntimeException("Loan not found with number: " + loanNumber));
    }
    
    public Loan createLoan(Loan loan) {
        // Generate loan number if not provided
        if (loan.getLoanNumber() == null || loan.getLoanNumber().isEmpty()) {
            loan.setLoanNumber(generateLoanNumber());
        }
        
        // Set default dates
        if (loan.getLoanDate() == null) {
            loan.setLoanDate(LocalDate.now());
        }
        
        // Initialize remaining amount
        if (loan.getRemainingAmount() == null) {
            loan.setRemainingAmount(loan.getLoanAmount());
        }
        
        // Set status
        if (loan.getStatus() == null) {
            loan.setStatus(Loan.LoanStatus.ACTIVE);
        }
        
        // Save loan
        Loan savedLoan = loanRepository.save(loan);
        
        // Create initial disbursement transaction
        LoanTransaction disbursement = new LoanTransaction();
        disbursement.setLoan(savedLoan);
        disbursement.setTransactionType(LoanTransaction.TransactionType.LOAN_DISBURSEMENT);
        disbursement.setTransactionDate(savedLoan.getLoanDate());
        disbursement.setAmount(savedLoan.getLoanAmount());
        disbursement.setPrincipalAmount(savedLoan.getLoanAmount());
        disbursement.setRemainingBalance(savedLoan.getRemainingAmount());
        disbursement.setPaymentMethod(LoanTransaction.PaymentMethod.CASH);
        disbursement.setNotes("Initial loan disbursement");
        disbursement.setCreatedAt(LocalDateTime.now());
        loanTransactionRepository.save(disbursement);
        
        // Update farmer's total loan balance
        updateFarmerLoanBalance(savedLoan.getFarmer().getId());
        
        return savedLoan;
    }
    
    public Loan updateLoan(Long id, Loan loanDetails) {
        Loan loan = getLoanById(id);
        
        loan.setInterestRate(loanDetails.getInterestRate());
        loan.setDueDate(loanDetails.getDueDate());
        loan.setPurpose(loanDetails.getPurpose());
        loan.setNotes(loanDetails.getNotes());
        
        // Update status if changed
        if (loanDetails.getStatus() != null) {
            loan.setStatus(loanDetails.getStatus());
        }
        
        return loanRepository.save(loan);
    }
    
    public void deleteLoan(Long id) {
        Loan loan = getLoanById(id);
        Long farmerId = loan.getFarmer().getId();
        
        loanRepository.delete(loan);
        
        // Update farmer's loan balance after deleting
        updateFarmerLoanBalance(farmerId);
    }
    
    public List<Loan> getLoansByFarmer(Long farmerId) {
        return loanRepository.findByFarmer_Id(farmerId);
    }
    
    public List<Loan> getActiveLoansByFarmer(Long farmerId) {
        return loanRepository.findByFarmer_IdAndStatus(farmerId, Loan.LoanStatus.ACTIVE);
    }
    
    public List<Loan> getLoansByStatus(Loan.LoanStatus status) {
        return loanRepository.findByStatus(status);
    }
    
 // Add this method to LoanService class
    public BigDecimal calculateInterest(Loan loan, LocalDate toDate) {
        if (loan.getRemainingAmount() == null || loan.getRemainingAmount().compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }
        
        long days = ChronoUnit.DAYS.between(loan.getLoanDate(), toDate);
        if (days <= 0) {
            return BigDecimal.ZERO;
        }
        
        // Calculate interest: (Principal * Rate * Days) / (100 * 365)
        BigDecimal interest = loan.getRemainingAmount()
                .multiply(loan.getInterestRate())
                .multiply(BigDecimal.valueOf(days))
                .divide(BigDecimal.valueOf(100 * 365L), 2, RoundingMode.HALF_UP);
        
        return interest;
    }
    
    public Loan processCopraPayment(Long loanId, BigDecimal paymentAmount, Long purchaseId, String notes) {
        Loan loan = getLoanById(loanId);
        Purchase purchase = purchaseRepository.findById(purchaseId)
                .orElseThrow(() -> new RuntimeException("Purchase not found with id: " + purchaseId));
        
        // Calculate interest up to payment date
        LocalDate paymentDate = LocalDate.now();
        BigDecimal interest = calculateInterest(loan, paymentDate);
        BigDecimal principal = paymentAmount;
        
        // If payment is less than interest, apply to interest first
        if (paymentAmount.compareTo(interest) < 0) {
            interest = paymentAmount;
            principal = BigDecimal.ZERO;
        } else {
            principal = paymentAmount.subtract(interest);
        }
        
        // Update loan
        BigDecimal newRemainingAmount = loan.getRemainingAmount().subtract(principal);
        loan.setRemainingAmount(newRemainingAmount);
        
        // Update total interest
        loan.setTotalInterest(loan.getTotalInterest().add(interest));
        
        // Update status if fully paid
        if (newRemainingAmount.compareTo(BigDecimal.ZERO) <= 0) {
            loan.setStatus(Loan.LoanStatus.PAID);
            loan.setRemainingAmount(BigDecimal.ZERO);
        }
        
        Loan updatedLoan = loanRepository.save(loan);
        
        // Create transaction record
        LoanTransaction transaction = new LoanTransaction();
        transaction.setLoan(updatedLoan);
        transaction.setTransactionType(LoanTransaction.TransactionType.COPRA_PAYMENT);
        transaction.setTransactionDate(paymentDate);
        transaction.setAmount(paymentAmount);
        transaction.setInterestAmount(interest);
        transaction.setPrincipalAmount(principal);
        transaction.setRemainingBalance(newRemainingAmount.compareTo(BigDecimal.ZERO) < 0 ? 
                                       BigDecimal.ZERO : newRemainingAmount);
        transaction.setPurchase(purchase);
        transaction.setPaymentMethod(LoanTransaction.PaymentMethod.COPRA_DEDUCTION);
        transaction.setNotes(notes != null ? notes : "Payment via copra purchase");
        transaction.setCreatedAt(LocalDateTime.now());
        loanTransactionRepository.save(transaction);
        
        // Update farmer's loan balance
        updateFarmerLoanBalance(loan.getFarmer().getId());
        
        return updatedLoan;
    }
    
    public Loan processCashPayment(Long loanId, BigDecimal amount, LoanTransaction.PaymentMethod paymentMethod, 
                                   String referenceNo, String notes) {
        Loan loan = getLoanById(loanId);
        
        // Calculate interest up to payment date
        LocalDate paymentDate = LocalDate.now();
        BigDecimal interest = calculateInterest(loan, paymentDate);
        BigDecimal principal = amount;
        
        // If payment is less than interest, apply to interest first
        if (amount.compareTo(interest) < 0) {
            interest = amount;
            principal = BigDecimal.ZERO;
        } else {
            principal = amount.subtract(interest);
        }
        
        // Update loan
        BigDecimal newRemainingAmount = loan.getRemainingAmount().subtract(principal);
        loan.setRemainingAmount(newRemainingAmount);
        
        // Update total interest
        loan.setTotalInterest(loan.getTotalInterest().add(interest));
        
        // Update status if fully paid
        if (newRemainingAmount.compareTo(BigDecimal.ZERO) <= 0) {
            loan.setStatus(Loan.LoanStatus.PAID);
            loan.setRemainingAmount(BigDecimal.ZERO);
        }
        
        Loan updatedLoan = loanRepository.save(loan);
        
        // Create transaction record
        LoanTransaction transaction = new LoanTransaction();
        transaction.setLoan(updatedLoan);
        transaction.setTransactionType(LoanTransaction.TransactionType.CASH_PAYMENT);
        transaction.setTransactionDate(paymentDate);
        transaction.setAmount(amount);
        transaction.setInterestAmount(interest);
        transaction.setPrincipalAmount(principal);
        transaction.setRemainingBalance(newRemainingAmount.compareTo(BigDecimal.ZERO) < 0 ? 
                                       BigDecimal.ZERO : newRemainingAmount);
        transaction.setPaymentMethod(paymentMethod);
        transaction.setReferenceNo(referenceNo);
        transaction.setNotes(notes != null ? notes : "Cash payment");
        transaction.setCreatedAt(LocalDateTime.now());
        loanTransactionRepository.save(transaction);
        
        // Update farmer's loan balance
        updateFarmerLoanBalance(loan.getFarmer().getId());
        
        return updatedLoan;
    }
    
    public BigDecimal getFarmerActiveLoanBalance(Long farmerId) {
        BigDecimal balance = loanRepository.findTotalActiveLoanBalanceByFarmerId(farmerId);
        return balance != null ? balance : BigDecimal.ZERO;
    }
    
    public BigDecimal getTotalActiveLoanBalance() {
        BigDecimal balance = loanRepository.findTotalActiveLoanBalance();
        return balance != null ? balance : BigDecimal.ZERO;
    }
    
    public Long getOverdueLoanCount() {
        Long count = loanRepository.countOverdueLoans(LocalDate.now());
        return count != null ? count : 0L;
    }
    
    public List<LoanTransaction> getLoanTransactions(Long loanId) {
        return loanTransactionRepository.findByLoan_IdOrderByTransactionDateDesc(loanId);
    }
    
    private String generateLoanNumber() {
        long count = loanRepository.count();
        return "LN" + LocalDate.now().getYear() + String.format("%05d", count + 1);
    }
    
    private void updateFarmerLoanBalance(Long farmerId) {
        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> new RuntimeException("Farmer not found with id: " + farmerId));
        
        BigDecimal totalLoanBalance = loanRepository.findTotalActiveLoanBalanceByFarmerId(farmerId);
        if (totalLoanBalance == null) {
            totalLoanBalance = BigDecimal.ZERO;
        }
        
        farmer.setTotalLoanBalance(totalLoanBalance);
        farmerRepository.save(farmer);
    }
}