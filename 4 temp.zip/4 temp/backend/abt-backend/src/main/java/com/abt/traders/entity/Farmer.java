package com.abt.traders.entity;

import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "farmers")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@JsonIdentityInfo(
    generator = ObjectIdGenerators.PropertyGenerator.class,
    property = "id"
)
public class Farmer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "farmer_code", unique = true, nullable = false)
    private String farmerCode;
    
    @Column(nullable = false)
    private String name;
    
    @Column(name = "father_name")
    private String fatherName;
    
    private String mobile;
    
    @Column(columnDefinition = "TEXT")
    private String address;
    
    private String district;
    private String taluk;
    private String hobli;
    private String village;
    
    @Column(name = "bank_name")
    private String bankName;
    
    @Column(name = "account_number")
    private String accountNumber;
    
    @Column(name = "ifsc_code")
    private String ifscCode;
    
    @Column(name = "upi_id")
    private String upiId;
    
    private String photo;
    
    @Column(name = "total_copra_sold", precision = 10, scale = 2)
    private BigDecimal totalCopraSold = BigDecimal.ZERO;
    
    @Column(name = "total_amount_paid", precision = 12, scale = 2)
    private BigDecimal totalAmountPaid = BigDecimal.ZERO;
    
    @Column(name = "balance_due", precision = 12, scale = 2)
    private BigDecimal balanceDue = BigDecimal.ZERO;
    
    @Column(name = "created_at")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;
    
    @Column(name = "total_loan_balance", precision = 12, scale = 2)
    private BigDecimal totalLoanBalance = BigDecimal.ZERO;
    
    // Add loans relationship
    @OneToMany(mappedBy = "farmer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference("farmer-loans")
    private List<Loan> loans = new ArrayList<>();
    
    // Add purchases relationship
    @OneToMany(mappedBy = "farmer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private List<Purchase> purchases = new ArrayList<>();
    
    // Add payments relationship
    @OneToMany(mappedBy = "farmer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private List<Payment> payments = new ArrayList<>();
    
    // Constructors
    public Farmer() {
        this.loans = new ArrayList<>();
        this.purchases = new ArrayList<>();
        this.payments = new ArrayList<>();
    }
    
    public Farmer(Long id, String farmerCode, String name, String fatherName, String mobile, String address, 
                  String district, String taluk, String hobli, String village, String bankName, 
                  String accountNumber, String ifscCode, String upiId, String photo, 
                  BigDecimal totalCopraSold, BigDecimal totalAmountPaid, BigDecimal balanceDue, 
                  LocalDateTime createdAt, BigDecimal totalLoanBalance) {
        this.id = id;
        this.farmerCode = farmerCode;
        this.name = name;
        this.fatherName = fatherName;
        this.mobile = mobile;
        this.address = address;
        this.district = district;
        this.taluk = taluk;
        this.hobli = hobli;
        this.village = village;
        this.bankName = bankName;
        this.accountNumber = accountNumber;
        this.ifscCode = ifscCode;
        this.upiId = upiId;
        this.photo = photo;
        this.totalCopraSold = totalCopraSold != null ? totalCopraSold : BigDecimal.ZERO;
        this.totalAmountPaid = totalAmountPaid != null ? totalAmountPaid : BigDecimal.ZERO;
        this.balanceDue = balanceDue != null ? balanceDue : BigDecimal.ZERO;
        this.createdAt = createdAt;
        this.totalLoanBalance = totalLoanBalance != null ? totalLoanBalance : BigDecimal.ZERO;
        this.loans = new ArrayList<>();
        this.purchases = new ArrayList<>();
        this.payments = new ArrayList<>();
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getFarmerCode() { return farmerCode; }
    public void setFarmerCode(String farmerCode) { this.farmerCode = farmerCode; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getFatherName() { return fatherName; }
    public void setFatherName(String fatherName) { this.fatherName = fatherName; }
    
    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }
    
    public String getTaluk() { return taluk; }
    public void setTaluk(String taluk) { this.taluk = taluk; }
    
    public String getHobli() { return hobli; }
    public void setHobli(String hobli) { this.hobli = hobli; }
    
    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }
    
    public String getBankName() { return bankName; }
    public void setBankName(String bankName) { this.bankName = bankName; }
    
    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    
    public String getIfscCode() { return ifscCode; }
    public void setIfscCode(String ifscCode) { this.ifscCode = ifscCode; }
    
    public String getUpiId() { return upiId; }
    public void setUpiId(String upiId) { this.upiId = upiId; }
    
    public String getPhoto() { return photo; }
    public void setPhoto(String photo) { this.photo = photo; }
    
    public BigDecimal getTotalCopraSold() { return totalCopraSold; }
    public void setTotalCopraSold(BigDecimal totalCopraSold) { 
        this.totalCopraSold = totalCopraSold != null ? totalCopraSold : BigDecimal.ZERO; 
    }
    
    public BigDecimal getTotalAmountPaid() { return totalAmountPaid; }
    public void setTotalAmountPaid(BigDecimal totalAmountPaid) { 
        this.totalAmountPaid = totalAmountPaid != null ? totalAmountPaid : BigDecimal.ZERO; 
    }
    
    public BigDecimal getBalanceDue() { return balanceDue; }
    public void setBalanceDue(BigDecimal balanceDue) { 
        this.balanceDue = balanceDue != null ? balanceDue : BigDecimal.ZERO; 
    }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public BigDecimal getTotalLoanBalance() { return totalLoanBalance; }
    public void setTotalLoanBalance(BigDecimal totalLoanBalance) { 
        this.totalLoanBalance = totalLoanBalance != null ? totalLoanBalance : BigDecimal.ZERO;
    }
    
    public List<Loan> getLoans() { return loans; }
    public void setLoans(List<Loan> loans) { 
        this.loans = loans != null ? loans : new ArrayList<>();
    }
    
    public List<Purchase> getPurchases() { return purchases; }
    public void setPurchases(List<Purchase> purchases) { 
        this.purchases = purchases != null ? purchases : new ArrayList<>();
    }
    
    public List<Payment> getPayments() { return payments; }
    public void setPayments(List<Payment> payments) { 
        this.payments = payments != null ? payments : new ArrayList<>();
    }
    
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        
        // Initialize farmer code if not set
        if (farmerCode == null || farmerCode.isEmpty()) {
            farmerCode = generateFarmerCode();
        }
        
        // Initialize all BigDecimal fields to zero if null
        if (totalCopraSold == null) totalCopraSold = BigDecimal.ZERO;
        if (totalAmountPaid == null) totalAmountPaid = BigDecimal.ZERO;
        if (balanceDue == null) balanceDue = BigDecimal.ZERO;
        if (totalLoanBalance == null) totalLoanBalance = BigDecimal.ZERO;
    }
    
    private String generateFarmerCode() {
        return "FARM" + System.currentTimeMillis() % 10000;
    }
    
    // Helper methods for business logic
    @Transient
    public BigDecimal getTotalPurchasesAmount() {
        if (purchases == null || purchases.isEmpty()) {
            return BigDecimal.ZERO;
        }
        
        return purchases.stream()
                .map(Purchase::getTotalAmount)
                .filter(amount -> amount != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    @Transient
    public BigDecimal getTotalPaymentsAmount() {
        if (payments == null || payments.isEmpty()) {
            return BigDecimal.ZERO;
        }
        
        return payments.stream()
                .map(Payment::getAmount)
                .filter(amount -> amount != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    @Transient
    public boolean hasActiveLoans() {
        if (loans == null || loans.isEmpty()) {
            return false;
        }
        
        return loans.stream()
                .anyMatch(loan -> loan.getStatus() == Loan.LoanStatus.ACTIVE);
    }
    
    @Transient
    public List<Loan> getActiveLoans() {
        if (loans == null || loans.isEmpty()) {
            return new ArrayList<>();
        }
        
        return loans.stream()
                .filter(loan -> loan.getStatus() == Loan.LoanStatus.ACTIVE)
                .toList();
    }
    
    @Transient
    public BigDecimal getTotalActiveLoanAmount() {
        return getActiveLoans().stream()
                .map(Loan::getRemainingAmount)
                .filter(amount -> amount != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    // Update farmer statistics after purchase
    public void updateAfterPurchase(Purchase purchase) {
        if (purchase == null) return;
        
        // Update total copra sold
        BigDecimal copraWeight = purchase.getPurchaseItems().stream()
                .filter(item -> item.getProductType() == ProductType.COPRA)
                .map(item -> item.getNetWeight() != null ? item.getNetWeight() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        this.totalCopraSold = this.totalCopraSold.add(copraWeight);
        
        // Update balance (farmer is owed this amount)
        BigDecimal netPayment = purchase.getNetPayment() != null ? purchase.getNetPayment() : BigDecimal.ZERO;
        BigDecimal amountPaid = purchase.getAmountPaid() != null ? purchase.getAmountPaid() : BigDecimal.ZERO;
        BigDecimal balanceIncrease = netPayment.subtract(amountPaid);
        
        if (balanceIncrease.compareTo(BigDecimal.ZERO) > 0) {
            this.balanceDue = this.balanceDue.add(balanceIncrease);
        }
        
        this.totalAmountPaid = this.totalAmountPaid.add(amountPaid);
    }
    
    // Update farmer statistics after payment
    public void updateAfterPayment(Payment payment) {
        if (payment == null || payment.getAmount() == null) return;
        
        BigDecimal amount = payment.getAmount();
        this.totalAmountPaid = this.totalAmountPaid.add(amount);
        
        // Reduce balance due, but don't go below zero
        BigDecimal newBalance = this.balanceDue.subtract(amount);
        if (newBalance.compareTo(BigDecimal.ZERO) < 0) {
            newBalance = BigDecimal.ZERO;
        }
        this.balanceDue = newBalance;
    }
}