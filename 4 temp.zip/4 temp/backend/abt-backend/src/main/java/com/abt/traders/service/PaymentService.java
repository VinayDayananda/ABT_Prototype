package com.abt.traders.service;

import com.abt.traders.dto.PaymentDTO;
import com.abt.traders.entity.Farmer;
import com.abt.traders.entity.Payment;
import com.abt.traders.repository.FarmerRepository;
import com.abt.traders.repository.PaymentRepository;
import com.abt.traders.repository.PurchaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class PaymentService {
    
    @Autowired
    private PaymentRepository paymentRepository;
    
    @Autowired
    private FarmerRepository farmerRepository;
    
    @Autowired
    private PurchaseRepository purchaseRepository;
    
    @Autowired
    private FarmerService farmerService;
    
    public List<PaymentDTO> getAllPayments() {
        List<Payment> payments = paymentRepository.findAll();
        return payments.stream()
                .map(PaymentDTO::fromEntity)
                .collect(Collectors.toList());
    }
    
    public PaymentDTO getPaymentById(Long id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found with id: " + id));
        return PaymentDTO.fromEntity(payment);
    }
    
    public PaymentDTO createPayment(Payment payment) {
        // Set default date if not provided
        if (payment.getPaymentDate() == null) {
            payment.setPaymentDate(LocalDate.now());
        }
        
        // Load full farmer entity if only ID is provided
        if (payment.getFarmer() != null && payment.getFarmer().getId() != null) {
            Farmer farmer = farmerRepository.findById(payment.getFarmer().getId())
                    .orElseThrow(() -> new RuntimeException("Farmer not found with id: " + payment.getFarmer().getId()));
            payment.setFarmer(farmer);
        }
        
        Payment savedPayment = paymentRepository.save(payment);
        
        // Update farmer's balance if payment is linked to a farmer
        if (payment.getFarmer() != null && payment.getAmount() != null) {
            Farmer farmer = payment.getFarmer();
            BigDecimal amountPaid = payment.getAmount();
            
            // Update farmer's paid amount and reduce balance
            farmer.setTotalAmountPaid(farmer.getTotalAmountPaid().add(amountPaid));
            
            // Ensure balance doesn't go negative
            BigDecimal newBalance = farmer.getBalanceDue().subtract(amountPaid);
            if (newBalance.compareTo(BigDecimal.ZERO) < 0) {
                newBalance = BigDecimal.ZERO;
            }
            farmer.setBalanceDue(newBalance);
            
            farmerRepository.save(farmer);
        }
        
        return PaymentDTO.fromEntity(savedPayment);
    }
    
    public PaymentDTO updatePayment(Long id, Payment paymentDetails) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found with id: " + id));
        
        // Store old amount for farmer balance adjustment
        BigDecimal oldAmount = payment.getAmount();
        
        payment.setPaymentDate(paymentDetails.getPaymentDate());
        payment.setAmount(paymentDetails.getAmount());
        payment.setPaymentMethod(paymentDetails.getPaymentMethod());
        payment.setReferenceNo(paymentDetails.getReferenceNo());
        payment.setNotes(paymentDetails.getNotes());
        
        // Update purchase reference if changed
        if (paymentDetails.getPurchase() != null) {
            payment.setPurchase(paymentDetails.getPurchase());
        }
        
        Payment updatedPayment = paymentRepository.save(payment);
        
        // Update farmer balance if amount changed
        if (payment.getFarmer() != null && oldAmount != null && paymentDetails.getAmount() != null) {
            Farmer farmer = payment.getFarmer();
            BigDecimal amountDifference = paymentDetails.getAmount().subtract(oldAmount);
            
            if (amountDifference.compareTo(BigDecimal.ZERO) != 0) {
                farmer.setTotalAmountPaid(farmer.getTotalAmountPaid().add(amountDifference));
                
                BigDecimal newBalance = farmer.getBalanceDue().subtract(amountDifference);
                if (newBalance.compareTo(BigDecimal.ZERO) < 0) {
                    newBalance = BigDecimal.ZERO;
                }
                farmer.setBalanceDue(newBalance);
                
                farmerRepository.save(farmer);
            }
        }
        
        return PaymentDTO.fromEntity(updatedPayment);
    }
    
    public void deletePayment(Long id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found with id: " + id));
        
        // Reverse the farmer balance update if needed
        if (payment.getFarmer() != null && payment.getAmount() != null) {
            Farmer farmer = payment.getFarmer();
            BigDecimal amountPaid = payment.getAmount();
            
            farmer.setTotalAmountPaid(farmer.getTotalAmountPaid().subtract(amountPaid));
            farmer.setBalanceDue(farmer.getBalanceDue().add(amountPaid));
            farmerRepository.save(farmer);
        }
        
        paymentRepository.delete(payment);
    }
    
    public List<PaymentDTO> getPaymentsByFarmer(Long farmerId) {
        List<Payment> payments = paymentRepository.findByFarmer_Id(farmerId);
        return payments.stream()
                .map(PaymentDTO::fromEntity)
                .collect(Collectors.toList());
    }
    
    public List<PaymentDTO> getPaymentsByDateRange(LocalDate startDate, LocalDate endDate) {
        List<Payment> payments = paymentRepository.findByPaymentDateBetween(startDate, endDate);
        return payments.stream()
                .map(PaymentDTO::fromEntity)
                .collect(Collectors.toList());
    }
    
    public List<PaymentDTO> getPaymentsByPurchase(Long purchaseId) {
        List<Payment> payments = paymentRepository.findByPurchase_Id(purchaseId);
        return payments.stream()
                .map(PaymentDTO::fromEntity)
                .collect(Collectors.toList());
    }
    
    public BigDecimal getTotalPaymentsByFarmer(Long farmerId) {
        List<Payment> payments = paymentRepository.findByFarmer_Id(farmerId);
        return payments.stream()
                .map(Payment::getAmount)
                .filter(amount -> amount != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    // Helper method to create payment from DTO
    public Payment createPaymentFromDTO(PaymentDTO paymentDTO) {
        Payment payment = new Payment();
        
        if (paymentDTO.getFarmerId() != null) {
            Farmer farmer = farmerRepository.findById(paymentDTO.getFarmerId())
                    .orElseThrow(() -> new RuntimeException("Farmer not found with id: " + paymentDTO.getFarmerId()));
            payment.setFarmer(farmer);
        }
        
        payment.setPaymentDate(paymentDTO.getPaymentDate());
        payment.setAmount(paymentDTO.getAmount());
        
        if (paymentDTO.getPaymentMethod() != null) {
            payment.setPaymentMethod(Payment.PaymentMethod.valueOf(paymentDTO.getPaymentMethod()));
        }
        
        payment.setReferenceNo(paymentDTO.getReferenceNo());
        payment.setNotes(paymentDTO.getNotes());
        
        return payment;
    }
}