package com.abt.traders.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "purchase_items")
public class PurchaseItem {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "product_type", nullable = false)
    private ProductType productType;
    
    @Column(name = "number_of_bags")
    private Integer numberOfBags;
    
    @Column(name = "weight_per_bag", precision = 8, scale = 2)
    private BigDecimal weightPerBag;
    
    @Column(name = "extra_quantity", precision = 8, scale = 2)
    private BigDecimal extraQuantity = BigDecimal.ZERO;
    
    @Column(name = "quality_deduction", precision = 8, scale = 2)
    private BigDecimal qualityDeduction = BigDecimal.ZERO;
    
    @Column(name = "net_weight", precision = 8, scale = 2, nullable = false)
    private BigDecimal netWeight;
    
    @Column(name = "rate_per_kg", nullable = false)
    private BigDecimal ratePerKg;
    
    @Column(name = "amount", precision = 12, scale = 2, nullable = false)
    private BigDecimal amount;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "purchase_id", nullable = false)
    private Purchase purchase;
    
    @Column(name = "created_at")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;
    
    // Constructors
    public PurchaseItem() {}
    
    public PurchaseItem(ProductType productType, Integer numberOfBags, BigDecimal weightPerBag,
                       BigDecimal extraQuantity, BigDecimal qualityDeduction, BigDecimal netWeight,
                       BigDecimal ratePerKg, BigDecimal amount, Purchase purchase,LocalDateTime createdAt) {
        this.productType = productType;
        this.numberOfBags = numberOfBags;
        this.weightPerBag = weightPerBag;
        this.extraQuantity = extraQuantity != null ? extraQuantity : BigDecimal.ZERO;
        this.qualityDeduction = qualityDeduction != null ? qualityDeduction : BigDecimal.ZERO;
        this.netWeight = netWeight;
        this.ratePerKg = ratePerKg;
        this.amount = amount;
        this.purchase = purchase;
        this.createdAt = createdAt;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public ProductType getProductType() { return productType; }
    public void setProductType(ProductType productType) { this.productType = productType; }
    
    public Integer getNumberOfBags() { return numberOfBags; }
    public void setNumberOfBags(Integer numberOfBags) { this.numberOfBags = numberOfBags; }
    
    public BigDecimal getWeightPerBag() { return weightPerBag; }
    public void setWeightPerBag(BigDecimal weightPerBag) { this.weightPerBag = weightPerBag; }
    
    public BigDecimal getExtraQuantity() { return extraQuantity; }
    public void setExtraQuantity(BigDecimal extraQuantity) { 
        this.extraQuantity = extraQuantity != null ? extraQuantity : BigDecimal.ZERO;
    }
    
    public BigDecimal getQualityDeduction() { return qualityDeduction; }
    public void setQualityDeduction(BigDecimal qualityDeduction) { 
        this.qualityDeduction = qualityDeduction != null ? qualityDeduction : BigDecimal.ZERO;
    }
    
    public BigDecimal getNetWeight() { return netWeight; }
    public void setNetWeight(BigDecimal netWeight) { this.netWeight = netWeight; }
    
    public BigDecimal getRatePerKg() { return ratePerKg; }
    public void setRatePerKg(BigDecimal ratePerKg) { this.ratePerKg = ratePerKg; }
    
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    
    public Purchase getPurchase() { return purchase; }
    public void setPurchase(Purchase purchase) { this.purchase = purchase; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    // Add PrePersist method
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
}