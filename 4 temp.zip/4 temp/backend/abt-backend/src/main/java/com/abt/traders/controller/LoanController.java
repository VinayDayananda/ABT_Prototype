package com.abt.traders.controller;

import com.abt.traders.entity.Loan;
import com.abt.traders.entity.LoanTransaction;
import com.abt.traders.dto.LoanDTO;
import com.abt.traders.dto.LoanTransactionDTO;
import com.abt.traders.service.LoanService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/loans")
@CrossOrigin(origins = "*")
public class LoanController {
    
    private final LoanService loanService;
    
    public LoanController(LoanService loanService) {
        this.loanService = loanService;
    }
    
    @GetMapping
    public ResponseEntity<List<LoanDTO>> getAllLoans() {
        List<Loan> loans = loanService.getAllLoans();
        List<LoanDTO> loanDTOs = loans.stream()
            .map(LoanDTO::fromEntity)
            .collect(Collectors.toList());
        return ResponseEntity.ok(loanDTOs);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<LoanDTO> getLoanById(@PathVariable Long id) {
        Loan loan = loanService.getLoanById(id);
        return ResponseEntity.ok(LoanDTO.fromEntity(loan));
    }
    
    @GetMapping("/number/{loanNumber}")
    public ResponseEntity<LoanDTO> getLoanByNumber(@PathVariable String loanNumber) {
        Loan loan = loanService.getLoanByNumber(loanNumber);
        return ResponseEntity.ok(LoanDTO.fromEntity(loan));
    }
    
    @PostMapping
    public ResponseEntity<LoanDTO> createLoan(@RequestBody Loan loan) {
        Loan createdLoan = loanService.createLoan(loan);
        return new ResponseEntity<>(LoanDTO.fromEntity(createdLoan), HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<LoanDTO> updateLoan(@PathVariable Long id, @RequestBody Loan loanDetails) {
        Loan updatedLoan = loanService.updateLoan(id, loanDetails);
        return ResponseEntity.ok(LoanDTO.fromEntity(updatedLoan));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLoan(@PathVariable Long id) {
        loanService.deleteLoan(id);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/farmer/{farmerId}")
    public ResponseEntity<List<LoanDTO>> getLoansByFarmer(@PathVariable Long farmerId) {
        List<Loan> loans = loanService.getLoansByFarmer(farmerId);
        List<LoanDTO> loanDTOs = loans.stream()
            .map(LoanDTO::fromEntity)
            .collect(Collectors.toList());
        return ResponseEntity.ok(loanDTOs);
    }
    
    @GetMapping("/farmer/{farmerId}/active")
    public ResponseEntity<List<LoanDTO>> getActiveLoansByFarmer(@PathVariable Long farmerId) {
        List<Loan> loans = loanService.getActiveLoansByFarmer(farmerId);
        List<LoanDTO> loanDTOs = loans.stream()
            .map(LoanDTO::fromEntity)
            .collect(Collectors.toList());
        return ResponseEntity.ok(loanDTOs);
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<List<LoanDTO>> getLoansByStatus(@PathVariable Loan.LoanStatus status) {
        List<Loan> loans = loanService.getLoansByStatus(status);
        List<LoanDTO> loanDTOs = loans.stream()
            .map(LoanDTO::fromEntity)
            .collect(Collectors.toList());
        return ResponseEntity.ok(loanDTOs);
    }
    
    @PostMapping("/{loanId}/copra-payment")
    public ResponseEntity<LoanDTO> processCopraPayment(
            @PathVariable Long loanId,
            @RequestParam BigDecimal amount,
            @RequestParam Long purchaseId,
            @RequestParam(required = false) String notes) {
        Loan loan = loanService.processCopraPayment(loanId, amount, purchaseId, notes);
        return ResponseEntity.ok(LoanDTO.fromEntity(loan));
    }
    
    @PostMapping("/{loanId}/cash-payment")
    public ResponseEntity<LoanDTO> processCashPayment(
            @PathVariable Long loanId,
            @RequestParam BigDecimal amount,
            @RequestParam LoanTransaction.PaymentMethod paymentMethod,
            @RequestParam(required = false) String referenceNo,
            @RequestParam(required = false) String notes) {
        Loan loan = loanService.processCashPayment(loanId, amount, paymentMethod, referenceNo, notes);
        return ResponseEntity.ok(LoanDTO.fromEntity(loan));
    }
    
    @GetMapping("/farmer/{farmerId}/balance")
    public ResponseEntity<BigDecimal> getFarmerActiveLoanBalance(@PathVariable Long farmerId) {
        return ResponseEntity.ok(loanService.getFarmerActiveLoanBalance(farmerId));
    }
    
    @GetMapping("/total-active-balance")
    public ResponseEntity<BigDecimal> getTotalActiveLoanBalance() {
        return ResponseEntity.ok(loanService.getTotalActiveLoanBalance());
    }
    
    @GetMapping("/overdue-count")
    public ResponseEntity<Long> getOverdueLoanCount() {
        return ResponseEntity.ok(loanService.getOverdueLoanCount());
    }
    
    @GetMapping("/{loanId}/transactions")
    public ResponseEntity<List<LoanTransactionDTO>> getLoanTransactions(@PathVariable Long loanId) {
        List<LoanTransaction> transactions = loanService.getLoanTransactions(loanId);
        List<LoanTransactionDTO> transactionDTOs = transactions.stream()
            .map(LoanTransactionDTO::fromEntity)
            .collect(Collectors.toList());
        return ResponseEntity.ok(transactionDTOs);
    }
    
    @GetMapping("/{loanId}/calculate-interest")
    public ResponseEntity<BigDecimal> calculateInterest(
            @PathVariable Long loanId,
            @RequestParam LocalDate toDate) {
        Loan loan = loanService.getLoanById(loanId);
        return ResponseEntity.ok(loanService.calculateInterest(loan, toDate));
    }
}