package com.abt.traders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbtBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbtBackendApplication.class, args);
	}

}
