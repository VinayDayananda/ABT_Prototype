package com.abt.traders.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.abt.traders.entity.TenderRate;
import com.abt.traders.service.TenderRateService;

@RestController
@RequestMapping("/api/tender-rates")
@CrossOrigin(origins = "*")
public class TenderRateController {
    
    private final TenderRateService tenderRateService;
    
    public TenderRateController(TenderRateService tenderRateService) {
        this.tenderRateService = tenderRateService;
    }
    
    @GetMapping
    public ResponseEntity<List<TenderRate>> getAllTenderRates() {
        return ResponseEntity.ok(tenderRateService.getAllTenderRates());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<TenderRate> getTenderRateById(@PathVariable Long id) {
        return ResponseEntity.ok(tenderRateService.getTenderRateById(id));
    }
    
    @PostMapping
    public ResponseEntity<TenderRate> createTenderRate(@RequestBody TenderRate tenderRate) {
        return new ResponseEntity<>(tenderRateService.createTenderRate(tenderRate), HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<TenderRate> updateTenderRate(
            @PathVariable Long id,
            @RequestBody TenderRate tenderRateDetails) {
        return ResponseEntity.ok(tenderRateService.updateTenderRate(id, tenderRateDetails));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTenderRate(@PathVariable Long id) {
        tenderRateService.deleteTenderRate(id);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/market/{market}")
    public ResponseEntity<List<TenderRate>> getRatesByMarket(@PathVariable TenderRate.Market market) {
        return ResponseEntity.ok(tenderRateService.getRatesByMarket(market));
    }
    
    @GetMapping("/market/{market}/latest")
    public ResponseEntity<TenderRate> getLatestRateByMarket(@PathVariable TenderRate.Market market) {
        TenderRate latestRate = tenderRateService.getLatestRateByMarket(market);
        return latestRate != null ? 
                ResponseEntity.ok(latestRate) : 
                ResponseEntity.notFound().build();
    }
    
    @GetMapping("/date-range")
    public ResponseEntity<List<TenderRate>> getRatesByDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return ResponseEntity.ok(tenderRateService.getRatesByDateRange(startDate, endDate));
    }
}