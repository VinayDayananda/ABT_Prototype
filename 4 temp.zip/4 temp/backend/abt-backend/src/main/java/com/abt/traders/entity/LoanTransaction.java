package com.abt.traders.entity;

import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "loan_transactions")
@JsonIdentityInfo(
    generator = ObjectIdGenerators.PropertyGenerator.class,
    property = "id"
)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class LoanTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "loan_id", nullable = false)
    @JsonBackReference("loan-transactions")
    private Loan loan;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_type", nullable = false)
    private TransactionType transactionType;
    
    @Column(name = "transaction_date", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate transactionDate;
    
    @Column(precision = 12, scale = 2, nullable = false)
    private BigDecimal amount;
    
    @Column(name = "interest_amount", precision = 12, scale = 2)
    private BigDecimal interestAmount = BigDecimal.ZERO;
    
    @Column(name = "principal_amount", precision = 12, scale = 2)
    private BigDecimal principalAmount = BigDecimal.ZERO;
    
    @Column(name = "remaining_balance", precision = 12, scale = 2, nullable = false)
    private BigDecimal remainingBalance;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "purchase_id")
    @JsonIgnore
    private Purchase purchase;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "payment_method")
    private PaymentMethod paymentMethod;
    
    @Column(name = "reference_no")
    private String referenceNo;
    
    @Column(columnDefinition = "TEXT")
    private String notes;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    @JsonIgnore
    private User createdBy;
    
    @Column(name = "created_at")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;
    
    // Constructors
    public LoanTransaction() {}
    
    public LoanTransaction(Long id, Loan loan, TransactionType transactionType, 
                          LocalDate transactionDate, BigDecimal amount, 
                          BigDecimal interestAmount, BigDecimal principalAmount, 
                          BigDecimal remainingBalance, Purchase purchase, 
                          PaymentMethod paymentMethod, String referenceNo, 
                          String notes, User createdBy, LocalDateTime createdAt) {
        this.id = id;
        this.loan = loan;
        this.transactionType = transactionType;
        this.transactionDate = transactionDate;
        this.amount = amount;
        this.interestAmount = interestAmount != null ? interestAmount : BigDecimal.ZERO;
        this.principalAmount = principalAmount != null ? principalAmount : BigDecimal.ZERO;
        this.remainingBalance = remainingBalance;
        this.purchase = purchase;
        this.paymentMethod = paymentMethod;
        this.referenceNo = referenceNo;
        this.notes = notes;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public Loan getLoan() { return loan; }
    public void setLoan(Loan loan) { this.loan = loan; }
    
    public TransactionType getTransactionType() { return transactionType; }
    public void setTransactionType(TransactionType transactionType) { this.transactionType = transactionType; }
    
    public LocalDate getTransactionDate() { return transactionDate; }
    public void setTransactionDate(LocalDate transactionDate) { this.transactionDate = transactionDate; }
    
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    
    public BigDecimal getInterestAmount() { return interestAmount; }
    public void setInterestAmount(BigDecimal interestAmount) { 
        this.interestAmount = interestAmount != null ? interestAmount : BigDecimal.ZERO;
    }
    
    public BigDecimal getPrincipalAmount() { return principalAmount; }
    public void setPrincipalAmount(BigDecimal principalAmount) { 
        this.principalAmount = principalAmount != null ? principalAmount : BigDecimal.ZERO;
    }
    
    public BigDecimal getRemainingBalance() { return remainingBalance; }
    public void setRemainingBalance(BigDecimal remainingBalance) { this.remainingBalance = remainingBalance; }
    
    public Purchase getPurchase() { return purchase; }
    public void setPurchase(Purchase purchase) { this.purchase = purchase; }
    
    public PaymentMethod getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(PaymentMethod paymentMethod) { this.paymentMethod = paymentMethod; }
    
    public String getReferenceNo() { return referenceNo; }
    public void setReferenceNo(String referenceNo) { this.referenceNo = referenceNo; }
    
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    
    public User getCreatedBy() { return createdBy; }
    public void setCreatedBy(User createdBy) { this.createdBy = createdBy; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public enum TransactionType {
        LOAN_DISBURSEMENT, COPRA_PAYMENT, CASH_PAYMENT, INTEREST_CALCULATION, ADJUSTMENT
    }
    
    public enum PaymentMethod {
        CASH, BANK_TRANSFER, UPI, COPRA_DEDUCTION
    }
    
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (transactionDate == null) {
            transactionDate = LocalDate.now();
        }
    }
    
    // Helper method to get loan ID without exposing full loan object
    @Transient
    @JsonProperty("loanId")
    public Long getLoanId() {
        return loan != null ? loan.getId() : null;
    }
    
    @Transient
    @JsonProperty("loanNumber")
    public String getLoanNumber() {
        return loan != null ? loan.getLoanNumber() : null;
    }
    
    @Transient
    @JsonProperty("purchaseId")
    public Long getPurchaseId() {
        return purchase != null ? purchase.getId() : null;
    }
    
    @Transient
    @JsonProperty("farmerId")
    public Long getFarmerId() {
        return loan != null && loan.getFarmer() != null ? loan.getFarmer().getId() : null;
    }
    
    @Transient
    @JsonProperty("farmerName")
    public String getFarmerName() {
        return loan != null && loan.getFarmer() != null ? loan.getFarmer().getName() : null;
    }
}