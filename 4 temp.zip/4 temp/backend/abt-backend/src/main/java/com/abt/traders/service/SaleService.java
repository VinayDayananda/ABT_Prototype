package com.abt.traders.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.abt.traders.entity.Merchant;
import com.abt.traders.entity.Sale;
import com.abt.traders.repository.MerchantRepository;
import com.abt.traders.repository.SaleRepository;

@Service
@Transactional
public class SaleService {
    
    @Autowired
    private SaleRepository saleRepository;
    
    @Autowired
    private MerchantRepository merchantRepository;
    
    @Autowired
    private MerchantService merchantService;
    
    public List<Sale> getAllSales() {
        return saleRepository.findAll();
    }
    
    public Sale getSaleById(Long id) {
        return saleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sale not found with id: " + id));
    }
    
    public Sale createSale(Sale sale) {
        // Generate sale ID if not provided
        if (sale.getSaleId() == null || sale.getSaleId().isEmpty()) {
            String saleId = generateSaleId();
            sale.setSaleId(saleId);
        }
        
        // Set default date if not provided
        if (sale.getSaleDate() == null) {
            sale.setSaleDate(LocalDate.now());
        }
        
        // Calculate profit if not provided
        if (sale.getProfit() == null && sale.getWeightKg() != null && 
            sale.getRatePerQuintal() != null && sale.getPurchaseRateAvg() != null) {
            
            BigDecimal weightQuintal = sale.getWeightKg().divide(BigDecimal.valueOf(100));
            BigDecimal saleAmount = weightQuintal.multiply(BigDecimal.valueOf(sale.getRatePerQuintal()));
            BigDecimal purchaseCost = weightQuintal.multiply(BigDecimal.valueOf(sale.getPurchaseRateAvg()));
            sale.setProfit(saleAmount.subtract(purchaseCost));
        }
        
        // Save sale
        Sale savedSale = saleRepository.save(sale);
        
        // Update merchant's purchase total
        Merchant merchant = sale.getMerchant();
        if (merchant != null) {
            BigDecimal weight = sale.getWeightKg() != null ? sale.getWeightKg() : BigDecimal.ZERO;
            BigDecimal amountPaid = sale.getTotalAmount() != null ? sale.getTotalAmount() : BigDecimal.ZERO;
            
            merchantService.updateMerchantPurchase(
                merchant.getId(),
                weight,
                amountPaid
            );
        }
        
        return savedSale;
    }
    
    public Sale updateSale(Long id, Sale saleDetails) {
        Sale sale = getSaleById(id);
        
        sale.setSaleDate(saleDetails.getSaleDate());
        sale.setWeightKg(saleDetails.getWeightKg());
        sale.setRatePerQuintal(saleDetails.getRatePerQuintal());
        sale.setPurchaseRateAvg(saleDetails.getPurchaseRateAvg());
        sale.setPaymentMethod(saleDetails.getPaymentMethod());
        sale.setNotes(saleDetails.getNotes());
        
        // Recalculate derived fields
        if (sale.getWeightKg() != null && sale.getRatePerQuintal() != null) {
            BigDecimal weightQuintal = sale.getWeightKg().divide(BigDecimal.valueOf(100));
            sale.setTotalAmount(weightQuintal.multiply(BigDecimal.valueOf(sale.getRatePerQuintal())));
            
            if (sale.getPurchaseRateAvg() != null) {
                BigDecimal purchaseCost = weightQuintal.multiply(BigDecimal.valueOf(sale.getPurchaseRateAvg()));
                sale.setProfit(sale.getTotalAmount().subtract(purchaseCost));
            }
        }
        
        return saleRepository.save(sale);
    }
    
    public void deleteSale(Long id) {
        Sale sale = getSaleById(id);
        saleRepository.delete(sale);
    }
    
    public List<Sale> getSalesByMerchant(Long merchantId) {
        return saleRepository.findByMerchant_Id(merchantId);
    }
    
    public List<Sale> getSalesByDateRange(LocalDate startDate, LocalDate endDate) {
        return saleRepository.findBySaleDateBetween(startDate, endDate);
    }
    
    private String generateSaleId() {
        String prefix = "SAL" + LocalDate.now().getYear();
        long count = saleRepository.count();
        return prefix + String.format("%04d", count + 1);
    }
    
    public BigDecimal getTotalSalesAmount(LocalDate startDate, LocalDate endDate) {
        List<Sale> sales = getSalesByDateRange(startDate, endDate);
        return sales.stream()
                .map(Sale::getTotalAmount)
                .filter(amount -> amount != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    public BigDecimal getTotalProfit(LocalDate startDate, LocalDate endDate) {
        List<Sale> sales = getSalesByDateRange(startDate, endDate);
        return sales.stream()
                .map(Sale::getProfit)
                .filter(profit -> profit != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}