package com.abt.traders.dto;

public class LoginRequest {
    private String username;
    private String password;
}