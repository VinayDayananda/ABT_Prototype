package com.abt.traders.repository;

import com.abt.traders.entity.Purchase;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface PurchaseRepository extends JpaRepository<Purchase, Long> {
    Optional<Purchase> findByPurchaseId(String purchaseId);
    List<Purchase> findByFarmer_Id(Long farmerId);
    List<Purchase> findByPurchaseDateBetween(LocalDate startDate, LocalDate endDate);
    List<Purchase> findByFarmer_IdAndPurchaseDateBetween(Long farmerId, LocalDate startDate, LocalDate endDate);
}