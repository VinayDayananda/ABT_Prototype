package com.abt.traders.controller;

import com.abt.traders.dto.PaymentDTO;
import com.abt.traders.entity.Payment;
import com.abt.traders.service.PaymentService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "*")
public class PaymentController {
    
    private final PaymentService paymentService;
    
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }
    
    @GetMapping
    public ResponseEntity<List<PaymentDTO>> getAllPayments() {
        return ResponseEntity.ok(paymentService.getAllPayments());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<PaymentDTO> getPaymentById(@PathVariable Long id) {
        return ResponseEntity.ok(paymentService.getPaymentById(id));
    }
    
    @PostMapping
    public ResponseEntity<PaymentDTO> createPayment(@RequestBody Payment payment) {
        return new ResponseEntity<>(paymentService.createPayment(payment), HttpStatus.CREATED);
    }
    
    // Alternative endpoint that accepts DTO directly
    @PostMapping("/dto")
    public ResponseEntity<PaymentDTO> createPaymentFromDTO(@RequestBody PaymentDTO paymentDTO) {
        Payment payment = paymentService.createPaymentFromDTO(paymentDTO);
        return new ResponseEntity<>(paymentService.createPayment(payment), HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<PaymentDTO> updatePayment(
            @PathVariable Long id,
            @RequestBody Payment paymentDetails) {
        return ResponseEntity.ok(paymentService.updatePayment(id, paymentDetails));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePayment(@PathVariable Long id) {
        paymentService.deletePayment(id);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/farmer/{farmerId}")
    public ResponseEntity<List<PaymentDTO>> getPaymentsByFarmer(@PathVariable Long farmerId) {
        return ResponseEntity.ok(paymentService.getPaymentsByFarmer(farmerId));
    }
    
    @GetMapping("/purchase/{purchaseId}")
    public ResponseEntity<List<PaymentDTO>> getPaymentsByPurchase(@PathVariable Long purchaseId) {
        return ResponseEntity.ok(paymentService.getPaymentsByPurchase(purchaseId));
    }
    
    @GetMapping("/date-range")
    public ResponseEntity<List<PaymentDTO>> getPaymentsByDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return ResponseEntity.ok(paymentService.getPaymentsByDateRange(startDate, endDate));
    }
    
    @GetMapping("/farmer/{farmerId}/total")
    public ResponseEntity<BigDecimal> getTotalPaymentsByFarmer(@PathVariable Long farmerId) {
        return ResponseEntity.ok(paymentService.getTotalPaymentsByFarmer(farmerId));
    }
}