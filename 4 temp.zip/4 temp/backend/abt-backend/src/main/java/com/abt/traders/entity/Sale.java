package com.abt.traders.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "sales")
public class Sale {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "sale_id", unique = true, nullable = false)
    private String saleId;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "merchant_id", nullable = false)
    private Merchant merchant;
    
    @Column(name = "sale_date", nullable = false)
    private LocalDate saleDate;
    
    @Column(name = "weight_kg", precision = 8, scale = 2, nullable = false)
    private BigDecimal weightKg;
    
    @Column(name = "rate_per_quintal", nullable = false)
    private Integer ratePerQuintal;
    
    @Column(name = "total_amount", precision = 12, scale = 2)
    private BigDecimal totalAmount;
    
    @Column(name = "purchase_rate_avg", nullable = false)
    private Integer purchaseRateAvg;
    
    @Column(precision = 12, scale = 2)
    private BigDecimal profit;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "payment_method")
    private PaymentMethod paymentMethod;
    
    @Column(columnDefinition = "TEXT")
    private String notes;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    // Constructors
    public Sale() {}
    
    public Sale(Long id, String saleId, Merchant merchant, LocalDate saleDate, 
               BigDecimal weightKg, Integer ratePerQuintal, BigDecimal totalAmount, 
               Integer purchaseRateAvg, BigDecimal profit, PaymentMethod paymentMethod, 
               String notes, LocalDateTime createdAt) {
        this.id = id;
        this.saleId = saleId;
        this.merchant = merchant;
        this.saleDate = saleDate;
        this.weightKg = weightKg;
        this.ratePerQuintal = ratePerQuintal;
        this.totalAmount = totalAmount;
        this.purchaseRateAvg = purchaseRateAvg;
        this.profit = profit;
        this.paymentMethod = paymentMethod;
        this.notes = notes;
        this.createdAt = createdAt;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getSaleId() { return saleId; }
    public void setSaleId(String saleId) { this.saleId = saleId; }
    
    public Merchant getMerchant() { return merchant; }
    public void setMerchant(Merchant merchant) { this.merchant = merchant; }
    
    public LocalDate getSaleDate() { return saleDate; }
    public void setSaleDate(LocalDate saleDate) { this.saleDate = saleDate; }
    
    public BigDecimal getWeightKg() { return weightKg; }
    public void setWeightKg(BigDecimal weightKg) { this.weightKg = weightKg; }
    
    public Integer getRatePerQuintal() { return ratePerQuintal; }
    public void setRatePerQuintal(Integer ratePerQuintal) { this.ratePerQuintal = ratePerQuintal; }
    
    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }
    
    public Integer getPurchaseRateAvg() { return purchaseRateAvg; }
    public void setPurchaseRateAvg(Integer purchaseRateAvg) { this.purchaseRateAvg = purchaseRateAvg; }
    
    public BigDecimal getProfit() { return profit; }
    public void setProfit(BigDecimal profit) { this.profit = profit; }
    
    public PaymentMethod getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(PaymentMethod paymentMethod) { this.paymentMethod = paymentMethod; }
    
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public enum PaymentMethod {
        CASH, BANK_TRANSFER, UPI
    }
    
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        
        // Calculate total amount
        if (weightKg != null && ratePerQuintal != null) {
            BigDecimal weightQuintal = weightKg.divide(BigDecimal.valueOf(100));
            totalAmount = weightQuintal.multiply(BigDecimal.valueOf(ratePerQuintal));
        }
        
        // Calculate profit
        if (totalAmount != null && purchaseRateAvg != null && weightKg != null) {
            BigDecimal weightQuintal = weightKg.divide(BigDecimal.valueOf(100));
            BigDecimal purchaseCost = weightQuintal.multiply(BigDecimal.valueOf(purchaseRateAvg));
            profit = totalAmount.subtract(purchaseCost);
        }
    }
}