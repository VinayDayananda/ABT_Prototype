package com.abt.traders.service;

import com.abt.traders.entity.TenderRate;
import com.abt.traders.repository.TenderRateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;

@Service
@Transactional
public class TenderRateService {
    
    @Autowired
    private TenderRateRepository tenderRateRepository;
    
    public List<TenderRate> getAllTenderRates() {
        return tenderRateRepository.findAll();
    }
    
    public TenderRate getTenderRateById(Long id) {
        return tenderRateRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Tender rate not found with id: " + id));
    }
    
    public TenderRate createTenderRate(TenderRate tenderRate) {
        if (tenderRate.getRateDate() == null) {
            tenderRate.setRateDate(LocalDate.now());
        }
        return tenderRateRepository.save(tenderRate);
    }
    
    public TenderRate updateTenderRate(Long id, TenderRate tenderRateDetails) {
        TenderRate tenderRate = getTenderRateById(id);
        
        tenderRate.setMarket(tenderRateDetails.getMarket());
        tenderRate.setRateDate(tenderRateDetails.getRateDate());
        tenderRate.setRatePerQuintal(tenderRateDetails.getRatePerQuintal());
        
        return tenderRateRepository.save(tenderRate);
    }
    
    public void deleteTenderRate(Long id) {
        TenderRate tenderRate = getTenderRateById(id);
        tenderRateRepository.delete(tenderRate);
    }
    
    public List<TenderRate> getRatesByMarket(TenderRate.Market market) {
        return tenderRateRepository.findByMarketOrderByRateDateDesc(market);
    }
    
    public TenderRate getLatestRateByMarket(TenderRate.Market market) {
        List<TenderRate> rates = getRatesByMarket(market);
        return rates.isEmpty() ? null : rates.get(0);
    }
    
    public List<TenderRate> getRatesByDateRange(LocalDate startDate, LocalDate endDate) {
        return tenderRateRepository.findByRateDateBetween(startDate, endDate);
    }
}