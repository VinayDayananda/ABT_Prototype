package com.abt.traders.repository;

import com.abt.traders.entity.TenderRate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface TenderRateRepository extends JpaRepository<TenderRate, Long> {
    Optional<TenderRate> findByMarketAndRateDate(TenderRate.Market market, LocalDate rateDate);
    List<TenderRate> findByMarketOrderByRateDateDesc(TenderRate.Market market);
    List<TenderRate> findByRateDateBetween(LocalDate startDate, LocalDate endDate);
}