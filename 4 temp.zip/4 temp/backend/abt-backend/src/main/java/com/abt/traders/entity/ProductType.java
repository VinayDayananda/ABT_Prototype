package com.abt.traders.entity;

public enum ProductType {
    COPRA("Copra"),
    CHURU_HOLU("Churu/Holu"),
    COWTU("Cowtu");
    
    private final String displayName;
    
    ProductType(String displayName) {
        this.displayName = displayName;
    }
    
    public String getDisplayName() {
        return displayName;
    }
}