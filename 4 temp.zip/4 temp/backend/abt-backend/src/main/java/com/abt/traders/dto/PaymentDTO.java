package com.abt.traders.dto;

import com.abt.traders.entity.Payment;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class PaymentDTO {
    private Long id;
    private Long farmerId;
    private String farmerName;
    private Long purchaseId;
    private String purchaseNumber;
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate paymentDate;
    
    private BigDecimal amount;
    private String paymentMethod;
    private String referenceNo;
    private String notes;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;
    
    // Constructors
    public PaymentDTO() {}
    
    public PaymentDTO(Long id, Long farmerId, String farmerName, Long purchaseId, String purchaseNumber,
                     LocalDate paymentDate, BigDecimal amount, String paymentMethod, String referenceNo,
                     String notes, LocalDateTime createdAt) {
        this.id = id;
        this.farmerId = farmerId;
        this.farmerName = farmerName;
        this.purchaseId = purchaseId;
        this.purchaseNumber = purchaseNumber;
        this.paymentDate = paymentDate;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.referenceNo = referenceNo;
        this.notes = notes;
        this.createdAt = createdAt;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public Long getFarmerId() { return farmerId; }
    public void setFarmerId(Long farmerId) { this.farmerId = farmerId; }
    
    public String getFarmerName() { return farmerName; }
    public void setFarmerName(String farmerName) { this.farmerName = farmerName; }
    
    public Long getPurchaseId() { return purchaseId; }
    public void setPurchaseId(Long purchaseId) { this.purchaseId = purchaseId; }
    
    public String getPurchaseNumber() { return purchaseNumber; }
    public void setPurchaseNumber(String purchaseNumber) { this.purchaseNumber = purchaseNumber; }
    
    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }
    
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    
    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
    
    public String getReferenceNo() { return referenceNo; }
    public void setReferenceNo(String referenceNo) { this.referenceNo = referenceNo; }
    
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    // Convert from Entity
    public static PaymentDTO fromEntity(Payment payment) {
        if (payment == null) return null;
        
        PaymentDTO dto = new PaymentDTO();
        dto.setId(payment.getId());
        
        // Set farmer details
        if (payment.getFarmer() != null) {
            dto.setFarmerId(payment.getFarmer().getId());
            dto.setFarmerName(payment.getFarmer().getName());
        }
        
        // Set purchase details
        if (payment.getPurchase() != null) {
            dto.setPurchaseId(payment.getPurchase().getId());
            dto.setPurchaseNumber(payment.getPurchase().getPurchaseId());
        }
        
        dto.setPaymentDate(payment.getPaymentDate());
        dto.setAmount(payment.getAmount());
        dto.setPaymentMethod(payment.getPaymentMethod() != null ? payment.getPaymentMethod().name() : null);
        dto.setReferenceNo(payment.getReferenceNo());
        dto.setNotes(payment.getNotes());
        dto.setCreatedAt(payment.getCreatedAt());
        
        return dto;
    }
    
    // Convert to Entity (for creating/updating)
    public Payment toEntity() {
        Payment payment = new Payment();
        payment.setId(this.id);
        payment.setPaymentDate(this.paymentDate);
        payment.setAmount(this.amount);
        
        if (this.paymentMethod != null) {
            try {
                payment.setPaymentMethod(Payment.PaymentMethod.valueOf(this.paymentMethod));
            } catch (IllegalArgumentException e) {
                // Handle invalid payment method
                payment.setPaymentMethod(Payment.PaymentMethod.CASH);
            }
        }
        
        payment.setReferenceNo(this.referenceNo);
        payment.setNotes(this.notes);
        
        return payment;
    }
}