package com.abt.traders.service;

import com.abt.traders.dto.PurchaseDTO;
import com.abt.traders.entity.*;
import com.abt.traders.repository.FarmerRepository;
import com.abt.traders.repository.PurchaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class PurchaseService {
    
    @Autowired
    private PurchaseRepository purchaseRepository;
    
    @Autowired
    private FarmerRepository farmerRepository;
    
    @Autowired
    private LoanService loanService;
    
    @Autowired
    private FarmerService farmerService;
    
    // Get all purchases with DTO conversion
    public List<PurchaseDTO> getAllPurchases() {
        List<Purchase> purchases = purchaseRepository.findAll();
        return purchases.stream()
            .map(PurchaseDTO::fromEntity)
            .collect(Collectors.toList());
    }
    
    // Get purchase by ID with DTO
    public PurchaseDTO getPurchaseById(Long id) {
        Purchase purchase = purchaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Purchase not found with id: " + id));
        return PurchaseDTO.fromEntity(purchase);
    }
    
    // Create purchase with all new features
    public PurchaseDTO createPurchase(Purchase purchase) {
        // Generate purchase ID if not provided
        if (purchase.getPurchaseId() == null || purchase.getPurchaseId().isEmpty()) {
            purchase.setPurchaseId(generatePurchaseId());
        }
        
        // Set default date if not provided
        if (purchase.getPurchaseDate() == null) {
            purchase.setPurchaseDate(LocalDate.now());
        }
        
        // CRITICAL FIX: Set purchase reference in each purchase item
        if (purchase.getPurchaseItems() != null && !purchase.getPurchaseItems().isEmpty()) {
            for (PurchaseItem item : purchase.getPurchaseItems()) {
                // This is the most important line - set the bidirectional relationship
                item.setPurchase(purchase);
                
                // Calculate item details
                calculatePurchaseItem(item);
            }
        }
        
        // Handle loan deduction if loan is selected
        if (purchase.getLoan() != null && purchase.getLoan().getId() != null) {
            handleLoanDeduction(purchase);
        }
        
        // Save purchase (cascading will save purchase items)
        Purchase savedPurchase = purchaseRepository.save(purchase);
        
        // Update farmer's balance and copra sold
        updateFarmerAfterPurchase(savedPurchase);
        
        // Update loan if loan deduction was made
        if (savedPurchase.getLoan() != null && savedPurchase.getLoanDeduction().compareTo(BigDecimal.ZERO) > 0) {
            updateLoanAfterPurchase(savedPurchase);
        }
        
        return PurchaseDTO.fromEntity(savedPurchase);
    }
    
    // Calculate purchase item details
    private void calculatePurchaseItem(PurchaseItem item) {
        BigDecimal netWeight = BigDecimal.ZERO;
        
        // Calculate based on product type
        if (item.getProductType() == ProductType.COPRA) {
            // For copra: (bags * weight per bag) + extra - deduction
            if (item.getNumberOfBags() != null && item.getWeightPerBag() != null) {
                netWeight = BigDecimal.valueOf(item.getNumberOfBags())
                    .multiply(item.getWeightPerBag());
            }
        } else {
            // For churu/holu and cowtu: net weight is directly entered
            netWeight = item.getNetWeight() != null ? item.getNetWeight() : BigDecimal.ZERO;
        }
        
        // Add extra quantity and subtract quality deduction
        if (item.getExtraQuantity() != null) {
            netWeight = netWeight.add(item.getExtraQuantity());
        }
        
        if (item.getQualityDeduction() != null) {
            netWeight = netWeight.subtract(item.getQualityDeduction());
            if (netWeight.compareTo(BigDecimal.ZERO) < 0) {
                netWeight = BigDecimal.ZERO;
            }
        }
        
        item.setNetWeight(netWeight);
        
        // Calculate amount
        if (item.getRatePerKg() != null && netWeight.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal amount = netWeight.multiply(item.getRatePerKg());
            item.setAmount(amount);
        } else {
            item.setAmount(BigDecimal.ZERO);
        }
    }
    
    // Handle loan deduction logic
    private void handleLoanDeduction(Purchase purchase) {
        if (purchase.getLoan() == null || purchase.getLoan().getId() == null) {
            return;
        }
        
        Loan loan = loanService.getLoanById(purchase.getLoan().getId());
        BigDecimal totalAmount = purchase.getTotalAmount();
        
        if (totalAmount == null || totalAmount.compareTo(BigDecimal.ZERO) <= 0) {
            return;
        }
        
        BigDecimal loanDeduction = BigDecimal.ZERO;
        
        // Handle null loan payment type
        Purchase.LoanPaymentType paymentType = purchase.getLoanPaymentType();
        if (paymentType == null) {
            paymentType = Purchase.LoanPaymentType.NONE;
        }
        
        switch (paymentType) {
            case FULL_PAYMENT:
                // Calculate interest up to purchase date
                BigDecimal interest = loan.getInterestUpToDate(purchase.getPurchaseDate());
                BigDecimal totalLoanAmount = loan.getRemainingAmount().add(interest);
                
                // Deduct up to total amount
                if (totalLoanAmount.compareTo(totalAmount) <= 0) {
                    loanDeduction = totalLoanAmount;
                } else {
                    loanDeduction = totalAmount;
                }
                break;
                
            case INTEREST_ONLY:
                // Deduct only interest
                BigDecimal interestOnly = loan.getInterestUpToDate(purchase.getPurchaseDate());
                if (interestOnly.compareTo(totalAmount) <= 0) {
                    loanDeduction = interestOnly;
                } else {
                    loanDeduction = totalAmount;
                }
                break;
                
            case PARTIAL_PAYMENT:
                // Deduct specified amount
                BigDecimal requestedDeduction = purchase.getLoanDeduction();
                if (requestedDeduction == null) {
                    requestedDeduction = BigDecimal.ZERO;
                }
                
                if (requestedDeduction.compareTo(totalAmount) <= 0) {
                    loanDeduction = requestedDeduction;
                } else {
                    loanDeduction = totalAmount;
                }
                break;
                
            case NONE:
            default:
                loanDeduction = BigDecimal.ZERO;
                break;
        }
        
        purchase.setLoanDeduction(loanDeduction);
        
        // Calculate commission (2% of amount after loan deduction)
        BigDecimal amountAfterLoan = totalAmount.subtract(loanDeduction);
        
        // Handle null commission rate
        BigDecimal commissionRate = purchase.getCommissionRate();
        if (commissionRate == null) {
            commissionRate = new BigDecimal("2.00");
            purchase.setCommissionRate(commissionRate);
        }
        
        BigDecimal commission = amountAfterLoan.multiply(commissionRate)
            .divide(BigDecimal.valueOf(100), 2, BigDecimal.ROUND_HALF_UP);
        
        purchase.setCommissionAmount(commission);
    }
    
    // Update farmer after purchase
    private void updateFarmerAfterPurchase(Purchase purchase) {
        Farmer farmer = purchase.getFarmer();
        if (farmer == null) return;
        
        // Update total copra sold
        BigDecimal totalCopraWeight = purchase.getPurchaseItems().stream()
            .filter(item -> item.getProductType() == ProductType.COPRA)
            .map(PurchaseItem::getNetWeight)
            .filter(weight -> weight != null)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        farmer.setTotalCopraSold(farmer.getTotalCopraSold().add(totalCopraWeight));
        
        // Update balance (add to what farmer is owed)
        BigDecimal netPayment = purchase.getNetPayment();
        BigDecimal amountPaid = purchase.getAmountPaid();
        BigDecimal balanceIncrease = netPayment.subtract(amountPaid);
        
        farmer.setBalanceDue(farmer.getBalanceDue().add(balanceIncrease));
        farmer.setTotalAmountPaid(farmer.getTotalAmountPaid().add(amountPaid));
        
        farmerRepository.save(farmer);
    }
    
    // Update loan after purchase
    private void updateLoanAfterPurchase(Purchase purchase) {
        if (purchase.getLoanDeduction().compareTo(BigDecimal.ZERO) <= 0) {
            return;
        }
        
        // Create loan transaction for the deduction
        loanService.processCopraPayment(
            purchase.getLoan().getId(),
            purchase.getLoanDeduction(),
            purchase.getId(),
            "Deducted from copra purchase #" + purchase.getPurchaseId()
        );
    }
    
    // Update purchase
    public PurchaseDTO updatePurchase(Long id, Purchase purchaseDetails) {
        Purchase purchase = purchaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Purchase not found with id: " + id));
        
        // Update basic fields
        purchase.setPurchaseDate(purchaseDetails.getPurchaseDate());
        purchase.setPaymentMethod(purchaseDetails.getPaymentMethod());
        purchase.setPaymentReference(purchaseDetails.getPaymentReference());
        purchase.setAmountPaid(purchaseDetails.getAmountPaid());
        purchase.setNotes(purchaseDetails.getNotes());
        
        // Update loan details if changed
        if (purchaseDetails.getLoan() != null) {
            purchase.setLoan(purchaseDetails.getLoan());
            purchase.setLoanPaymentType(purchaseDetails.getLoanPaymentType());
            purchase.setLoanDeduction(purchaseDetails.getLoanDeduction());
        }
        
        // Update purchase items
        if (purchaseDetails.getPurchaseItems() != null) {
            // Remove existing items
            purchase.getPurchaseItems().clear();
            
            // Add new items
            for (PurchaseItem item : purchaseDetails.getPurchaseItems()) {
                item.setPurchase(purchase);
                calculatePurchaseItem(item);
                purchase.getPurchaseItems().add(item);
            }
        }
        
        // Recalculate totals
        purchase.calculateTotals();
        
        Purchase updatedPurchase = purchaseRepository.save(purchase);
        
        // Re-update farmer balance
        updateFarmerAfterPurchase(updatedPurchase);
        
        return PurchaseDTO.fromEntity(updatedPurchase);
    }
    
    // Delete purchase
    public void deletePurchase(Long id) {
        Purchase purchase = purchaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Purchase not found with id: " + id));
        
        // Reverse farmer balance update
        reverseFarmerUpdate(purchase);
        
        purchaseRepository.delete(purchase);
    }
    
    // Reverse farmer update when deleting purchase
    private void reverseFarmerUpdate(Purchase purchase) {
        Farmer farmer = purchase.getFarmer();
        if (farmer == null) return;
        
        // Reverse copra weight
        BigDecimal totalCopraWeight = purchase.getPurchaseItems().stream()
            .filter(item -> item.getProductType() == ProductType.COPRA)
            .map(PurchaseItem::getNetWeight)
            .filter(weight -> weight != null)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        farmer.setTotalCopraSold(farmer.getTotalCopraSold().subtract(totalCopraWeight));
        
        // Reverse balance update
        BigDecimal netPayment = purchase.getNetPayment();
        BigDecimal amountPaid = purchase.getAmountPaid();
        BigDecimal balanceDecrease = netPayment.subtract(amountPaid);
        
        farmer.setBalanceDue(farmer.getBalanceDue().subtract(balanceDecrease));
        farmer.setTotalAmountPaid(farmer.getTotalAmountPaid().subtract(amountPaid));
        
        farmerRepository.save(farmer);
    }
    
    // Other methods remain similar but with DTO conversion
    public List<PurchaseDTO> getPurchasesByFarmer(Long farmerId) {
        List<Purchase> purchases = purchaseRepository.findByFarmer_Id(farmerId);
        return purchases.stream()
            .map(PurchaseDTO::fromEntity)
            .collect(Collectors.toList());
    }
    
    public List<PurchaseDTO> getPurchasesByDateRange(LocalDate startDate, LocalDate endDate) {
        List<Purchase> purchases = purchaseRepository.findByPurchaseDateBetween(startDate, endDate);
        return purchases.stream()
            .map(PurchaseDTO::fromEntity)
            .collect(Collectors.toList());
    }
    
    private String generatePurchaseId() {
        String prefix = "PUR" + LocalDate.now().getYear();
        long count = purchaseRepository.count();
        return prefix + String.format("%04d", count + 1);
    }
    
    public BigDecimal getTotalCopraPurchased(LocalDate startDate, LocalDate endDate) {
        List<Purchase> purchases = getPurchasesByDateRange(startDate, endDate).stream()
            .map(dto -> purchaseRepository.findById(dto.getId()).orElse(null))
            .filter(p -> p != null)
            .collect(Collectors.toList());
            
        return purchases.stream()
            .flatMap(purchase -> purchase.getPurchaseItems().stream())
            .filter(item -> item.getProductType() == ProductType.COPRA)
            .map(PurchaseItem::getNetWeight)
            .filter(weight -> weight != null)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}