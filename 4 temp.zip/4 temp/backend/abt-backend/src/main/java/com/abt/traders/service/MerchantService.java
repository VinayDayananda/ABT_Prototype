package com.abt.traders.service;

import com.abt.traders.entity.Merchant;
import com.abt.traders.repository.MerchantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.List;

@Service
@Transactional
public class MerchantService {
    
    @Autowired
    private MerchantRepository merchantRepository;
    
    public List<Merchant> getAllMerchants() {
        return merchantRepository.findAll();
    }
    
    public Merchant getMerchantById(Long id) {
        return merchantRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Merchant not found with id: " + id));
    }
    
    public Merchant createMerchant(Merchant merchant) {
        if (merchant.getMerchantCode() == null || merchant.getMerchantCode().isEmpty()) {
            String merchantCode = generateMerchantCode();
            merchant.setMerchantCode(merchantCode);
        }
        
        // Initialize zero values if null
        if (merchant.getTotalPurchased() == null) merchant.setTotalPurchased(BigDecimal.ZERO);
        if (merchant.getTotalPaid() == null) merchant.setTotalPaid(BigDecimal.ZERO);
        if (merchant.getBalanceDue() == null) merchant.setBalanceDue(BigDecimal.ZERO);
        
        return merchantRepository.save(merchant);
    }
    
    public Merchant updateMerchant(Long id, Merchant merchantDetails) {
        Merchant merchant = getMerchantById(id);
        
        merchant.setName(merchantDetails.getName());
        merchant.setCompanyName(merchantDetails.getCompanyName());
        merchant.setMobile(merchantDetails.getMobile());
        merchant.setAddress(merchantDetails.getAddress());
        merchant.setBankName(merchantDetails.getBankName());
        merchant.setAccountNumber(merchantDetails.getAccountNumber());
        merchant.setIfscCode(merchantDetails.getIfscCode());
        
        return merchantRepository.save(merchant);
    }
    
    public void deleteMerchant(Long id) {
        Merchant merchant = getMerchantById(id);
        merchantRepository.delete(merchant);
    }
    
    private String generateMerchantCode() {
        long count = merchantRepository.count();
        return "MR" + String.format("%03d", count + 1);
    }
    
    public Merchant updateMerchantPurchase(Long merchantId, BigDecimal weight, BigDecimal amountPaid) {
        Merchant merchant = getMerchantById(merchantId);
        
        merchant.setTotalPurchased(merchant.getTotalPurchased().add(weight));
        merchant.setTotalPaid(merchant.getTotalPaid().add(amountPaid));
        merchant.setBalanceDue(merchant.getBalanceDue().add(weight.multiply(BigDecimal.valueOf(100))).subtract(amountPaid));
        
        return merchantRepository.save(merchant);
    }
    
    public Merchant getMerchantByCode(String merchantCode) {
        return merchantRepository.findByMerchantCode(merchantCode)
                .orElseThrow(() -> new RuntimeException("Merchant not found with code: " + merchantCode));
    }
}