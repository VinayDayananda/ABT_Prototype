package com.abt.traders.dto;

import com.abt.traders.entity.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PurchaseDTO {
    private Long id;
    private String purchaseId;
    private Long farmerId; // Change from Farmer to Long
    private String farmerName; // Add farmer name
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate purchaseDate;
    private Purchase.PaymentMethod paymentMethod;
    private String paymentReference;
    private BigDecimal amountPaid;
    private BigDecimal balanceAmount;
    private String notes;
    private BigDecimal loanDeduction;
    private BigDecimal commissionRate;
    private BigDecimal commissionAmount;
    private BigDecimal netPayment;
    private Long loanId; // Change from Loan to Long
    private String loanNumber; // Add loan number
    private List<PurchaseItemDTO> purchaseItems;
    private BigDecimal totalWeightKg;
    private BigDecimal totalWeightQuintal;
    private BigDecimal totalAmount;
    private Purchase.LoanPaymentType loanPaymentType;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;
    
    // Constructors
    public PurchaseDTO() {}
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getPurchaseId() { return purchaseId; }
    public void setPurchaseId(String purchaseId) { this.purchaseId = purchaseId; }
    
    public Long getFarmerId() { return farmerId; }
    public void setFarmerId(Long farmerId) { this.farmerId = farmerId; }
    
    public String getFarmerName() { return farmerName; }
    public void setFarmerName(String farmerName) { this.farmerName = farmerName; }
    
    public LocalDate getPurchaseDate() { return purchaseDate; }
    public void setPurchaseDate(LocalDate purchaseDate) { this.purchaseDate = purchaseDate; }
    
    public Purchase.PaymentMethod getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(Purchase.PaymentMethod paymentMethod) { this.paymentMethod = paymentMethod; }
    
    public String getPaymentReference() { return paymentReference; }
    public void setPaymentReference(String paymentReference) { this.paymentReference = paymentReference; }
    
    public BigDecimal getAmountPaid() { return amountPaid; }
    public void setAmountPaid(BigDecimal amountPaid) { this.amountPaid = amountPaid; }
    
    public BigDecimal getBalanceAmount() { return balanceAmount; }
    public void setBalanceAmount(BigDecimal balanceAmount) { this.balanceAmount = balanceAmount; }
    
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    
    public BigDecimal getLoanDeduction() { return loanDeduction; }
    public void setLoanDeduction(BigDecimal loanDeduction) { this.loanDeduction = loanDeduction; }
    
    public BigDecimal getCommissionRate() { return commissionRate; }
    public void setCommissionRate(BigDecimal commissionRate) { this.commissionRate = commissionRate; }
    
    public BigDecimal getCommissionAmount() { return commissionAmount; }
    public void setCommissionAmount(BigDecimal commissionAmount) { this.commissionAmount = commissionAmount; }
    
    public BigDecimal getNetPayment() { return netPayment; }
    public void setNetPayment(BigDecimal netPayment) { this.netPayment = netPayment; }
    
    public Long getLoanId() { return loanId; }
    public void setLoanId(Long loanId) { this.loanId = loanId; }
    
    public String getLoanNumber() { return loanNumber; }
    public void setLoanNumber(String loanNumber) { this.loanNumber = loanNumber; }
    
    public List<PurchaseItemDTO> getPurchaseItems() { return purchaseItems; }
    public void setPurchaseItems(List<PurchaseItemDTO> purchaseItems) { this.purchaseItems = purchaseItems; }
    
    public BigDecimal getTotalWeightKg() { return totalWeightKg; }
    public void setTotalWeightKg(BigDecimal totalWeightKg) { this.totalWeightKg = totalWeightKg; }
    
    public BigDecimal getTotalWeightQuintal() { return totalWeightQuintal; }
    public void setTotalWeightQuintal(BigDecimal totalWeightQuintal) { this.totalWeightQuintal = totalWeightQuintal; }
    
    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }
    
    public Purchase.LoanPaymentType getLoanPaymentType() { return loanPaymentType; }
    public void setLoanPaymentType(Purchase.LoanPaymentType loanPaymentType) { this.loanPaymentType = loanPaymentType; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    // Convert from Entity
    public static PurchaseDTO fromEntity(Purchase purchase) {
        if (purchase == null) return null;
        
        PurchaseDTO dto = new PurchaseDTO();
        dto.setId(purchase.getId());
        dto.setPurchaseId(purchase.getPurchaseId());
        
        // Set farmer details
        if (purchase.getFarmer() != null) {
            dto.setFarmerId(purchase.getFarmer().getId());
            dto.setFarmerName(purchase.getFarmer().getName());
        }
        
        dto.setPurchaseDate(purchase.getPurchaseDate());
        dto.setPaymentMethod(purchase.getPaymentMethod());
        dto.setPaymentReference(purchase.getPaymentReference());
        dto.setAmountPaid(purchase.getAmountPaid());
        dto.setBalanceAmount(purchase.getBalanceAmount());
        dto.setNotes(purchase.getNotes());
        dto.setLoanDeduction(purchase.getLoanDeduction());
        dto.setCommissionRate(purchase.getCommissionRate());
        dto.setCommissionAmount(purchase.getCommissionAmount());
        dto.setNetPayment(purchase.getNetPayment());
        
        // Set loan details
        if (purchase.getLoan() != null) {
            dto.setLoanId(purchase.getLoan().getId());
            dto.setLoanNumber(purchase.getLoan().getLoanNumber());
        }
        
        dto.setTotalWeightKg(purchase.getTotalWeightKg());
        dto.setTotalWeightQuintal(purchase.getTotalWeightQuintal());
        dto.setTotalAmount(purchase.getTotalAmount());
        dto.setLoanPaymentType(purchase.getLoanPaymentType());
        dto.setCreatedAt(purchase.getCreatedAt());
        
        // Convert purchase items
        if (purchase.getPurchaseItems() != null) {
            List<PurchaseItemDTO> itemDTOs = purchase.getPurchaseItems().stream()
                .map(PurchaseItemDTO::fromEntity)
                .collect(Collectors.toList());
            dto.setPurchaseItems(itemDTOs);
        }
        
        return dto;
    }
}