import React, { createContext, useContext, useState, useMemo } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider as MuiThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Login from './components/Login';
import Layout from './components/Layout/Layout';
import Dashboard from './components/Dashboard';
import Farmers from './components/Farmers';
import Purchase from './components/Purchase';
import PurchaseSummary from './components/PurchaseSummary';
import Transactions from './components/Transactions';
import Merchants from './components/Merchants';
import TenderRates from './components/TenderRates';
import Sales from './components/Sales';
import Reports from './components/Reports';
import Admin from './components/Admin';
import Help from './components/Help';
import { getThemeConfig, themes } from './themes';
import './App.css';
import Loans from './components/Loans';
import LoanDashboard from './components/LoanDashboard';
import LoanReports from './components/LoanReports';
import LoanStatement from './components/LoanStatement';

// Create Theme Context
const ThemeContext = createContext();

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    // Check if user is logged in from localStorage
    const storedLogin = localStorage.getItem('isLoggedIn');
    return storedLogin === 'true';
  });
  
  const [currentTheme, setCurrentTheme] = useState(() => {
    return localStorage.getItem('appTheme') || 'blue';
  });

  // Create theme using createTheme
  const theme = useMemo(() => {
    const themeConfig = getThemeConfig(currentTheme);
    return createTheme(themeConfig);
  }, [currentTheme]);

  const handleLogin = () => {
    // Store login state in localStorage
    localStorage.setItem('isLoggedIn', 'true');
    // Set a default user role for testing
    localStorage.setItem('userRole', 'owner');
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    // Clear all auth-related data
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userRole');
    localStorage.removeItem('token');
    setIsLoggedIn(false);
  };

  const handleThemeChange = (themeName) => {
    setCurrentTheme(themeName);
    localStorage.setItem('appTheme', themeName);
  };

  const themeContextValue = {
    currentTheme,
    handleThemeChange,
    themes,
  };

  return (
    <ThemeContext.Provider value={themeContextValue}>
      <MuiThemeProvider theme={theme}>
        <CssBaseline />
        <Router>
          <Routes>
            {/* Default route - redirect based on login status */}
            <Route 
              path="/" 
              element={
                isLoggedIn ? 
                  <Navigate to="/dashboard" replace /> : 
                  <Navigate to="/login" replace />
              } 
            />
            
            {/* Login route */}
            <Route 
              path="/login" 
              element={
                !isLoggedIn ? 
                  <Login onLogin={handleLogin} /> : 
                  <Navigate to="/dashboard" replace />
              } 
            />
            
            {/* Protected routes - wrapped with Layout */}
            <Route 
              path="/*" 
              element={
                isLoggedIn ? (
                  <Layout onLogout={handleLogout}>
                    <Routes>
                      {/* Main Dashboard */}
                      <Route path="/dashboard" element={<Dashboard />} />
                      
                      {/* Farmer Management */}
                      <Route path="/farmers" element={<Farmers />} />
                      
                      {/* Purchase Module */}
                      <Route path="/purchase" element={<Purchase />} />
                      <Route path="/purchase/new" element={<Purchase />} />
                      <Route path="/purchase/history" element={<PurchaseSummary />} />
                      
                      {/* Loan Management - Main Loan Page */}
                      <Route path="/loans" element={<Loans />} />
                      
                      {/* Loan Dashboard */}
                      <Route path="/loan-dashboard" element={<LoanDashboard />} />
                      
                      {/* Loan Reports */}
                      <Route path="/loan-reports" element={<LoanReports />} />
                      
                      {/* Loan Statement */}
                      <Route path="/loan-statement" element={<LoanStatement />} />
                      
                      {/* Transaction History */}
                      <Route path="/transactions" element={<Transactions />} />
                      
                      {/* Merchant Management */}
                      <Route path="/merchants" element={<Merchants />} />
                      
                      {/* Tender Rates */}
                      <Route path="/tender-rates" element={<TenderRates />} />
                      
                      {/* Sales (Copra Selling) */}
                      <Route path="/sales" element={<Sales />} />
                      
                      {/* Reports */}
                      <Route path="/reports" element={<Reports />} />
                      
                      {/* Admin Settings */}
                      <Route path="/admin" element={<Admin />} />
                      
                      {/* Help/Support */}
                      <Route path="/help" element={<Help />} />
                      
                      {/* Catch-all route for undefined paths */}
                      <Route path="*" element={<Navigate to="/dashboard" replace />} />
                    </Routes>
                  </Layout>
                ) : (
                  <Navigate to="/login" replace />
                )
              } 
            />
          </Routes>
        </Router>
      </MuiThemeProvider>
    </ThemeContext.Provider>
  );
}

export default App;