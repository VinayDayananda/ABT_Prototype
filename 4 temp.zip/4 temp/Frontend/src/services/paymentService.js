import api from './api';

export const paymentService = {
  getAllPayments: () => api.get('/payments'),
  getPaymentById: (id) => api.get(`/payments/${id}`),
  createPayment: (paymentData) => api.post('/payments', paymentData),
  updatePayment: (id, paymentData) => api.put(`/payments/${id}`, paymentData),
  deletePayment: (id) => api.delete(`/payments/${id}`),
  getPaymentsByFarmerId: (farmerId) => api.get(`/payments/farmer/${farmerId}`),
  getPaymentsByDateRange: (startDate, endDate) => api.get(`/payments/date-range?start=${startDate}&end=${endDate}`),
};