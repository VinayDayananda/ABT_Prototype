import api from './api';

export const merchantService = {
  getAllMerchants: () => api.get('/merchants'),
  getMerchantById: (id) => api.get(`/merchants/${id}`),
  createMerchant: (merchantData) => api.post('/merchants', merchantData),
  updateMerchant: (id, merchantData) => api.put(`/merchants/${id}`, merchantData),
  deleteMerchant: (id) => api.delete(`/merchants/${id}`),
};