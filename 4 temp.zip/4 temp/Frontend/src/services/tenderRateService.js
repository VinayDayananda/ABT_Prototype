import api from './api';

export const tenderRateService = {
  getAllTenderRates: () => api.get('/tender-rates'),
  getTenderRateById: (id) => api.get(`/tender-rates/${id}`),
  createTenderRate: (tenderRateData) => api.post('/tender-rates', tenderRateData),
  updateTenderRate: (id, tenderRateData) => api.put(`/tender-rates/${id}`, tenderRateData),
  deleteTenderRate: (id) => api.delete(`/tender-rates/${id}`),
  getLatestTenderRates: () => api.get('/tender-rates/latest'),
  getTenderRatesByMarket: (market) => api.get(`/tender-rates/market/${market}`),
};