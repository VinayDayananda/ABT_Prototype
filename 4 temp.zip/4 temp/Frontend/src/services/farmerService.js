import api from './api';

export const farmerService = {
  getAllFarmers: () => api.get('/farmers'),
  getFarmerById: (id) => api.get(`/farmers/${id}`),
  createFarmer: (farmerData) => api.post('/farmers', farmerData),
  updateFarmer: (id, farmerData) => api.put(`/farmers/${id}`, farmerData),
  deleteFarmer: (id) => api.delete(`/farmers/${id}`),
};