import api from './api';

export const userService = {
  login: (credentials) => api.post('/users/login', credentials),
  getAllUsers: () => api.get('/users'),
  createUser: (userData) => api.post('/users', userData),
};