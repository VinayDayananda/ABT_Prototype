import api from './api';

export const salesService = {
  getAllSales: () => api.get('/sales'),
  getSaleById: (id) => api.get(`/sales/${id}`),
  createSale: (saleData) => api.post('/sales', saleData),
  updateSale: (id, saleData) => api.put(`/sales/${id}`, saleData),
  deleteSale: (id) => api.delete(`/sales/${id}`),
  getSalesByMerchantId: (merchantId) => api.get(`/sales/merchant/${merchantId}`),
  getSalesByDateRange: (startDate, endDate) => api.get(`/sales/date-range?startDate=${startDate}&endDate=${endDate}`),
};