import api from './api';

export const purchaseService = {
  getAllPurchases: () => api.get('/purchases'),
  getPurchaseById: (id) => api.get(`/purchases/${id}`),
  createPurchase: (purchaseData) => api.post('/purchases', purchaseData),
  updatePurchase: (id, purchaseData) => api.put(`/purchases/${id}`, purchaseData),
  deletePurchase: (id) => api.delete(`/purchases/${id}`),
  getPurchasesByFarmer: (farmerId) => api.get(`/purchases/farmer/${farmerId}`),
  getPurchasesByDateRange: (startDate, endDate) => 
    api.get(`/purchases/date-range?startDate=${startDate}&endDate=${endDate}`),
  getTotalCopraPurchased: (startDate, endDate) =>
    api.get(`/purchases/total-copra?startDate=${startDate}&endDate=${endDate}`),
};