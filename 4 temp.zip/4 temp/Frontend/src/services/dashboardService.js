export const dashboardService = {
  getDashboardStats: () => Promise.resolve({ data: {} }),
  getRecentTransactions: () => Promise.resolve({ data: [] }),
  getCopraInflowData: () => Promise.resolve({ data: {} }),
  getPaymentStatusData: () => Promise.resolve({ data: {} }),
  getTopFarmers: () => Promise.resolve({ data: [] }),
};