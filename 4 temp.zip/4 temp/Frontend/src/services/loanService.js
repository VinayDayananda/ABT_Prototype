import api from './api';

export const loanService = {
  getAllLoans: () => api.get('/loans'),
  getLoanById: (id) => api.get(`/loans/${id}`),
  getLoanByNumber: (loanNumber) => api.get(`/loans/number/${loanNumber}`),
  createLoan: (loanData) => api.post('/loans', loanData),
  updateLoan: (id, loanData) => api.put(`/loans/${id}`, loanData),
  deleteLoan: (id) => api.delete(`/loans/${id}`),
  getLoansByFarmer: (farmerId) => api.get(`/loans/farmer/${farmerId}`),
  getActiveLoansByFarmer: (farmerId) => api.get(`/loans/farmer/${farmerId}/active`),
  getLoansByStatus: (status) => api.get(`/loans/status/${status}`),
  processCopraPayment: (loanId, amount, purchaseId, notes) => 
    api.post(`/loans/${loanId}/copra-payment`, null, {
      params: { amount, purchaseId, notes }
    }),
  processCashPayment: (loanId, amount, paymentMethod, referenceNo, notes) => 
    api.post(`/loans/${loanId}/cash-payment`, null, {
      params: { amount, paymentMethod, referenceNo, notes }
    }),
  getFarmerActiveLoanBalance: (farmerId) => api.get(`/loans/farmer/${farmerId}/balance`),
  getTotalActiveLoanBalance: () => api.get('/loans/total-active-balance'),
  getOverdueLoanCount: () => api.get('/loans/overdue-count'),
  getLoanTransactions: (loanId) => api.get(`/loans/${loanId}/transactions`),
  calculateInterest: (loanId, toDate) => 
    api.get(`/loans/${loanId}/calculate-interest`, {
      params: { toDate: toDate.toISOString().split('T')[0] }
    }),
};