import React, { useState, useEffect } from 'react';
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  CircularProgress,
  Alert,
  Chip,
  IconButton,
  Tooltip,
  Divider,
  LinearProgress
} from '@mui/material';
import {
  TrendingUp as TrendingIcon,
  TrendingDown as TrendingDownIcon,
  AccountBalance as LoanIcon,
  People as PeopleIcon,
  Schedule as ScheduleIcon,
  MoneyOff as MoneyOffIcon,
  AttachMoney as MoneyIcon,
  PieChart as PieChartIcon,
  BarChart as BarChartIcon,
  CalendarToday as CalendarIcon,
  FilterList as FilterIcon,
  Refresh as RefreshIcon,
  Download as DownloadIcon
} from '@mui/icons-material';
import { loanService } from '../services/loanService';
import { farmerService } from '../services/farmerService';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

const LoanDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [timeRange, setTimeRange] = useState('month');
  const [dashboardData, setDashboardData] = useState({
    summary: {},
    trendData: [],
    loanStatusData: [],
    farmerLoans: [],
    recentTransactions: [],
    performanceMetrics: {}
  });

  useEffect(() => {
    fetchDashboardData();
  }, [timeRange]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Fetch all loans and farmers
      const [loansRes, farmersRes] = await Promise.all([
        loanService.getAllLoans(),
        farmerService.getAllFarmers()
      ]);
      
      const loans = loansRes.data;
      const farmers = farmersRes.data;
      
      // Calculate summary statistics
      const summary = calculateSummary(loans, farmers);
      const trendData = calculateTrendData(loans, timeRange);
      const loanStatusData = calculateLoanStatusData(loans);
      const farmerLoans = calculateTopFarmerLoans(loans);
      const recentTransactions = getRecentTransactions(loans);
      const performanceMetrics = calculatePerformanceMetrics(loans);
      
      setDashboardData({
        summary,
        trendData,
        loanStatusData,
        farmerLoans,
        recentTransactions,
        performanceMetrics
      });
      
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      setError('Failed to load dashboard data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const calculateSummary = (loans, farmers) => {
    const activeLoans = loans.filter(l => l.status === 'ACTIVE');
    const totalActiveAmount = activeLoans.reduce((sum, loan) => 
      sum + parseFloat(loan.remainingAmount || 0), 0);
    
    const totalLoansAmount = loans.reduce((sum, loan) => 
      sum + parseFloat(loan.loanAmount || 0), 0);
    
    const farmersWithLoans = [...new Set(loans.map(l => l.farmer?.id))].length;
    const overdueLoans = loans.filter(l => 
      l.status === 'ACTIVE' && l.dueDate && new Date(l.dueDate) < new Date()
    ).length;

    return {
      totalActiveLoans: activeLoans.length,
      totalActiveAmount,
      totalLoans: loans.length,
      totalLoansAmount,
      farmersWithLoans,
      overdueLoans,
      avgLoanSize: loans.length > 0 ? totalLoansAmount / loans.length : 0
    };
  };

  const calculateTrendData = (loans, range) => {
    const now = new Date();
    const data = [];
    
    // Determine number of periods based on range
    let periods, periodName, dateFormat;
    switch(range) {
      case 'week':
        periods = 7;
        periodName = 'Day';
        dateFormat = (date) => date.toLocaleDateString('en-US', { weekday: 'short' });
        break;
      case 'month':
        periods = 30;
        periodName = 'Date';
        dateFormat = (date) => date.getDate();
        break;
      case 'year':
        periods = 12;
        periodName = 'Month';
        dateFormat = (date) => date.toLocaleDateString('en-US', { month: 'short' });
        break;
      default:
        periods = 30;
        periodName = 'Date';
        dateFormat = (date) => date.getDate();
    }
    
    for (let i = periods - 1; i >= 0; i--) {
      const date = new Date();
      if (range === 'year') {
        date.setMonth(now.getMonth() - i);
      } else {
        date.setDate(now.getDate() - i);
      }
      
      // Filter loans for this period
      const periodLoans = loans.filter(loan => {
        const loanDate = new Date(loan.loanDate);
        if (range === 'year') {
          return loanDate.getMonth() === date.getMonth() && 
                 loanDate.getFullYear() === date.getFullYear();
        } else {
          return loanDate.toDateString() === date.toDateString();
        }
      });
      
      const periodRepayments = loans.flatMap(loan => 
        (loan.transactions || []).filter(t => 
          t.transactionType === 'COPRA_PAYMENT' || t.transactionType === 'CASH_PAYMENT'
        ).filter(t => {
          const tDate = new Date(t.transactionDate);
          if (range === 'year') {
            return tDate.getMonth() === date.getMonth() && 
                   tDate.getFullYear() === date.getFullYear();
          } else {
            return tDate.toDateString() === date.toDateString();
          }
        })
      );
      
      data.push({
        name: range === 'year' ? dateFormat(date) : `${periodName} ${dateFormat(date)}`,
        loans: periodLoans.length,
        amount: periodLoans.reduce((sum, loan) => sum + parseFloat(loan.loanAmount || 0), 0),
        repayments: periodRepayments.reduce((sum, t) => sum + parseFloat(t.amount || 0), 0),
        date: date.toISOString().split('T')[0]
      });
    }
    
    return data;
  };

  const calculateLoanStatusData = (loans) => {
    const statusCount = {
      ACTIVE: 0,
      PAID: 0,
      OVERDUE: 0,
      DEFAULTED: 0
    };
    
    loans.forEach(loan => {
      statusCount[loan.status] = (statusCount[loan.status] || 0) + 1;
    });
    
    return Object.entries(statusCount).map(([name, value]) => ({
      name,
      value,
      color: getStatusColor(name).color
    }));
  };

  const calculateTopFarmerLoans = (loans) => {
    const farmerMap = {};
    
    loans.forEach(loan => {
      if (loan.farmer) {
        const farmerId = loan.farmer.id;
        if (!farmerMap[farmerId]) {
          farmerMap[farmerId] = {
            farmer: loan.farmer,
            totalLoans: 0,
            activeLoans: 0,
            totalAmount: 0,
            remainingAmount: 0
          };
        }
        
        farmerMap[farmerId].totalLoans++;
        farmerMap[farmerId].totalAmount += parseFloat(loan.loanAmount || 0);
        
        if (loan.status === 'ACTIVE') {
          farmerMap[farmerId].activeLoans++;
          farmerMap[farmerId].remainingAmount += parseFloat(loan.remainingAmount || 0);
        }
      }
    });
    
    return Object.values(farmerMap)
      .sort((a, b) => b.remainingAmount - a.remainingAmount)
      .slice(0, 10);
  };

  const getRecentTransactions = (loans) => {
    const allTransactions = loans.flatMap(loan => 
      (loan.transactions || []).map(t => ({
        ...t,
        farmerName: loan.farmer?.name,
        loanNumber: loan.loanNumber
      }))
    );
    
    return allTransactions
      .sort((a, b) => new Date(b.transactionDate) - new Date(a.transactionDate))
      .slice(0, 10);
  };

  const calculatePerformanceMetrics = (loans) => {
    const activeLoans = loans.filter(l => l.status === 'ACTIVE');
    const paidLoans = loans.filter(l => l.status === 'PAID');
    
    const totalDisbursed = loans.reduce((sum, loan) => 
      sum + parseFloat(loan.loanAmount || 0), 0);
    
    const totalRepaid = paidLoans.reduce((sum, loan) => 
      sum + parseFloat(loan.loanAmount || 0), 0);
    
    const totalInterest = loans.reduce((sum, loan) => 
      sum + parseFloat(loan.totalInterest || 0), 0);
    
    const avgRepaymentTime = paidLoans.length > 0 ? 
      paidLoans.reduce((sum, loan) => {
        const loanDate = new Date(loan.loanDate);
        const lastPayment = loan.transactions && loan.transactions.length > 0 ?
          new Date(Math.max(...loan.transactions.map(t => new Date(t.transactionDate)))) :
          new Date();
        return sum + (lastPayment - loanDate) / (1000 * 60 * 60 * 24);
      }, 0) / paidLoans.length : 0;
    
    const defaultRate = loans.filter(l => l.status === 'DEFAULTED').length / loans.length * 100;
    
    return {
      totalDisbursed,
      totalRepaid,
      totalInterest,
      repaymentRate: totalDisbursed > 0 ? (totalRepaid / totalDisbursed) * 100 : 0,
      avgRepaymentTime,
      defaultRate,
      activeLoanValue: activeLoans.reduce((sum, loan) => 
        sum + parseFloat(loan.remainingAmount || 0), 0)
    };
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'ACTIVE': return { bg: '#e8f5e8', color: '#00a859' };
      case 'PAID': return { bg: '#e3f2fd', color: '#0066b3' };
      case 'OVERDUE': return { bg: '#fff3cd', color: '#856404' };
      case 'DEFAULTED': return { bg: '#ffeaea', color: '#dc3545' };
      default: return { bg: '#f5f5f5', color: '#666' };
    }
  };

  const COLORS = ['#00a859', '#0066b3', '#ffc107', '#dc3545'];

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="h4" sx={{ fontWeight: 'bold', color: '#004b87' }}>
            Loan Analytics Dashboard
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
            <FormControl size="small" sx={{ minWidth: 120 }}>
              <InputLabel>Time Range</InputLabel>
              <Select
                value={timeRange}
                label="Time Range"
                onChange={(e) => setTimeRange(e.target.value)}
                startAdornment={<FilterIcon sx={{ mr: 1 }} />}
              >
                <MenuItem value="week">Last 7 Days</MenuItem>
                <MenuItem value="month">Last 30 Days</MenuItem>
                <MenuItem value="year">Last 12 Months</MenuItem>
              </Select>
            </FormControl>
            <Tooltip title="Refresh Data">
              <IconButton onClick={fetchDashboardData} color="primary">
                <RefreshIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Export Report">
              <IconButton color="primary">
                <DownloadIcon />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>
        
        {error && (
          <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}
      </Box>

      {/* Summary Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ 
            borderLeft: '4px solid #0066b3',
            height: '100%'
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h4" fontWeight="bold" color="#004b87">
                    {dashboardData.summary.totalActiveLoans}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Active Loans
                  </Typography>
                </Box>
                <LoanIcon sx={{ fontSize: 40, color: '#0066b3', opacity: 0.8 }} />
              </Box>
              <Typography variant="caption" color="text.secondary">
                ₹{dashboardData.summary.totalActiveAmount?.toLocaleString('en-IN')} total amount
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ 
            borderLeft: '4px solid #00a859',
            height: '100%'
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h4" fontWeight="bold" color="#004b87">
                    {dashboardData.summary.farmersWithLoans}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Farmers with Loans
                  </Typography>
                </Box>
                <PeopleIcon sx={{ fontSize: 40, color: '#00a859', opacity: 0.8 }} />
              </Box>
              <Typography variant="caption" color="text.secondary">
                {dashboardData.summary.totalLoans} total loans
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ 
            borderLeft: '4px solid #ffc107',
            height: '100%'
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h4" fontWeight="bold" color="#004b87">
                    {dashboardData.summary.overdueLoans}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Overdue Loans
                  </Typography>
                </Box>
                <ScheduleIcon sx={{ fontSize: 40, color: '#ffc107', opacity: 0.8 }} />
              </Box>
              <Typography variant="caption" color="text.secondary">
                Needs attention
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ 
            borderLeft: '4px solid #dc3545',
            height: '100%'
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h4" fontWeight="bold" color="#004b87">
                    ₹{dashboardData.summary.avgLoanSize?.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Average Loan Size
                  </Typography>
                </Box>
                <MoneyIcon sx={{ fontSize: 40, color: '#dc3545', opacity: 0.8 }} />
              </Box>
              <Typography variant="caption" color="text.secondary">
                Total disbursed: ₹{dashboardData.summary.totalLoansAmount?.toLocaleString('en-IN')}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Charts Row */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {/* Loan Trend Chart */}
        <Grid item xs={12} md={8}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                <TrendingIcon sx={{ mr: 1, color: '#0066b3' }} />
                <Typography variant="h6" fontWeight="bold">
                  Loan Disbursement & Repayment Trend
                </Typography>
              </Box>
              <Box sx={{ height: 300 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={dashboardData.trendData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="name" stroke="#666" />
                    <YAxis stroke="#666" />
                    <RechartsTooltip 
                      formatter={(value) => [`₹${value.toLocaleString('en-IN')}`, 'Amount']}
                      labelFormatter={(label) => `Period: ${label}`}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="amount" 
                      name="Loans Disbursed" 
                      stroke="#0066b3" 
                      strokeWidth={2}
                      activeDot={{ r: 8 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="repayments" 
                      name="Repayments" 
                      stroke="#00a859" 
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Loan Status Pie Chart */}
        <Grid item xs={12} md={4}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                <PieChartIcon sx={{ mr: 1, color: '#0066b3' }} />
                <Typography variant="h6" fontWeight="bold">
                  Loan Status Distribution
                </Typography>
              </Box>
              <Box sx={{ height: 300 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={dashboardData.loanStatusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {dashboardData.loanStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <RechartsTooltip formatter={(value) => [value, 'Loans']} />
                  </PieChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Performance Metrics */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" sx={{ mb: 3, color: '#004b87' }}>
                <BarChartIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                Performance Metrics
              </Typography>
              
              <Grid container spacing={3}>
                <Grid item xs={12} md={3}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="h4" fontWeight="bold" color="#00a859">
                      {dashboardData.performanceMetrics.repaymentRate?.toFixed(1)}%
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Repayment Rate
                    </Typography>
                    <LinearProgress 
                      variant="determinate" 
                      value={dashboardData.performanceMetrics.repaymentRate || 0}
                      sx={{ mt: 1, height: 8, borderRadius: 4 }}
                      color="success"
                    />
                  </Box>
                </Grid>
                
                <Grid item xs={12} md={3}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="h4" fontWeight="bold" color="#0066b3">
                      ₹{dashboardData.performanceMetrics.totalInterest?.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Total Interest Earned
                    </Typography>
                  </Box>
                </Grid>
                
                <Grid item xs={12} md={3}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="h4" fontWeight="bold" color="#ffc107">
                      {dashboardData.performanceMetrics.avgRepaymentTime?.toFixed(0)} days
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Average Repayment Time
                    </Typography>
                  </Box>
                </Grid>
                
                <Grid item xs={12} md={3}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="h4" fontWeight="bold" color="#dc3545">
                      {dashboardData.performanceMetrics.defaultRate?.toFixed(1)}%
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Default Rate
                    </Typography>
                    <LinearProgress 
                      variant="determinate" 
                      value={dashboardData.performanceMetrics.defaultRate || 0}
                      sx={{ mt: 1, height: 8, borderRadius: 4 }}
                      color="error"
                    />
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Bottom Tables Row */}
      <Grid container spacing={3}>
        {/* Top Farmers with Loans */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" sx={{ mb: 3, color: '#004b87' }}>
                <PeopleIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                Top Farmers with Active Loans
              </Typography>
              
              <TableContainer component={Paper} variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
                      <TableCell>Farmer</TableCell>
                      <TableCell align="right">Active Loans</TableCell>
                      <TableCell align="right">Total Due</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {dashboardData.farmerLoans.map((item, index) => (
                      <TableRow key={index} hover>
                        <TableCell>
                          <Box>
                            <Typography variant="body2" fontWeight="medium">
                              {item.farmer.name}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {item.farmer.farmerCode} • {item.farmer.village}
                            </Typography>
                          </Box>
                        </TableCell>
                        <TableCell align="right">
                          <Chip 
                            label={item.activeLoans} 
                            size="small" 
                            sx={{ backgroundColor: '#e3f2fd', color: '#0066b3' }}
                          />
                        </TableCell>
                        <TableCell align="right">
                          <Typography variant="body2" fontWeight="bold" color="#dc3545">
                            ₹{item.remainingAmount?.toLocaleString('en-IN')}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Recent Transactions */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" sx={{ mb: 3, color: '#004b87' }}>
                <CalendarIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                Recent Loan Transactions
              </Typography>
              
              <TableContainer component={Paper} variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
                      <TableCell>Date</TableCell>
                      <TableCell>Farmer</TableCell>
                      <TableCell align="right">Amount</TableCell>
                      <TableCell>Type</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {dashboardData.recentTransactions.map((transaction, index) => (
                      <TableRow key={index} hover>
                        <TableCell>
                          <Typography variant="body2">
                            {new Date(transaction.transactionDate).toLocaleDateString()}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {transaction.farmerName}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {transaction.loanNumber}
                          </Typography>
                        </TableCell>
                        <TableCell align="right">
                          <Typography 
                            variant="body2" 
                            fontWeight="medium"
                            color={transaction.amount > 0 ? '#00a859' : '#dc3545'}
                          >
                            ₹{Math.abs(transaction.amount)?.toLocaleString('en-IN')}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip 
                            label={transaction.transactionType.replace('_', ' ')} 
                            size="small"
                            sx={{ 
                              backgroundColor: transaction.transactionType.includes('PAYMENT') ? 
                                '#e8f5e8' : '#e3f2fd',
                              color: transaction.transactionType.includes('PAYMENT') ? 
                                '#00a859' : '#0066b3'
                            }}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default LoanDashboard;