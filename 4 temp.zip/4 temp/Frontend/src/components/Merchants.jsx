import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Grid,
  IconButton,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  InputAdornment,
  Alert,
  CircularProgress,
  TableSortLabel, // Added
  TablePagination, // Added
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon,
  Store as StoreIcon,
  Phone as PhoneIcon,
  LocationOn as LocationIcon,
  AccountBalance as BankIcon,
} from '@mui/icons-material';
import { merchantService } from '../services/merchantService';

const Merchants = () => {
  const [merchants, setMerchants] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingMerchant, setEditingMerchant] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    companyName: '',
    mobile: '',
    address: '',
    bankName: '',
    accountNumber: '',
    ifscCode: '',
    upiId: '',
  });

  // Sorting state
  const [order, setOrder] = useState('desc');
  const [orderBy, setOrderBy] = useState('merchantCode');
  
  // Pagination state
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  useEffect(() => {
    fetchMerchants();
  }, []);

  const fetchMerchants = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await merchantService.getAllMerchants();
      setMerchants(response.data);
    } catch (error) {
      console.error('Error fetching merchants:', error);
      setError('Failed to load merchants data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Sorting functions
  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const descendingComparator = (a, b, orderBy) => {
    if (b[orderBy] < a[orderBy]) {
      return -1;
    }
    if (b[orderBy] > a[orderBy]) {
      return 1;
    }
    return 0;
  };

  const getComparator = (order, orderBy) => {
    return order === 'desc'
      ? (a, b) => descendingComparator(a, b, orderBy)
      : (a, b) => -descendingComparator(a, b, orderBy);
  };

  const stableSort = (array, comparator) => {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
      const order = comparator(a[0], b[0]);
      if (order !== 0) return order;
      return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
  };

  // Pagination functions
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleOpenDialog = (merchant = null) => {
    if (merchant) {
      setEditingMerchant(merchant);
      setFormData({
        name: merchant.name,
        companyName: merchant.companyName || '',
        mobile: merchant.mobile,
        address: merchant.address,
        bankName: merchant.bankName || '',
        accountNumber: merchant.accountNumber || '',
        ifscCode: merchant.ifscCode || '',
        upiId: merchant.upiId || '',
      });
    } else {
      setEditingMerchant(null);
      setFormData({
        name: '',
        companyName: '',
        mobile: '',
        address: '',
        bankName: '',
        accountNumber: '',
        ifscCode: '',
        upiId: '',
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingMerchant(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async () => {
    try {
      setError(null);
      if (editingMerchant) {
        await merchantService.updateMerchant(editingMerchant.id, formData);
      } else {
        await merchantService.createMerchant(formData);
      }
      await fetchMerchants();
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving merchant:', error);
      setError('Failed to save merchant. Please try again.');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this merchant?')) {
      try {
        setError(null);
        await merchantService.deleteMerchant(id);
        await fetchMerchants();
      } catch (error) {
        console.error('Error deleting merchant:', error);
        setError('Failed to delete merchant. Please try again.');
      }
    }
  };

  const filteredMerchants = merchants.filter((merchant) => {
    return (
      merchant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      merchant.companyName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      merchant.mobile.includes(searchTerm) ||
      merchant.merchantCode?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  // Prepare sorted and paginated data
  const sortedMerchants = stableSort(filteredMerchants, getComparator(order, orderBy));
  const paginatedMerchants = sortedMerchants.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ color: '#004b87' }}>
          <StoreIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
          Merchants Management
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
          sx={{ background: 'linear-gradient(135deg, #0066b3 0%, #0083d4 100%)' }}
        >
          Add New Merchant
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Search Bar */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              placeholder="Search merchants by name, company, or mobile..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
              variant="outlined"
              size="small"
            />
          </Grid>
        </Grid>
      </Paper>

      {/* Merchants Table with Sorting and Pagination */}
      <Paper sx={{ width: '100%', overflow: 'hidden' }}>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ bgcolor: '#f8f9fa' }}>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  <TableSortLabel
                    active={orderBy === 'merchantCode'}
                    direction={orderBy === 'merchantCode' ? order : 'asc'}
                    onClick={() => handleRequestSort('merchantCode')}
                  >
                    ID
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  <TableSortLabel
                    active={orderBy === 'companyName'}
                    direction={orderBy === 'companyName' ? order : 'asc'}
                    onClick={() => handleRequestSort('companyName')}
                  >
                    Shop Name
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  <TableSortLabel
                    active={orderBy === 'name'}
                    direction={orderBy === 'name' ? order : 'asc'}
                    onClick={() => handleRequestSort('name')}
                  >
                    Contact Person
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  Mobile
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  Address
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  Bank Details
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }} align="right">
                  <TableSortLabel
                    active={orderBy === 'totalPurchased'}
                    direction={orderBy === 'totalPurchased' ? order : 'asc'}
                    onClick={() => handleRequestSort('totalPurchased')}
                  >
                    Total Purchased (kg)
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedMerchants.length > 0 ? (
                paginatedMerchants.map((merchant) => (
                  <TableRow key={merchant.id} hover>
                    <TableCell>
                      <Typography fontWeight="bold">{merchant.merchantCode}</Typography>
                    </TableCell>
                    <TableCell>
                      <Box>
                        <Typography fontWeight="medium">{merchant.companyName || merchant.name}</Typography>
                        {merchant.companyName && (
                          <Typography variant="caption" color="text.secondary">
                            {merchant.name}
                          </Typography>
                        )}
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2">{merchant.name}</Typography>
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <PhoneIcon sx={{ fontSize: 16, mr: 0.5, color: '#666' }} />
                        <Typography variant="body2">{merchant.mobile}</Typography>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'flex-start' }}>
                        <LocationIcon sx={{ fontSize: 16, mr: 0.5, mt: 0.5, color: '#666' }} />
                        <Typography variant="body2">{merchant.address}</Typography>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Box>
                        {merchant.bankName && (
                          <>
                            <Typography variant="body2">
                              <BankIcon sx={{ fontSize: 16, verticalAlign: 'middle', mr: 0.5 }} />
                              {merchant.bankName}
                            </Typography>
                            {merchant.accountNumber && (
                              <Typography variant="caption" display="block" color="text.secondary">
                                A/C: {merchant.accountNumber}
                              </Typography>
                            )}
                            {merchant.ifscCode && (
                              <Typography variant="caption" color="text.secondary">
                                IFSC: {merchant.ifscCode}
                              </Typography>
                            )}
                          </>
                        )}
                      </Box>
                    </TableCell>
                    <TableCell align="right">
                      <Typography variant="body1" fontWeight="medium">
                        {parseFloat(merchant.totalPurchased || 0).toLocaleString('en-IN', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', gap: 1 }}>
                        <IconButton
                          color="primary"
                          onClick={() => handleOpenDialog(merchant)}
                          sx={{ 
                            backgroundColor: 'rgba(0, 102, 179, 0.1)',
                            '&:hover': { backgroundColor: 'rgba(0, 102, 179, 0.2)' }
                          }}
                          size="small"
                        >
                          <EditIcon fontSize="small" />
                        </IconButton>
                        <IconButton
                          color="error"
                          onClick={() => handleDelete(merchant.id)}
                          sx={{ 
                            backgroundColor: 'rgba(220, 53, 69, 0.1)',
                            '&:hover': { backgroundColor: 'rgba(220, 53, 69, 0.2)' }
                          }}
                          size="small"
                        >
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={8} align="center" sx={{ py: 4 }}>
                    <Typography variant="body1" color="text.secondary">
                      No merchants found
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25, 50]}
          component="div"
          count={filteredMerchants.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          sx={{
            borderTop: '1px solid rgba(224, 224, 224, 1)',
          }}
        />
      </Paper>

      {/* Add/Edit Merchant Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle sx={{ color: '#004b87' }}>
          {editingMerchant ? 'Edit Merchant' : 'Add New Merchant'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Contact Person Name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
                size="small"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Company/Shop Name"
                name="companyName"
                value={formData.companyName}
                onChange={handleInputChange}
                size="small"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Mobile Number"
                name="mobile"
                value={formData.mobile}
                onChange={handleInputChange}
                required
                size="small"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Address"
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                multiline
                rows={2}
                size="small"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Bank Name"
                name="bankName"
                value={formData.bankName}
                onChange={handleInputChange}
                size="small"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Account Number"
                name="accountNumber"
                value={formData.accountNumber}
                onChange={handleInputChange}
                size="small"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="IFSC Code"
                name="ifscCode"
                value={formData.ifscCode}
                onChange={handleInputChange}
                size="small"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="UPI ID"
                name="upiId"
                value={formData.upiId}
                onChange={handleInputChange}
                size="small"
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} sx={{ color: '#666' }}>
            Cancel
          </Button>
          <Button 
            variant="contained" 
            onClick={handleSubmit}
            sx={{ background: 'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)' }}
          >
            {editingMerchant ? 'Update' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Merchants;