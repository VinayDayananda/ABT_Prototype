import React, { useState, useEffect } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { 
  Box, 
  AppBar, 
  Toolbar, 
  Typography, 
  IconButton, 
  Button,
  Avatar,
  Menu,
  MenuItem,
  Container,
  Chip,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Tooltip,
  Badge,
  Popover,
  Grid,
  Paper,
  alpha,
  useTheme,
  Divider,
  Stack,
  Select,
  FormControl,
} from '@mui/material';
import { 
  Language as LanguageIcon,
  Logout as LogoutIcon,
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  People as PeopleIcon,
  ShoppingCart as PurchaseIcon,
  Store as MerchantIcon,
  TrendingUp as TenderIcon,
  Receipt as SaleIcon,
  Assessment as ReportIcon,
  Settings as AdminIcon,
  Help as HelpIcon,
  Notifications as NotificationsIcon,
  Palette as PaletteIcon,
  Person as PersonIcon,
  ChevronRight as ChevronRightIcon,
  Home as HomeIcon,
  Email as EmailIcon,
  Circle as CircleIcon,
  Translate as TranslateIcon,
  AccountBalance as LoanIcon, // ADDED: Loan icon
} from '@mui/icons-material';
import { useTheme as useAppTheme } from '../../App';

// Language translations
const translations = {
  en: {
    welcome: 'Welcome',
    admin: 'Admin',
    owner: 'Owner',
    manager: 'Manager',
    accountant: 'Accountant',
    logout: 'Logout',
    dashboard: 'Dashboard',
    farmers: 'Farmers',
    purchase: 'Purchase',
    merchants: 'Merchants',
    tenderRates: 'Tender Rates',
    sales: 'Sales',
    reports: 'Reports',
    adminSettings: 'Admin',
    help: 'Help',
    notifications: 'Notifications',
    new: 'new',
    viewAll: 'View All',
    noNotifications: 'No new notifications',
    profile: 'Profile',
    settings: 'Settings',
    copraSystem: 'Copra Management System',
    theme: 'Theme',
    language: 'Language',
    english: 'English',
    kannada: 'Kannada',
    time: 'Time',
    date: 'Date',
    farmerRegistration: 'New farmer registration',
    tenderUpdate: 'Tender rate updated',
    paymentReminder: 'Payment reminder',
    stockAlert: 'Stock alert',
    copyright: '© 2025 Ambika Traders | Copra Management System v1.0',
    selectTheme: 'Select Theme',
    blueOcean: 'Blue Ocean',
    sunsetOrange: 'Sunset Orange',
    greenForest: 'Green Forest',
    purpleRoyal: 'Purple Royal',
    corporateBlue: 'Corporate Blue',
    // ADDED: Loan translations
    loans: 'Loans',
    loanManagement: 'Loan Management',
    loanDashboard: 'Loan Dashboard',
    loanReports: 'Loan Reports',
  },
  kn: {
    welcome: 'ಸ್ವಾಗತ',
    admin: 'ನಿರ್ವಾಹಕ',
    owner: 'ಮಾಲೀಕ',
    manager: 'ವ್ಯವಸ್ಥಾಪಕ',
    accountant: 'ಲೆಕ್ಕಿಗ',
    logout: 'ಲಾಗ್ ಔಟ್',
    dashboard: 'ಡ್ಯಾಶ್ಬೋರ್ಡ್',
    farmers: 'ರೈತರು',
    purchase: 'ಕೊಳ್ಳುವುದು',
    merchants: 'ವ್ಯಾಪಾರಿಗಳು',
    tenderRates: 'ಟೆಂಡರ್ ದರಗಳು',
    sales: 'ಮಾರಾಟ',
    reports: 'ವರದಿಗಳು',
    adminSettings: 'ನಿರ್ವಾಹಕ',
    help: 'ಸಹಾಯ',
    notifications: 'ಅಧಿಸೂಚನೆಗಳು',
    new: 'ಹೊಸ',
    viewAll: 'ಎಲ್ಲವನ್ನು ನೋಡಿ',
    noNotifications: 'ಹೊಸ ಅಧಿಸೂಚನೆಗಳಿಲ್ಲ',
    profile: 'ಪ್ರೊಫೈಲ್',
    settings: 'ಸೆಟ್ಟಿಂಗ್ಸ್',
    copraSystem: 'ಕೊಪ್ರಾ ನಿರ್ವಹಣಾ ವ್ಯವಸ್ಥೆ',
    theme: 'ಥೀಮ್',
    language: 'ಭಾಷೆ',
    english: 'ಇಂಗ್ಲಿಷ್',
    kannada: 'ಕನ್ನಡ',
    time: 'ಸಮಯ',
    date: 'ದಿನಾಂಕ',
    farmerRegistration: 'ಹೊಸ ರೈತ ನೋಂದಣಿ',
    tenderUpdate: 'ಟೆಂಡರ್ ದರ ನವೀಕರಿಸಲಾಗಿದೆ',
    paymentReminder: 'ಪಾವತಿ ಜ್ಞಾಪನೆ',
    stockAlert: 'ಸ್ಟಾಕ್ ಎಚ್ಚರಿಕೆ',
    copyright: '© 2025 ಅಂಬಿಕಾ ವ್ಯಾಪಾರಿಗಳು | ಕೊಪ್ರಾ ನಿರ್ವಹಣಾ ವ್ಯವಸ್ಥೆ v1.0',
    selectTheme: 'ಥೀಮ್ ಆಯ್ಕೆಮಾಡಿ',
    blueOcean: 'ನೀಲಿ ಸಮುದ್ರ',
    sunsetOrange: 'ಸೂರ್ಯಾಸ್ತ ಕಿತ್ತಳೆ',
    greenForest: 'ಹಸಿರು ಅರಣ್ಯ',
    purpleRoyal: 'ರಾಜಕೀಯ ನೇರಳೆ',
    corporateBlue: 'ಕಾರ್ಪೊರೇಟ್ ನೀಲಿ',
    // ADDED: Loan translations
    loans: 'ಕಡವುಗಳು',
    loanManagement: 'ಕಡವು ನಿರ್ವಹಣೆ',
    loanDashboard: 'ಕಡವು ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
    loanReports: 'ಕಡವು ವರದಿಗಳು',
  }
};

// Notification texts
const notificationTexts = {
  en: [
    'New farmer registration: Ramu Gowda',
    'Tender rate updated: ₹282/kg',
    'Payment reminder: Suresh Kumar - ₹15,000',
    'Stock alert: Copra below 5000kg',
  ],
  kn: [
    'ಹೊಸ ರೈತ ನೋಂದಣಿ: ರಾಮು ಗೌಡ',
    'ಟೆಂಡರ್ ದರ ನವೀಕರಿಸಲಾಗಿದೆ: ₹282/ಕೆಜಿ',
    'ಪಾವತಿ ಜ್ಞಾಪನೆ: ಸುರೇಶ್ ಕುಮಾರ್ - ₹15,000',
    'ಸ್ಟಾಕ್ ಎಚ್ಚರಿಕೆ: ಕೊಪ್ರಾ 5000 ಕೆಜಿ ಕೆಳಗೆ',
  ]
};

const Layout = ({ children, onLogout }) => {
  const [language, setLanguage] = useState(() => {
    return localStorage.getItem('appLanguage') || 'en';
  });
  const [anchorEl, setAnchorEl] = useState(null);
  const [themeMenuAnchor, setThemeMenuAnchor] = useState(null);
  const [notificationAnchorEl, setNotificationAnchorEl] = useState(null);
  const [profileAnchorEl, setProfileAnchorEl] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const userRole = localStorage.getItem('userRole') || 'Owner';
  const muiTheme = useTheme();
  const { currentTheme, handleThemeChange, themes } = useAppTheme();

  const t = translations[language];

  useEffect(() => {
    // Update document title based on language
    document.title = language === 'kn' 
      ? 'ಅಂಬಿಕಾ ವ್ಯಾಪಾರಿಗಳು - ಕೊಪ್ರಾ ನಿರ್ವಹಣಾ ವ್ಯವಸ್ಥೆ'
      : 'Ambika Traders - Copra Management System';
  }, [language]);

  const handleLanguageChange = (lang) => {
    setLanguage(lang);
    localStorage.setItem('appLanguage', lang);
    handleClose();
  };

  const handleThemeMenu = (event) => {
    setThemeMenuAnchor(event.currentTarget);
  };

  const handleNotificationMenu = (event) => {
    setNotificationAnchorEl(event.currentTarget);
  };

  const handleProfileMenu = (event) => {
    setProfileAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
    setThemeMenuAnchor(null);
    setNotificationAnchorEl(null);
    setProfileAnchorEl(null);
  };

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  // Get notifications in current language
  const notifications = [
    { 
      id: 1, 
      text: notificationTexts[language][0], 
      time: language === 'kn' ? '10 ನಿಮಿಷಗಳ ಹಿಂದೆ' : '10 min ago', 
      read: false,
      type: 'success'
    },
    { 
      id: 2, 
      text: notificationTexts[language][1], 
      time: language === 'kn' ? '1 ಗಂಟೆ ಹಿಂದೆ' : '1 hour ago', 
      read: true,
      type: 'info'
    },
    { 
      id: 3, 
      text: notificationTexts[language][2], 
      time: language === 'kn' ? '2 ಗಂಟೆಗಳ ಹಿಂದೆ' : '2 hours ago', 
      read: false,
      type: 'warning'
    },
    { 
      id: 4, 
      text: notificationTexts[language][3], 
      time: language === 'kn' ? '3 ಗಂಟೆಗಳ ಹಿಂದೆ' : '3 hours ago', 
      read: true,
      type: 'error'
    },
  ];

  const unreadCount = notifications.filter(n => !n.read).length;

  // UPDATED: Added loan management tab
  const tabs = [
    { id: 'dashboard', label: t.dashboard, path: '/dashboard', icon: <DashboardIcon /> },
    { id: 'farmers', label: t.farmers, path: '/farmers', icon: <PeopleIcon /> },
    { id: 'purchase', label: t.purchase, path: '/purchase', icon: <PurchaseIcon /> },
    // ADDED: Loan management tab
    { id: 'loans', label: t.loanManagement, path: '/loans', icon: <LoanIcon /> },
    { id: 'merchants', label: t.merchants, path: '/merchants', icon: <MerchantIcon /> },
    { id: 'tender-rates', label: t.tenderRates, path: '/tender-rates', icon: <TenderIcon /> },
    { id: 'sales', label: t.sales, path: '/sales', icon: <SaleIcon /> },
    { id: 'reports', label: t.reports, path: '/reports', icon: <ReportIcon /> },
    { id: 'admin', label: t.adminSettings, path: '/admin', icon: <AdminIcon /> },
    { id: 'help', label: t.help, path: '/help', icon: <HelpIcon /> },
  ];

  const drawer = (
    <Box sx={{ 
      width: 280, 
      height: '100%', 
      bgcolor: muiTheme.palette.background.paper,
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* User Profile Section */}
      <Box sx={{ 
        p: 3, 
        borderBottom: `1px solid ${muiTheme.palette.divider}`,
        background: muiTheme.palette.primary.main,
        color: 'white',
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Avatar
            sx={{
              width: 56,
              height: 56,
              bgcolor: 'white',
              color: muiTheme.palette.primary.main,
              fontSize: '1.5rem',
              fontWeight: 'bold',
              border: '3px solid white',
            }}
          >
            {userRole.charAt(0).toUpperCase()}
          </Avatar>
          <Box>
            <Typography variant="h6" sx={{ fontWeight: 600 }}>
              {t[userRole] || userRole}
            </Typography>
            <Typography variant="body2" sx={{ opacity: 0.9 }}>
              {userRole === 'admin' ? 'System Administrator' : 
               userRole === 'owner' ? 'Shop Owner' : 
               userRole === 'manager' ? 'Manager' : 'Accountant'}
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* Navigation */}
      <List sx={{ p: 2, flex: 1 }}>
        {tabs.map((tab) => (
          <ListItem
            key={tab.id}
            button
            selected={location.pathname === tab.path}
            onClick={() => {
              navigate(tab.path);
              setMobileOpen(false);
            }}
            sx={{
              borderRadius: 2,
              mb: 1,
              borderLeft: location.pathname === tab.path ? '4px solid' : 'none',
              borderColor: muiTheme.palette.primary.main,
              backgroundColor: location.pathname === tab.path 
                ? alpha(muiTheme.palette.primary.main, 0.08)
                : 'transparent',
              '&:hover': {
                backgroundColor: alpha(muiTheme.palette.primary.main, 0.04),
              },
              transition: 'all 0.2s ease',
            }}
          >
            <ListItemIcon sx={{ 
              color: location.pathname === tab.path 
                ? muiTheme.palette.primary.main 
                : muiTheme.palette.text.secondary,
              minWidth: 40,
            }}>
              {tab.icon}
            </ListItemIcon>
            <ListItemText 
              primary={tab.label} 
              sx={{ 
                '& .MuiTypography-root': {
                  fontSize: '0.9rem',
                  fontWeight: location.pathname === tab.path ? '600' : '400',
                  color: location.pathname === tab.path 
                    ? muiTheme.palette.primary.main 
                    : muiTheme.palette.text.primary,
                }
              }}
            />
            {location.pathname === tab.path && (
              <ChevronRightIcon sx={{ 
                color: muiTheme.palette.primary.main,
                fontSize: 20,
              }} />
            )}
          </ListItem>
        ))}
      </List>

      {/* Footer */}
      <Box sx={{ p: 2, borderTop: `1px solid ${muiTheme.palette.divider}` }}>
        <Button
          fullWidth
          startIcon={<LogoutIcon />}
          onClick={onLogout}
          variant="outlined"
          sx={{
            justifyContent: 'center',
            textTransform: 'none',
            color: muiTheme.palette.error.main,
            borderColor: muiTheme.palette.error.main,
            '&:hover': {
              backgroundColor: alpha(muiTheme.palette.error.main, 0.08),
              borderColor: muiTheme.palette.error.dark,
            },
            py: 1,
            borderRadius: 2,
          }}
        >
          {t.logout}
        </Button>
      </Box>
    </Box>
  );

  return (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      minHeight: '100vh',
      background: muiTheme.palette.background.default,
    }}>
      {/* Top Header */}
      <AppBar
        position="sticky"
        elevation={0}
        sx={{
          background: muiTheme.palette.primary.main,
          borderBottom: `2px solid ${alpha('#fff', 0.1)}`,
          backdropFilter: 'blur(10px)',
        }}
      >
        <Container maxWidth="xl" sx={{ px: { xs: 2, sm: 3 } }}>
          {/* First Row - Main Header */}
          <Toolbar disableGutters sx={{ 
            py: 1.5,
            minHeight: '70px !important',
            gap: 2,
          }}>
            {/* Mobile Menu Button */}
            <IconButton
              color="inherit"
              aria-label="open drawer"
              edge="start"
              onClick={handleDrawerToggle}
              sx={{ 
                display: { md: 'none' },
                color: 'white',
                p: 1,
              }}
            >
              <MenuIcon sx={{ fontSize: 28 }} />
            </IconButton>

            {/* Logo */}
            <Box sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: 2,
              cursor: 'pointer',
              flex: 1,
            }} onClick={() => navigate('/dashboard')}>
              <Box sx={{
                width: 44,
                height: 44,
                borderRadius: '12px',
                background: 'white',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
              }}>
                <HomeIcon sx={{ 
                  color: muiTheme.palette.primary.main,
                  fontSize: 24,
                }} />
              </Box>
              <Box>
                <Typography variant="h5" sx={{ 
                  fontWeight: '800', 
                  color: 'white',
                  fontSize: '1.4rem',
                  lineHeight: 1.2,
                  letterSpacing: '0.5px',
                }}>
                  AMBIKA TRADERS
                </Typography>
                <Typography variant="caption" sx={{ 
                  color: alpha('#fff', 0.9),
                  fontSize: '0.75rem',
                  fontWeight: 500,
                  display: 'block',
                }}>
                  {t.copraSystem}
                </Typography>
              </Box>
            </Box>

            {/* Action Buttons - Spaced properly */}
            <Stack 
              direction="row" 
              spacing={1.5}
              sx={{ 
                alignItems: 'center',
                display: { xs: 'none', md: 'flex' },
              }}
            >
              {/* Theme Switcher - Now as Dropdown */}
              <Tooltip title={t.theme}>
                <FormControl size="small" sx={{ minWidth: 120 }}>
                  <Select
                    value={currentTheme}
                    onChange={(e) => handleThemeChange(e.target.value)}
                    displayEmpty
                    sx={{
                      color: 'white',
                      backgroundColor: alpha('#fff', 0.1),
                      borderRadius: '12px',
                      '& .MuiSelect-select': {
                        py: 1,
                        display: 'flex',
                        alignItems: 'center',
                        gap: 1,
                      },
                      '& .MuiOutlinedInput-notchedOutline': {
                        border: 'none',
                      },
                      '& .MuiSelect-icon': {
                        color: 'white',
                      },
                      '&:hover': {
                        backgroundColor: alpha('#fff', 0.2),
                      },
                    }}
                  >
                    <MenuItem value="" disabled>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <PaletteIcon sx={{ fontSize: 20 }} />
                        {t.selectTheme}
                      </Box>
                    </MenuItem>
                    {Object.entries(themes).map(([key, themeData]) => (
                      <MenuItem key={key} value={key}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, width: '100%' }}>
                          <Box sx={{
                            width: 20,
                            height: 20,
                            borderRadius: '4px',
                            background: themeData.gradients.primary,
                          }} />
                          <Typography sx={{ flex: 1 }}>
                            {key === 'blue' ? t.blueOcean :
                             key === 'orange' ? t.sunsetOrange :
                             key === 'green' ? t.greenForest :
                             key === 'purple' ? t.purpleRoyal :
                             t.corporateBlue}
                          </Typography>
                          {currentTheme === key && (
                            <Box sx={{
                              width: 8,
                              height: 8,
                              borderRadius: '50%',
                              background: 'white',
                            }} />
                          )}
                        </Box>
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Tooltip>

              {/* Language Selector - Working Dropdown */}
              <Tooltip title={t.language}>
                <FormControl size="small" sx={{ minWidth: 100 }}>
                  <Select
                    value={language}
                    onChange={(e) => handleLanguageChange(e.target.value)}
                    sx={{
                      color: 'white',
                      backgroundColor: alpha('#fff', 0.1),
                      borderRadius: '12px',
                      '& .MuiSelect-select': {
                        py: 1,
                        display: 'flex',
                        alignItems: 'center',
                        gap: 1,
                      },
                      '& .MuiOutlinedInput-notchedOutline': {
                        border: 'none',
                      },
                      '& .MuiSelect-icon': {
                        color: 'white',
                      },
                      '&:hover': {
                        backgroundColor: alpha('#fff', 0.2),
                      },
                    }}
                  >
                    <MenuItem value="en">
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <LanguageIcon sx={{ fontSize: 20 }} />
                        {t.english}
                      </Box>
                    </MenuItem>
                    <MenuItem value="kn">
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <TranslateIcon sx={{ fontSize: 20 }} />
                        {t.kannada}
                      </Box>
                    </MenuItem>
                  </Select>
                </FormControl>
              </Tooltip>

              {/* Notifications */}
              <Tooltip title={t.notifications}>
                <IconButton
                  onClick={handleNotificationMenu}
                  sx={{ 
                    color: 'white',
                    backgroundColor: alpha('#fff', 0.1),
                    width: 44,
                    height: 44,
                    borderRadius: '12px',
                    position: 'relative',
                    '&:hover': {
                      backgroundColor: alpha('#fff', 0.2),
                    },
                  }}
                >
                  <Badge 
                    badgeContent={unreadCount} 
                    color="error"
                    sx={{
                      '& .MuiBadge-badge': {
                        fontSize: '0.7rem',
                        height: 20,
                        minWidth: 20,
                      }
                    }}
                  >
                    <NotificationsIcon />
                  </Badge>
                </IconButton>
              </Tooltip>
            </Stack>

            {/* User Profile */}
            <Box sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: 1.5,
              ml: { xs: 'auto', md: 0 },
            }}>
              <Box sx={{ 
                textAlign: 'right', 
                display: { xs: 'none', sm: 'block' },
              }}>
                <Typography variant="subtitle2" sx={{ 
                  fontWeight: 600, 
                  color: 'white',
                  fontSize: '0.9rem',
                }}>
                  {t.welcome}, {t[userRole] || userRole}
                </Typography>
                <Typography variant="caption" sx={{ 
                  color: alpha('#fff', 0.8),
                  fontSize: '0.75rem',
                }}>
                  {new Date().toLocaleTimeString(language === 'kn' ? 'kn-IN' : 'en-IN', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </Typography>
              </Box>
              
              {/* User Avatar with Logout */}
              <Box sx={{ position: 'relative' }}>
                <Tooltip title={`${t.profile} & ${t.logout}`}>
                  <IconButton
                    onClick={handleProfileMenu}
                    sx={{ p: 0 }}
                  >
                    <Avatar
                      sx={{
                        width: 46,
                        height: 46,
                        bgcolor: 'white',
                        color: muiTheme.palette.primary.main,
                        fontWeight: 'bold',
                        border: '3px solid white',
                        fontSize: '1.1rem',
                      }}
                    >
                      {userRole.charAt(0).toUpperCase()}
                    </Avatar>
                  </IconButton>
                </Tooltip>
                
                {/* Logout Button */}
                <Tooltip title={t.logout}>
                  <IconButton
                    onClick={onLogout}
                    sx={{
                      position: 'absolute',
                      bottom: -8,
                      right: -8,
                      backgroundColor: muiTheme.palette.error.main,
                      color: 'white',
                      width: 28,
                      height: 28,
                      '&:hover': {
                        backgroundColor: muiTheme.palette.error.dark,
                      },
                      border: '2px solid white',
                    }}
                  >
                    <LogoutIcon sx={{ fontSize: 16 }} />
                  </IconButton>
                </Tooltip>
              </Box>
            </Box>
          </Toolbar>

          {/* Tab Navigation - Desktop */}
          <Box sx={{ 
            display: { xs: 'none', md: 'block' },
            background: alpha(muiTheme.palette.primary.dark, 0.8),
            borderTop: `1px solid ${alpha('#fff', 0.15)}`,
            borderRadius: '0 0 12px 12px',
            overflow: 'hidden',
            mx: -3,
          }}>
            <Box sx={{ 
              display: 'flex', 
              overflowX: 'auto', 
              '&::-webkit-scrollbar': { display: 'none' },
              px: 3,
            }}>
              {tabs.map((tab) => (
                <Button
                  key={tab.id}
                  onClick={() => navigate(tab.path)}
                  startIcon={tab.icon}
                  sx={{
                    minWidth: 'auto',
                    px: 3,
                    py: 1.8,
                    borderRadius: 0,
                    color: location.pathname === tab.path ? 'white' : alpha('#fff', 0.85),
                    borderBottom: location.pathname === tab.path 
                      ? `3px solid white` 
                      : `3px solid transparent`,
                    backgroundColor: location.pathname === tab.path 
                      ? alpha('#fff', 0.15) 
                      : 'transparent',
                    fontWeight: location.pathname === tab.path ? '700' : '500',
                    textTransform: 'none',
                    fontSize: '0.9rem',
                    whiteSpace: 'nowrap',
                    letterSpacing: '0.3px',
                    '&:hover': {
                      backgroundColor: alpha('#fff', 0.2),
                      color: 'white',
                    },
                    transition: 'all 0.2s ease',
                    gap: 1,
                  }}
                >
                  {tab.label}
                </Button>
              ))}
            </Box>
          </Box>
        </Container>
      </AppBar>

      {/* Notifications Popover */}
      <Popover
        open={Boolean(notificationAnchorEl)}
        anchorEl={notificationAnchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        sx={{
          mt: 1,
          '& .MuiPaper-root': {
            borderRadius: 16,
            width: 380,
            maxHeight: 500,
            overflow: 'hidden',
            boxShadow: '0 20px 60px rgba(0, 0, 0, 0.2)',
          },
        }}
      >
        <Box sx={{ 
          p: 2.5, 
          borderBottom: `1px solid ${muiTheme.palette.divider}`,
          background: muiTheme.palette.primary.main,
          color: 'white',
        }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
              {t.notifications}
            </Typography>
            <Chip 
              label={`${unreadCount} ${t.new}`} 
              size="small" 
              sx={{ 
                backgroundColor: 'white', 
                color: muiTheme.palette.primary.main,
                fontWeight: 600,
                fontSize: '0.7rem',
              }}
            />
          </Box>
        </Box>
        
        <Box sx={{ maxHeight: 400, overflow: 'auto' }}>
          {notifications.length > 0 ? (
            notifications.map((notification) => (
              <Box
                key={notification.id}
                sx={{
                  p: 2.5,
                  borderBottom: `1px solid ${muiTheme.palette.divider}`,
                  backgroundColor: !notification.read 
                    ? alpha(muiTheme.palette.primary.main, 0.04) 
                    : 'transparent',
                  transition: 'background-color 0.2s',
                  '&:hover': {
                    backgroundColor: alpha(muiTheme.palette.primary.main, 0.08),
                  },
                  cursor: 'pointer',
                }}
              >
                <Box sx={{ display: 'flex', gap: 2, alignItems: 'flex-start' }}>
                  <Box sx={{
                    width: 40,
                    height: 40,
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: 
                      notification.type === 'success' ? alpha('#4caf50', 0.1) :
                      notification.type === 'warning' ? alpha('#ff9800', 0.1) :
                      notification.type === 'error' ? alpha('#f44336', 0.1) :
                      alpha('#2196f3', 0.1),
                    color: 
                      notification.type === 'success' ? '#4caf50' :
                      notification.type === 'warning' ? '#ff9800' :
                      notification.type === 'error' ? '#f44336' :
                      '#2196f3',
                    flexShrink: 0,
                  }}>
                    <EmailIcon sx={{ fontSize: 20 }} />
                  </Box>
                  
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="body2" sx={{ 
                      fontWeight: notification.read ? 400 : 600,
                      color: muiTheme.palette.text.primary,
                      mb: 0.5,
                    }}>
                      {notification.text}
                    </Typography>
                    <Typography variant="caption" sx={{ 
                      color: muiTheme.palette.text.secondary,
                      display: 'flex',
                      alignItems: 'center',
                      gap: 0.5,
                    }}>
                      <CircleIcon sx={{ fontSize: 8 }} />
                      {notification.time}
                    </Typography>
                  </Box>
                  
                  {!notification.read && (
                    <Box sx={{
                      width: 10,
                      height: 10,
                      borderRadius: '50%',
                      backgroundColor: muiTheme.palette.primary.main,
                      flexShrink: 0,
                      mt: 0.5,
                    }} />
                  )}
                </Box>
              </Box>
            ))
          ) : (
            <Box sx={{ p: 4, textAlign: 'center' }}>
              <Typography variant="body2" sx={{ color: muiTheme.palette.text.secondary }}>
                {t.noNotifications}
              </Typography>
            </Box>
          )}
        </Box>
        
        <Box sx={{ 
          p: 2, 
          textAlign: 'center',
          borderTop: `1px solid ${muiTheme.palette.divider}`,
        }}>
          <Button 
            size="small" 
            sx={{ 
              textTransform: 'none',
              fontWeight: 500,
            }}
          >
            {t.viewAll}
          </Button>
        </Box>
      </Popover>

      {/* Profile Menu */}
      <Menu
        anchorEl={profileAnchorEl}
        open={Boolean(profileAnchorEl)}
        onClose={handleClose}
        sx={{
          mt: 1,
          '& .MuiPaper-root': {
            borderRadius: 12,
            minWidth: 200,
            boxShadow: '0 10px 40px rgba(0, 0, 0, 0.15)',
          },
        }}
      >
        <Box sx={{ p: 2 }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 0.5 }}>
            {t[userRole] || userRole}
          </Typography>
          <Typography variant="caption" sx={{ color: muiTheme.palette.text.secondary }}>
            {userRole === 'admin' ? 'System Administrator' : 
             userRole === 'owner' ? 'Shop Owner' : 
             userRole === 'manager' ? 'Manager' : 'Accountant'}
          </Typography>
        </Box>
        <Divider />
        <MenuItem onClick={() => {
          navigate('/admin');
          handleClose();
        }}>
          {t.settings}
        </MenuItem>
        <MenuItem onClick={() => {
          navigate('/profile');
          handleClose();
        }}>
          {t.profile}
        </MenuItem>
        <Divider />
        <MenuItem 
          onClick={onLogout}
          sx={{ 
            color: muiTheme.palette.error.main,
            fontWeight: 600,
          }}
        >
          <LogoutIcon sx={{ mr: 1, fontSize: 20 }} />
          {t.logout}
        </MenuItem>
      </Menu>

      {/* Mobile Drawer */}
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        ModalProps={{
          keepMounted: true,
        }}
        sx={{
          display: { xs: 'block', md: 'none' },
          '& .MuiDrawer-paper': { 
            boxSizing: 'border-box', 
            width: 280,
            border: 'none',
            boxShadow: '0 0 40px rgba(0, 0, 0, 0.15)',
          },
        }}
      >
        {drawer}
      </Drawer>

      {/* Main Content */}
      <Container 
        maxWidth="xl" 
        sx={{ 
          flex: 1, 
          py: { xs: 2, md: 3 },
          px: { xs: 2, sm: 3 },
          animation: 'fadeIn 0.3s ease',
          '@keyframes fadeIn': {
            from: { opacity: 0 },
            to: { opacity: 1 },
          },
        }}
      >
        <Outlet />
        {children}
      </Container>

      {/* Footer */}
      <Box
        sx={{
          py: 2.5,
          borderTop: `1px solid ${muiTheme.palette.divider}`,
          backgroundColor: muiTheme.palette.background.paper,
          mt: 'auto',
        }}
      >
        <Container maxWidth="xl">
          <Box sx={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 2,
          }}>
            <Typography variant="body2" sx={{ 
              color: muiTheme.palette.text.secondary,
              fontSize: '0.8rem',
            }}>
              {t.copyright}
            </Typography>
            <Box sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: 2,
              fontSize: '0.8rem',
              color: muiTheme.palette.text.secondary,
            }}>
              <Box sx={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: 0.5,
              }}>
                <PaletteIcon sx={{ fontSize: 14 }} />
                <span>
                  {currentTheme === 'blue' ? t.blueOcean :
                   currentTheme === 'orange' ? t.sunsetOrange :
                   currentTheme === 'green' ? t.greenForest :
                   currentTheme === 'purple' ? t.purpleRoyal :
                   t.corporateBlue}
                </span>
              </Box>
              <span>•</span>
              <Box sx={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: 0.5,
              }}>
                <LanguageIcon sx={{ fontSize: 14 }} />
                <span>{language === 'en' ? t.english : t.kannada}</span>
              </Box>
              <span>•</span>
              <span>{new Date().toLocaleDateString(language === 'kn' ? 'kn-IN' : 'en-IN', { 
                weekday: 'short', 
                day: 'numeric', 
                month: 'short', 
                year: 'numeric' 
              })}</span>
            </Box>
          </Box>
        </Container>
      </Box>
    </Box>
  );
};

export default Layout;