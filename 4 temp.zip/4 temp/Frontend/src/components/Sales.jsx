import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Grid,
  IconButton,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  InputAdornment,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  CircularProgress,
  TablePagination, // Changed from Pagination
  TableSortLabel, // Added
  Card,
  CardContent,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon,
  Download as DownloadIcon,
  TrendingUp as TrendingUpIcon,
  LocalShipping as ShippingIcon,
  AttachMoney as MoneyIcon,
  Warning as WarningIcon,
  CheckCircle as CheckIcon,
} from '@mui/icons-material';
import { salesService } from '../services/salesService';
import { merchantService } from '../services/merchantService';
import { format } from 'date-fns';

const Sales = () => {
  const [sales, setSales] = useState([]);
  const [merchants, setMerchants] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingSale, setEditingSale] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMerchant, setSelectedMerchant] = useState('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    merchantId: '',
    saleDate: format(new Date(), 'yyyy-MM-dd'),
    weightKg: '',
    ratePerQuintal: '',
    purchaseRateAvg: '',
    paymentMethod: 'BANK_TRANSFER',
  });

  // Sorting state
  const [order, setOrder] = useState('desc');
  const [orderBy, setOrderBy] = useState('saleDate');
  
  // Pagination state
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  useEffect(() => {
    fetchSales();
    fetchMerchants();
  }, []);

  const fetchSales = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await salesService.getAllSales();
      setSales(response.data);
    } catch (error) {
      console.error('Error fetching sales:', error);
      setError('Failed to load sales data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const fetchMerchants = async () => {
    try {
      const response = await merchantService.getAllMerchants();
      setMerchants(response.data);
    } catch (error) {
      console.error('Error fetching merchants:', error);
    }
  };

  // Sorting functions
  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const descendingComparator = (a, b, orderBy) => {
    if (b[orderBy] < a[orderBy]) {
      return -1;
    }
    if (b[orderBy] > a[orderBy]) {
      return 1;
    }
    return 0;
  };

  const getComparator = (order, orderBy) => {
    return order === 'desc'
      ? (a, b) => descendingComparator(a, b, orderBy)
      : (a, b) => -descendingComparator(a, b, orderBy);
  };

  const stableSort = (array, comparator) => {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
      const order = comparator(a[0], b[0]);
      if (order !== 0) return order;
      return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
  };

  // Pagination functions
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleOpenDialog = (sale = null) => {
    if (sale) {
      setEditingSale(sale);
      setFormData({
        merchantId: sale.merchantId,
        saleDate: format(new Date(sale.saleDate), 'yyyy-MM-dd'),
        weightKg: sale.weightKg,
        ratePerQuintal: sale.ratePerQuintal,
        purchaseRateAvg: sale.purchaseRateAvg,
        paymentMethod: sale.paymentMethod,
      });
    } else {
      setEditingSale(null);
      setFormData({
        merchantId: '',
        saleDate: format(new Date(), 'yyyy-MM-dd'),
        weightKg: '',
        ratePerQuintal: '',
        purchaseRateAvg: '',
        paymentMethod: 'BANK_TRANSFER',
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingSale(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const calculateAmounts = () => {
    const weight = parseFloat(formData.weightKg) || 0;
    const saleRate = parseFloat(formData.ratePerQuintal) || 0;
    const purchaseRate = parseFloat(formData.purchaseRateAvg) || 0;
    
    const saleValue = (weight / 100) * saleRate;
    const purchaseCost = (weight / 100) * purchaseRate;
    const profit = saleValue - purchaseCost;
    
    return {
      saleValue,
      purchaseCost,
      profit,
    };
  };

  const handleSubmit = async () => {
    try {
      setError(null);
      const amounts = calculateAmounts();
      const saleData = {
        ...formData,
        totalAmount: amounts.saleValue,
        purchaseCost: amounts.purchaseCost,
        profit: amounts.profit,
      };

      if (editingSale) {
        await salesService.updateSale(editingSale.id, saleData);
      } else {
        await salesService.createSale(saleData);
      }
      
      await fetchSales();
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving sale:', error);
      setError('Failed to save sale. Please try again.');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this sale?')) {
      try {
        setError(null);
        await salesService.deleteSale(id);
        await fetchSales();
      } catch (error) {
        console.error('Error deleting sale:', error);
        setError('Failed to delete sale. Please try again.');
      }
    }
  };

  const exportSales = () => {
    const csvContent = filteredSales.map(s => 
      `${s.saleId},${format(new Date(s.saleDate), 'dd/MM/yyyy')},${s.merchantName},${s.weightKg},${s.ratePerQuintal},${s.totalAmount},${s.profit}`
    ).join('\n');
    
    const blob = new Blob([`ID,Date,Merchant,Weight(kg),Rate(₹/q),Total(₹),Profit(₹)\n${csvContent}`], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sales.csv';
    a.click();
  };

  const filteredSales = sales.filter((sale) => {
    const matchesSearch = 
      sale.saleId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sale.merchantName?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesMerchant = selectedMerchant === 'all' || sale.merchantId == selectedMerchant;
    
    const saleDate = new Date(sale.saleDate);
    const start = startDate ? new Date(startDate) : null;
    const end = endDate ? new Date(endDate) : null;
    
    const matchesDate = 
      (!start || saleDate >= start) && 
      (!end || saleDate <= end);
    
    return matchesSearch && matchesMerchant && matchesDate;
  });

  // Prepare sorted and paginated data
  const sortedSales = stableSort(filteredSales, getComparator(order, orderBy));
  const paginatedSales = sortedSales.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  // Calculate total stock from purchases and sales
  const totalStock = () => {
    // This should come from your database
    // For now, using mock calculation
    const totalPurchases = 25000; // Should come from purchases API
    const totalSales = sales.reduce((sum, sale) => sum + sale.weightKg, 0);
    return totalPurchases - totalSales;
  };

  const getSalesSuggestion = () => {
    const stock = totalStock();
    if (stock > 15000) {
      return 'You have high copra stock. Consider selling now to free up storage space and realize profits.';
    } else if (stock < 5000) {
      return 'Stock is running low. Plan your purchases accordingly.';
    } else {
      return 'Stock levels are optimal. Monitor market rates for selling opportunities.';
    }
  };

  const getPaymentMethodIcon = (method) => {
    switch(method) {
      case 'CASH':
        return <MoneyIcon sx={{ fontSize: 16, mr: 0.5 }} />;
      case 'UPI':
        return <CheckIcon sx={{ fontSize: 16, mr: 0.5 }} />;
      case 'BANK_TRANSFER':
        return <MoneyIcon sx={{ fontSize: 16, mr: 0.5 }} />;
      default:
        return <MoneyIcon sx={{ fontSize: 16, mr: 0.5 }} />;
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ color: '#004b87' }}>
          <ShippingIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
          Sales to Merchants
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
          sx={{ background: 'linear-gradient(135deg, #0066b3 0%, #0083d4 100%)' }}
        >
          New Sale
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Smart Selling Suggestions */}
      <Card sx={{ mb: 4, borderLeft: '4px solid #0066b3' }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={8}>
              <Typography variant="h6" sx={{ color: '#004b87', mb: 1 }}>
                <TrendingUpIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                Smart Selling Suggestions
              </Typography>
              <Typography variant="body1" color="text.secondary">
                {getSalesSuggestion()}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Box sx={{ textAlign: { md: 'right' } }}>
                <Typography variant="body2" color="text.secondary">
                  Current Stock:
                </Typography>
                <Typography variant="h5" sx={{ color: '#0066b3', fontWeight: 'bold' }}>
                  {totalStock().toLocaleString()} kg
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Filter Bar */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={2}>
            <TextField
              fullWidth
              type="date"
              label="From"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              size="small"
            />
          </Grid>
          <Grid item xs={12} md={2}>
            <TextField
              fullWidth
              type="date"
              label="To"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              size="small"
            />
          </Grid>
          <Grid item xs={12} md={2}>
            <FormControl fullWidth size="small">
              <InputLabel>Merchant</InputLabel>
              <Select
                value={selectedMerchant}
                label="Merchant"
                onChange={(e) => setSelectedMerchant(e.target.value)}
              >
                <MenuItem value="all">All Merchants</MenuItem>
                {merchants.map((merchant) => (
                  <MenuItem key={merchant.id} value={merchant.id}>
                    {merchant.companyName || merchant.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={3}>
            <TextField
              fullWidth
              placeholder="Search sales..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
              size="small"
            />
          </Grid>
          <Grid item xs={12} md={3}>
            <Button
              fullWidth
              variant="outlined"
              startIcon={<DownloadIcon />}
              onClick={exportSales}
              sx={{ color: '#0066b3', borderColor: '#0066b3' }}
            >
              Export
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* Sales Table with Sorting and Pagination */}
      <Paper sx={{ width: '100%', overflow: 'hidden' }}>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ bgcolor: '#f8f9fa' }}>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  <TableSortLabel
                    active={orderBy === 'saleDate'}
                    direction={orderBy === 'saleDate' ? order : 'asc'}
                    onClick={() => handleRequestSort('saleDate')}
                  >
                    Date
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  <TableSortLabel
                    active={orderBy === 'merchantName'}
                    direction={orderBy === 'merchantName' ? order : 'asc'}
                    onClick={() => handleRequestSort('merchantName')}
                  >
                    Merchant
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  <TableSortLabel
                    active={orderBy === 'weightKg'}
                    direction={orderBy === 'weightKg' ? order : 'asc'}
                    onClick={() => handleRequestSort('weightKg')}
                  >
                    Copra (kg)
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  <TableSortLabel
                    active={orderBy === 'ratePerQuintal'}
                    direction={orderBy === 'ratePerQuintal' ? order : 'asc'}
                    onClick={() => handleRequestSort('ratePerQuintal')}
                  >
                    Rate (₹/q)
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  <TableSortLabel
                    active={orderBy === 'totalAmount'}
                    direction={orderBy === 'totalAmount' ? order : 'asc'}
                    onClick={() => handleRequestSort('totalAmount')}
                  >
                    Total Amount (₹)
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  <TableSortLabel
                    active={orderBy === 'profit'}
                    direction={orderBy === 'profit' ? order : 'asc'}
                    onClick={() => handleRequestSort('profit')}
                  >
                    Profit (₹)
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  Payment
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedSales.length > 0 ? (
                paginatedSales.map((sale) => (
                  <TableRow key={sale.id} hover>
                    <TableCell>
                      {format(new Date(sale.saleDate), 'dd/MM/yyyy')}
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" fontWeight="medium">
                        {sale.merchantName}
                      </Typography>
                      {sale.merchantCode && (
                        <Typography variant="caption" color="text.secondary">
                          {sale.merchantCode}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell align="right">
                      {parseFloat(sale.weightKg).toLocaleString('en-IN', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </TableCell>
                    <TableCell align="right">
                      {parseFloat(sale.ratePerQuintal).toLocaleString()}
                    </TableCell>
                    <TableCell align="right">
                      <Typography fontWeight="medium">
                        ₹{parseFloat(sale.totalAmount).toLocaleString('en-IN', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      <Typography
                        fontWeight="bold"
                        sx={{ color: sale.profit >= 0 ? '#00a859' : '#dc3545' }}
                      >
                        ₹{parseFloat(sale.profit || 0).toLocaleString('en-IN', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        {getPaymentMethodIcon(sale.paymentMethod)}
                        <Typography variant="body2">
                          {sale.paymentMethod === 'CASH' ? 'Cash' : 
                           sale.paymentMethod === 'UPI' ? 'UPI' : 'Bank'}
                        </Typography>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', gap: 1 }}>
                        <IconButton
                          color="primary"
                          onClick={() => handleOpenDialog(sale)}
                          sx={{ 
                            backgroundColor: 'rgba(0, 102, 179, 0.1)',
                            '&:hover': { backgroundColor: 'rgba(0, 102, 179, 0.2)' }
                          }}
                          size="small"
                        >
                          <EditIcon fontSize="small" />
                        </IconButton>
                        <IconButton
                          color="error"
                          onClick={() => handleDelete(sale.id)}
                          sx={{ 
                            backgroundColor: 'rgba(220, 53, 69, 0.1)',
                            '&:hover': { backgroundColor: 'rgba(220, 53, 69, 0.2)' }
                          }}
                          size="small"
                        >
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={8} align="center" sx={{ py: 4 }}>
                    <Typography variant="body1" color="text.secondary">
                      No sales found
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        
        {/* Pagination */}
        <TablePagination
          rowsPerPageOptions={[5, 10, 25, 50]}
          component="div"
          count={filteredSales.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          sx={{
            borderTop: '1px solid rgba(224, 224, 224, 1)',
          }}
        />
      </Paper>

      {/* Add/Edit Sale Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle sx={{ color: '#004b87' }}>
          {editingSale ? 'Edit Sale' : 'New Sale to Merchant'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <FormControl fullWidth size="small">
                <InputLabel>Merchant</InputLabel>
                <Select
                  name="merchantId"
                  value={formData.merchantId}
                  onChange={handleInputChange}
                  label="Merchant"
                >
                  <MenuItem value="">Select Merchant</MenuItem>
                  {merchants.map((merchant) => (
                    <MenuItem key={merchant.id} value={merchant.id}>
                      {merchant.companyName || merchant.name} ({merchant.merchantCode})
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                type="date"
                label="Sale Date"
                name="saleDate"
                value={formData.saleDate}
                onChange={handleInputChange}
                InputLabelProps={{ shrink: true }}
                size="small"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                type="number"
                label="Weight (KG)"
                name="weightKg"
                value={formData.weightKg}
                onChange={handleInputChange}
                size="small"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                type="number"
                label="Sale Rate per Quintal (₹)"
                name="ratePerQuintal"
                value={formData.ratePerQuintal}
                onChange={handleInputChange}
                size="small"
                helperText={`₹${(formData.ratePerQuintal / 100 || 0).toFixed(2)} per kg`}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                type="number"
                label="Avg Purchase Rate (₹)"
                name="purchaseRateAvg"
                value={formData.purchaseRateAvg}
                onChange={handleInputChange}
                size="small"
                helperText="Average purchase rate from farmers"
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth size="small">
                <InputLabel>Payment Method</InputLabel>
                <Select
                  name="paymentMethod"
                  value={formData.paymentMethod}
                  onChange={handleInputChange}
                  label="Payment Method"
                >
                  <MenuItem value="CASH">Cash</MenuItem>
                  <MenuItem value="UPI">UPI</MenuItem>
                  <MenuItem value="BANK_TRANSFER">Bank Transfer</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            {/* Profit Calculation */}
            {formData.weightKg && formData.ratePerQuintal && formData.purchaseRateAvg && (
              <Grid item xs={12}>
                <Paper sx={{ p: 2, backgroundColor: '#e8f5e8', borderRadius: 2 }}>
                  <Typography variant="subtitle2" gutterBottom sx={{ color: '#00a859' }}>
                    Profit Calculation
                  </Typography>
                  <Grid container spacing={1}>
                    <Grid item xs={6}>
                      <Typography variant="body2">Sale Value:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2" align="right">
                        ₹{calculateAmounts().saleValue.toLocaleString('en-IN', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2">Purchase Cost:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2" align="right">
                        ₹{calculateAmounts().purchaseCost.toLocaleString('en-IN', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="subtitle2" fontWeight="bold">Profit:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography 
                        variant="subtitle2" 
                        align="right" 
                        fontWeight="bold"
                        sx={{ color: calculateAmounts().profit >= 0 ? '#00a859' : '#dc3545' }}
                      >
                        ₹{calculateAmounts().profit.toLocaleString('en-IN', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </Typography>
                    </Grid>
                  </Grid>
                </Paper>
              </Grid>
            )}
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} sx={{ color: '#666' }}>
            Cancel
          </Button>
          <Button 
            variant="contained" 
            onClick={handleSubmit}
            sx={{ background: 'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)' }}
          >
            {editingSale ? 'Update' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Sales;