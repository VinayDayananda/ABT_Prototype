import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Grid,
  IconButton,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  InputAdornment,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  CircularProgress,
  Card,
  CardHeader,
  CardContent,
  Divider,
  Tooltip,
  TableSortLabel, // Added
  TablePagination, // Added
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon,
  Download as DownloadIcon,
  People as PeopleIcon,
  AccountBalance as BankIcon,
  Phone as PhoneIcon,
  LocationOn as LocationIcon,
  FilterList as FilterListIcon
} from '@mui/icons-material';
import { farmerService } from '../services/farmerService';

const Farmers = () => {
  const [farmers, setFarmers] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingFarmer, setEditingFarmer] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    fatherName: '',
    mobile: '',
    address: '',
    district: '',
    taluk: '',
    hobli: '',
    village: '',
    bankName: '',
    accountNumber: '',
    ifscCode: '',
    upiId: '',
    districtOther: '',
    talukOther: '',
    hobliOther: ''
  });

  // Sorting state
  const [order, setOrder] = useState('desc');
  const [orderBy, setOrderBy] = useState('farmerCode');
  
  // Pagination state
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  // COMPREHENSIVE LOCATION DATA FOR KARNATAKA
  const locationData = {
    districts: [
      { id: 1, name: 'Tumkur' },
      { id: 2, name: 'Hassan' },
      { id: 3, name: 'Chikkamagaluru' },
      { id: 4, name: 'Mysuru' },
      { id: 5, name: 'Mandya' },
      { id: 99, name: 'Other' }
    ],
    taluksByDistrict: {
      'Tumkur': [
        { id: 1, name: 'Turuvekere' },
        { id: 2, name: 'Tiptur' },
        { id: 3, name: 'Kunigal' },
        { id: 4, name: 'Madhugiri' },
        { id: 5, name: 'Sira' },
        { id: 6, name: 'Gubbi' },
        { id: 7, name: 'Tumkur' },
        { id: 8, name: 'Pavagada' },
        { id: 99, name: 'Other' }
      ],
      'Hassan': [
        { id: 1, name: 'Hassan' },
        { id: 2, name: 'Arsikere' },
        { id: 3, name: 'Sakleshpur' },
        { id: 4, name: 'Belur' },
        { id: 5, name: 'Alur' },
        { id: 6, name: 'Arkalgud' },
        { id: 7, name: 'Channarayapatna' },
        { id: 99, name: 'Other' }
      ],
      'Chikkamagaluru': [
        { id: 1, name: 'Chikkamagaluru' },
        { id: 2, name: 'Kadur' },
        { id: 3, name: 'Mudigere' },
        { id: 4, name: 'Koppa' },
        { id: 5, name: 'Narasimharajapura' },
        { id: 6, name: 'Sringeri' },
        { id: 7, name: 'Tarikere' },
        { id: 99, name: 'Other' }
      ],
      'Mysuru': [
        { id: 1, name: 'Mysuru' },
        { id: 2, name: 'Hunsur' },
        { id: 3, name: 'Periyapatna' },
        { id: 4, name: 'Krishnarajanagara' },
        { id: 5, name: 'Nanjangud' },
        { id: 6, name: 'Tirumakudal Narsipur' },
        { id: 99, name: 'Other' }
      ],
      'Mandya': [
        { id: 1, name: 'Mandya' },
        { id: 2, name: 'Maddur' },
        { id: 3, name: 'Malavalli' },
        { id: 4, name: 'Srirangapatna' },
        { id: 5, name: 'Nagamangala' },
        { id: 6, name: 'Krishnarajpet' },
        { id: 99, name: 'Other' }
      ],
      'Other': [
        { id: 99, name: 'Other' }
      ]
    },
    hoblisByTaluk: {
      'Turuvekere': [
        { id: 1, name: 'Dandinashivara' },
        { id: 2, name: 'Turuvekere' },
        { id: 3, name: 'Nonavinakere' },
        { id: 4, name: 'Honnavalli' },
        { id: 99, name: 'Other' }
      ],
      'Tiptur': [
        { id: 1, name: 'Tiptur' },
        { id: 2, name: 'Ajjampura' },
        { id: 3, name: 'Hiriyur' },
        { id: 99, name: 'Other' }
      ],
      'Kunigal': [
        { id: 1, name: 'Kunigal' },
        { id: 2, name: 'Yedeyur' },
        { id: 3, name: 'Devalapura' },
        { id: 99, name: 'Other' }
      ],
      'Madhugiri': [
        { id: 1, name: 'Madhugiri' },
        { id: 2, name: 'Pavagada' },
        { id: 3, name: 'Koratagere' },
        { id: 99, name: 'Other' }
      ],
      'Sira': [
        { id: 1, name: 'Sira' },
        { id: 2, name: 'Bagepalli' },
        { id: 99, name: 'Other' }
      ],
      'Gubbi': [
        { id: 1, name: 'Gubbi' },
        { id: 2, name: 'Chiknayakanhalli' },
        { id: 99, name: 'Other' }
      ],
      'Hassan': [
        { id: 1, name: 'Hassan' },
        { id: 2, name: 'Chennarayapatna' },
        { id: 3, name: 'Alur' },
        { id: 99, name: 'Other' }
      ],
      'Arsikere': [
        { id: 1, name: 'Arsikere' },
        { id: 2, name: 'Banavara' },
        { id: 99, name: 'Other' }
      ],
      'Sakleshpur': [
        { id: 1, name: 'Sakleshpur' },
        { id: 2, name: 'Yeslur' },
        { id: 99, name: 'Other' }
      ],
      'Chikkamagaluru': [
        { id: 1, name: 'Chikkamagaluru' },
        { id: 2, name: 'Kadur' },
        { id: 3, name: 'Mudigere' },
        { id: 99, name: 'Other' }
      ],
      'Mysuru': [
        { id: 1, name: 'Mysuru' },
        { id: 2, name: 'Hunsur' },
        { id: 3, name: 'Periyapatna' },
        { id: 99, name: 'Other' }
      ],
      'Mandya': [
        { id: 1, name: 'Mandya' },
        { id: 2, name: 'Maddur' },
        { id: 3, name: 'Srirangapatna' },
        { id: 99, name: 'Other' }
      ],
      // Default for "Other" taluk or any taluk not listed
      'Other': [
        { id: 99, name: 'Other' }
      ]
    }
  };

  useEffect(() => {
    fetchFarmers();
  }, []);

  const fetchFarmers = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await farmerService.getAllFarmers();
      setFarmers(response.data);
    } catch (error) {
      console.error('Error fetching farmers:', error);
      setError('Failed to load farmers data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Sorting functions
  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const descendingComparator = (a, b, orderBy) => {
    if (b[orderBy] < a[orderBy]) {
      return -1;
    }
    if (b[orderBy] > a[orderBy]) {
      return 1;
    }
    return 0;
  };

  const getComparator = (order, orderBy) => {
    return order === 'desc'
      ? (a, b) => descendingComparator(a, b, orderBy)
      : (a, b) => -descendingComparator(a, b, orderBy);
  };

  const stableSort = (array, comparator) => {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
      const order = comparator(a[0], b[0]);
      if (order !== 0) return order;
      return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
  };

  // Pagination functions
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const getTaluksForDistrict = (district) => {
    return locationData.taluksByDistrict[district] || locationData.taluksByDistrict['Other'];
  };

  const getHoblisForTaluk = (taluk) => {
    return locationData.hoblisByTaluk[taluk] || locationData.hoblisByTaluk['Other'];
  };

  const handleOpenDialog = (farmer = null) => {
    if (farmer) {
      setEditingFarmer(farmer);
      setFormData({
        name: farmer.name,
        fatherName: farmer.fatherName || '',
        mobile: farmer.mobile,
        address: farmer.address,
        district: farmer.district || '',
        taluk: farmer.taluk || '',
        hobli: farmer.hobli || '',
        village: farmer.village,
        bankName: farmer.bankName,
        accountNumber: farmer.accountNumber,
        ifscCode: farmer.ifscCode,
        upiId: farmer.upiId,
        districtOther: '',
        talukOther: '',
        hobliOther: ''
      });
    } else {
      setEditingFarmer(null);
      setFormData({
        name: '',
        fatherName: '',
        mobile: '',
        address: '',
        district: '',
        taluk: '',
        hobli: '',
        village: '',
        bankName: '',
        accountNumber: '',
        ifscCode: '',
        upiId: '',
        districtOther: '',
        talukOther: '',
        hobliOther: ''
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingFarmer(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleDistrictChange = (e) => {
    const value = e.target.value;
    setFormData(prev => ({
      ...prev,
      district: value,
      taluk: '',
      hobli: '',
      talukOther: '',
      hobliOther: ''
    }));
  };

  const handleTalukChange = (e) => {
    const value = e.target.value;
    setFormData(prev => ({
      ...prev,
      taluk: value,
      hobli: '',
      hobliOther: ''
    }));
  };

  const handleSubmit = async () => {
    try {
      setError(null);
      
      // Prepare final data, using "Other" text fields if selected
      const farmerData = {
        ...formData,
        district: formData.district === 'Other' ? formData.districtOther : formData.district,
        taluk: formData.taluk === 'Other' ? formData.talukOther : formData.taluk,
        hobli: formData.hobli === 'Other' ? formData.hobliOther : formData.hobli,
      };
      
      // Remove temporary helper fields before sending to backend
      delete farmerData.districtOther;
      delete farmerData.talukOther;
      delete farmerData.hobliOther;
      
      if (editingFarmer) {
        await farmerService.updateFarmer(editingFarmer.id, farmerData);
      } else {
        await farmerService.createFarmer(farmerData);
      }
      await fetchFarmers();
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving farmer:', error);
      setError('Failed to save farmer. Please try again.');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this farmer?')) {
      try {
        setError(null);
        await farmerService.deleteFarmer(id);
        await fetchFarmers();
      } catch (error) {
        console.error('Error deleting farmer:', error);
        setError('Failed to delete farmer. Please try again.');
      }
    }
  };

  const exportFarmers = () => {
    const csvContent = farmers.map(farmer => 
      `${farmer.farmerCode},${farmer.name},${farmer.fatherName},${farmer.mobile},${farmer.village},${farmer.district},${farmer.taluk},${farmer.hobli},${farmer.bankName},${farmer.accountNumber},${farmer.totalCopraSold},${farmer.balanceDue}`
    ).join('\n');
    
    const blob = new Blob([`ID,Name,Father Name,Mobile,Village,District,Taluk,Hobli,Bank,Account,Copra Sold,Balance\n${csvContent}`], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'farmers.csv';
    a.click();
  };

  const filteredFarmers = farmers.filter((farmer) => {
    const matchesSearch = farmer.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         farmer.fatherName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         farmer.mobile?.includes(searchTerm) ||
                         farmer.village?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         farmer.farmerCode?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         farmer.district?.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filter === 'all') return matchesSearch;
    if (filter === 'withBalance') return matchesSearch && farmer.balanceDue > 0;
    if (filter === 'active') return matchesSearch && farmer.isActive !== false;
    
    return matchesSearch;
  });

  // Prepare sorted and paginated data
  const sortedFarmers = stableSort(filteredFarmers, getComparator(order, orderBy));
  const paginatedFarmers = sortedFarmers.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  const getRatingColor = (balance) => {
    if (balance === 0) return { bg: '#e8f5e8', color: '#00a859', text: 'Excellent' };
    if (balance < 10000) return { bg: '#e3f2fd', color: '#0066b3', text: 'Good' };
    if (balance < 50000) return { bg: '#fff3cd', color: '#856404', text: 'Average' };
    return { bg: '#ffeaea', color: '#dc3545', text: 'Poor' };
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      {/* Page Header */}
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 'bold', color: '#004b87', mb: 1 }}>
          Farmers Management
        </Typography>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Action Bar */}
      <Card sx={{ mb: 3, borderRadius: 2, boxShadow: '0 2px 15px rgba(0,0,0,0.08)' }}>
        <CardContent sx={{ p: 2 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                placeholder="Search farmers by name, father name, mobile, district..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon sx={{ color: '#666' }} />
                    </InputAdornment>
                  ),
                  sx: {
                    borderRadius: 2,
                    backgroundColor: 'white',
                    '&:hover': {
                      borderColor: '#0066b3'
                    }
                  }
                }}
                variant="outlined"
                size="small"
              />
            </Grid>
            
            <Grid item xs={12} md={2}>
              <FormControl fullWidth size="small">
                <InputLabel sx={{ fontSize: '0.875rem' }}>Filter</InputLabel>
                <Select
                  value={filter}
                  label="Filter"
                  onChange={(e) => setFilter(e.target.value)}
                  sx={{
                    borderRadius: 2,
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#ddd'
                    }
                  }}
                >
                  <MenuItem value="all">All Farmers</MenuItem>
                  <MenuItem value="active">Active</MenuItem>
                  <MenuItem value="withBalance">With Balance</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} md={2}>
              <Button
                fullWidth
                variant="outlined"
                startIcon={<DownloadIcon />}
                onClick={exportFarmers}
                sx={{
                  textTransform: 'none',
                  borderRadius: 2,
                  borderColor: '#0066b3',
                  color: '#0066b3',
                  '&:hover': {
                    borderColor: '#004b87',
                    backgroundColor: 'rgba(0, 102, 179, 0.04)'
                  }
                }}
              >
                Export
              </Button>
            </Grid>
            
            <Grid item xs={12} md={2}>
              <Button
                fullWidth
                variant="contained"
                startIcon={<AddIcon />}
                onClick={() => handleOpenDialog()}
                sx={{
                  textTransform: 'none',
                  borderRadius: 2,
                  background: 'linear-gradient(135deg, #0066b3 0%, #0083d4 100%)',
                  '&:hover': {
                    background: 'linear-gradient(135deg, #004b87 0%, #0066b3 100%)',
                  }
                }}
              >
                Add New Farmer
              </Button>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Farmers Table - UPDATED WITH NEW COLUMNS AND SORTING */}
      <Card sx={{ borderRadius: 2, boxShadow: '0 2px 15px rgba(0,0,0,0.08)', overflow: 'hidden' }}>
        <TableContainer component={Box}>
          <Table>
            <TableHead sx={{ backgroundColor: '#f8f9fa' }}>
              <TableRow>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  <TableSortLabel
                    active={orderBy === 'farmerCode'}
                    direction={orderBy === 'farmerCode' ? order : 'asc'}
                    onClick={() => handleRequestSort('farmerCode')}
                  >
                    ID
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  <TableSortLabel
                    active={orderBy === 'name'}
                    direction={orderBy === 'name' ? order : 'asc'}
                    onClick={() => handleRequestSort('name')}
                  >
                    Name
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  <TableSortLabel
                    active={orderBy === 'fatherName'}
                    direction={orderBy === 'fatherName' ? order : 'asc'}
                    onClick={() => handleRequestSort('fatherName')}
                  >
                    Father's Name
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  <TableSortLabel
                    active={orderBy === 'mobile'}
                    direction={orderBy === 'mobile' ? order : 'asc'}
                    onClick={() => handleRequestSort('mobile')}
                  >
                    Mobile
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  <TableSortLabel
                    active={orderBy === 'village'}
                    direction={orderBy === 'village' ? order : 'asc'}
                    onClick={() => handleRequestSort('village')}
                  >
                    Village
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  Bank Details
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }} align="right">
                  <TableSortLabel
                    active={orderBy === 'totalCopraSold'}
                    direction={orderBy === 'totalCopraSold' ? order : 'asc'}
                    onClick={() => handleRequestSort('totalCopraSold')}
                  >
                    Total Copra (kg)
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }} align="right">
                  <TableSortLabel
                    active={orderBy === 'balanceDue'}
                    direction={orderBy === 'balanceDue' ? order : 'asc'}
                    onClick={() => handleRequestSort('balanceDue')}
                  >
                    Balance (₹)
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }} align="center">
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedFarmers.length > 0 ? (
                paginatedFarmers.map((farmer) => {
                  const rating = getRatingColor(farmer.balanceDue || 0);
                  return (
                    <TableRow 
                      key={farmer.id} 
                      hover 
                      sx={{ 
                        '&:hover': { backgroundColor: '#f8fafc' },
                        borderBottom: '1px solid #f0f0f0'
                      }}
                    >
                      <TableCell sx={{ py: 1.5 }}>
                        <Typography variant="body2" sx={{ 
                          fontWeight: '600', 
                          backgroundColor: '#f0f8ff', 
                          color: '#0066b3',
                          px: 1.5,
                          py: 0.5,
                          borderRadius: 1,
                          display: 'inline-block'
                        }}>
                          {farmer.farmerCode}
                        </Typography>
                      </TableCell>
                      
                      <TableCell sx={{ py: 1.5 }}>
                        <Box>
                          <Typography variant="body1" fontWeight="medium">
                            {farmer.name}
                          </Typography>
                          <Chip
                            label={rating.text}
                            size="small"
                            sx={{
                              mt: 0.5,
                              backgroundColor: rating.bg,
                              color: rating.color,
                              fontSize: '0.65rem',
                              height: '18px',
                              fontWeight: '500'
                            }}
                          />
                        </Box>
                      </TableCell>
                      
                      <TableCell sx={{ py: 1.5 }}>
                        <Typography variant="body2">
                          {farmer.fatherName || '-'}
                        </Typography>
                      </TableCell>
                      
                      <TableCell sx={{ py: 1.5 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <PhoneIcon fontSize="small" sx={{ color: '#666', fontSize: 16 }} />
                          <Typography variant="body2">{farmer.mobile}</Typography>
                        </Box>
                      </TableCell>
                                            
                      <TableCell sx={{ py: 1.5 }}>
                        <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.5 }}>
                          <LocationIcon fontSize="small" sx={{ color: '#666', fontSize: 16, mt: 0.25 }} />
                          <Box>
                            <Typography variant="body2" fontWeight="medium">{farmer.village}</Typography>
                            <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.75rem' }}>
                              {farmer.address}
                            </Typography>
                          </Box>
                        </Box>
                      </TableCell>
                      
                      <TableCell sx={{ py: 1.5 }}>
                        <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.5 }}>
                          <BankIcon fontSize="small" sx={{ color: '#666', fontSize: 16, mt: 0.25 }} />
                          <Box>
                            <Typography variant="body2" sx={{ fontSize: '0.875rem' }}>
                              {farmer.bankName}
                            </Typography>
                            <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.7rem' }}>
                              A/C: {farmer.accountNumber?.slice(-4).padStart(farmer.accountNumber?.length, 'X')}
                            </Typography>
                            {farmer.ifscCode && (
                              <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.7rem', display: 'block' }}>
                                IFSC: {farmer.ifscCode}
                              </Typography>
                            )}
                          </Box>
                        </Box>
                      </TableCell>
                      
                      <TableCell align="right" sx={{ py: 1.5 }}>
                        <Typography variant="body1" fontWeight="medium">
                          {parseFloat(farmer.totalCopraSold || 0).toLocaleString('en-IN', {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 0,
                          })}
                        </Typography>
                      </TableCell>
                      
                      <TableCell align="right" sx={{ py: 1.5 }}>
                        <Typography
                          variant="body1"
                          fontWeight="bold"
                          color={farmer.balanceDue > 0 ? '#dc3545' : '#00a859'}
                        >
                          ₹{parseFloat(farmer.balanceDue || 0).toLocaleString('en-IN', {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 0,
                          })}
                        </Typography>
                      </TableCell>
                      
                      <TableCell align="center" sx={{ py: 1.5 }}>
                        <Box sx={{ display: 'flex', gap: 1, justifyContent: 'center' }}>
                          <Tooltip title="Edit">
                            <IconButton
                              size="small"
                              onClick={() => handleOpenDialog(farmer)}
                              sx={{ 
                                backgroundColor: 'rgba(0, 102, 179, 0.1)',
                                color: '#0066b3',
                                '&:hover': { 
                                  backgroundColor: 'rgba(0, 102, 179, 0.2)' 
                                }
                              }}
                            >
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          
                          <Tooltip title="Delete">
                            <IconButton
                              size="small"
                              onClick={() => handleDelete(farmer.id)}
                              sx={{ 
                                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                                color: '#dc3545',
                                '&:hover': { 
                                  backgroundColor: 'rgba(220, 53, 69, 0.2)' 
                                }
                              }}
                            >
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      </TableCell>
                    </TableRow>
                  );
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={9} align="center" sx={{ py: 4 }}>
                    <Typography variant="body1" color="text.secondary">
                      No farmers found
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        
        {/* Pagination */}
        <TablePagination
          rowsPerPageOptions={[5, 10, 25, 50]}
          component="div"
          count={filteredFarmers.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          sx={{
            borderTop: '1px solid rgba(224, 224, 224, 1)',
          }}
        />
      </Card>

      {/* Add/Edit Farmer Dialog - UPDATED WITH NEW FIELDS */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle sx={{ 
          color: '#004b87',
          borderBottom: '1px solid #eee',
          pb: 2
        }}>
          {editingFarmer ? 'Edit Farmer Details' : 'Add New Farmer'}
        </DialogTitle>
        <DialogContent sx={{ pt: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Farmer's Name *"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
                size="small"
                sx={{ mb: 2 }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Father's Name *"
                name="fatherName"
                value={formData.fatherName}
                onChange={handleInputChange}
                required
                size="small"
                sx={{ mb: 2 }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Mobile Number *"
                name="mobile"
                value={formData.mobile}
                onChange={handleInputChange}
                required
                size="small"
                sx={{ mb: 2 }}
              />
            </Grid>
            
            {/* District Field with "Other" option */}
            <Grid item xs={12} md={6}>
              <FormControl fullWidth size="small" sx={{ mb: 2 }}>
                <InputLabel>District *</InputLabel>
                <Select
                  name="district"
                  value={formData.district}
                  label="District *"
                  onChange={handleDistrictChange}
                  required
                >
                  <MenuItem value="">Select District</MenuItem>
                  {locationData.districts.map((district) => (
                    <MenuItem key={district.id} value={district.name}>
                      {district.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              {formData.district === 'Other' && (
                <TextField
                  fullWidth
                  label="Specify District"
                  name="districtOther"
                  value={formData.districtOther}
                  onChange={handleInputChange}
                  size="small"
                  sx={{ mb: 2 }}
                  required
                />
              )}
            </Grid>
            
            {/* Taluk Field (dependent on District) */}
            <Grid item xs={12} md={6}>
              <FormControl fullWidth size="small" sx={{ mb: 2 }}>
                <InputLabel>Taluk *</InputLabel>
                <Select
                  name="taluk"
                  value={formData.taluk}
                  label="Taluk *"
                  onChange={handleTalukChange}
                  required
                  disabled={!formData.district}
                >
                  <MenuItem value="">Select Taluk</MenuItem>
                  {getTaluksForDistrict(formData.district).map((taluk) => (
                    <MenuItem key={taluk.id} value={taluk.name}>
                      {taluk.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              {formData.taluk === 'Other' && (
                <TextField
                  fullWidth
                  label="Specify Taluk"
                  name="talukOther"
                  value={formData.talukOther}
                  onChange={handleInputChange}
                  size="small"
                  sx={{ mb: 2 }}
                  required
                />
              )}
            </Grid>
            
            {/* Hobli Field (dependent on Taluk) */}
            <Grid item xs={12} md={6}>
              <FormControl fullWidth size="small" sx={{ mb: 2 }}>
                <InputLabel>Hobli *</InputLabel>
                <Select
                  name="hobli"
                  value={formData.hobli}
                  label="Hobli *"
                  onChange={(e) => setFormData(prev => ({ ...prev, hobli: e.target.value }))}
                  required
                  disabled={!formData.taluk}
                >
                  <MenuItem value="">Select Hobli</MenuItem>
                  {getHoblisForTaluk(formData.taluk).map((hobli) => (
                    <MenuItem key={hobli.id} value={hobli.name}>
                      {hobli.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              {formData.hobli === 'Other' && (
                <TextField
                  fullWidth
                  label="Specify Hobli"
                  name="hobliOther"
                  value={formData.hobliOther}
                  onChange={handleInputChange}
                  size="small"
                  sx={{ mb: 2 }}
                  required
                />
              )}
            </Grid>
            
            {/* Village Field */}
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Village *"
                name="village"
                value={formData.village}
                onChange={handleInputChange}
                required
                size="small"
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Complete Address"
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                multiline
                rows={2}
                size="small"
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <Typography variant="subtitle2" sx={{ color: '#004b87', mb: 1 }}>
                Bank Details
              </Typography>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Bank Name"
                name="bankName"
                value={formData.bankName}
                onChange={handleInputChange}
                size="small"
                sx={{ mb: 2 }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Account Number"
                name="accountNumber"
                value={formData.accountNumber}
                onChange={handleInputChange}
                size="small"
                sx={{ mb: 2 }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="IFSC Code"
                name="ifscCode"
                value={formData.ifscCode}
                onChange={handleInputChange}
                size="small"
                sx={{ mb: 2 }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="UPI ID"
                name="upiId"
                value={formData.upiId}
                onChange={handleInputChange}
                size="small"
                sx={{ mb: 2 }}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button 
            onClick={handleCloseDialog} 
            sx={{ 
              color: '#666',
              textTransform: 'none'
            }}
          >
            Cancel
          </Button>
          <Button 
            variant="contained" 
            onClick={handleSubmit}
            sx={{ 
              textTransform: 'none',
              background: 'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)',
              '&:hover': {
                background: 'linear-gradient(135deg, #00994d 0%, #00b35d 100%)',
              }
            }}
          >
            {editingFarmer ? 'Update Farmer' : 'Save Farmer'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Farmers;