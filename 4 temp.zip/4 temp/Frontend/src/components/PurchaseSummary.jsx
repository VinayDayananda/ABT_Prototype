import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  TextField,
  Button,
  Card,
  CardContent,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import {
  Search as SearchIcon,
  FilterList as FilterIcon,
  Download as DownloadIcon,
  Visibility as ViewIcon,
  Receipt as ReceiptIcon,
  LocalShipping as BagIcon,
  Scale as ScaleIcon
} from '@mui/icons-material';
import { purchaseService } from '../services/purchaseService';
import { farmerService } from '../services/farmerService';

const PurchaseSummary = () => {
  const [purchases, setPurchases] = useState([]);
  const [filteredPurchases, setFilteredPurchases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [openDetails, setOpenDetails] = useState(false);
  const [selectedPurchase, setSelectedPurchase] = useState(null);

  useEffect(() => {
    fetchPurchases();
  }, []);

  useEffect(() => {
    filterPurchases();
  }, [searchTerm, dateFilter, startDate, endDate, purchases]);

  const fetchPurchases = async () => {
    try {
      setLoading(true);
      const response = await purchaseService.getAllPurchases();
      setPurchases(response.data || []);
      setFilteredPurchases(response.data || []);
    } catch (error) {
      console.error('Error fetching purchases:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterPurchases = () => {
    let filtered = [...purchases];

    // Filter by search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(purchase =>
        purchase.purchaseId?.toLowerCase().includes(term) ||
        purchase.farmer?.name?.toLowerCase().includes(term) ||
        purchase.farmer?.farmerCode?.toLowerCase().includes(term)
      );
    }

    // Filter by date
    if (dateFilter === 'custom' && startDate && endDate) {
      filtered = filtered.filter(purchase => {
        const purchaseDate = new Date(purchase.purchaseDate);
        const start = new Date(startDate);
        const end = new Date(endDate);
        return purchaseDate >= start && purchaseDate <= end;
      });
    } else if (dateFilter === 'today') {
      const today = new Date().toISOString().split('T')[0];
      filtered = filtered.filter(purchase =>
        purchase.purchaseDate === today
      );
    } else if (dateFilter === 'week') {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      filtered = filtered.filter(purchase => {
        const purchaseDate = new Date(purchase.purchaseDate);
        return purchaseDate >= weekAgo;
      });
    } else if (dateFilter === 'month') {
      const monthAgo = new Date();
      monthAgo.setMonth(monthAgo.getMonth() - 1);
      filtered = filtered.filter(purchase => {
        const purchaseDate = new Date(purchase.purchaseDate);
        return purchaseDate >= monthAgo;
      });
    }

    setFilteredPurchases(filtered);
  };

  const calculateStats = () => {
    const stats = {
      totalPurchases: filteredPurchases.length,
      totalWeight: 0,
      totalAmount: 0,
      totalLoanDeduction: 0,
      totalCommission: 0,
      totalNetPayment: 0
    };

    filteredPurchases.forEach(purchase => {
      stats.totalWeight += parseFloat(purchase.totalWeightKg) || 0;
      stats.totalAmount += parseFloat(purchase.totalAmount) || 0;
      stats.totalLoanDeduction += parseFloat(purchase.loanDeduction) || 0;
      stats.totalCommission += parseFloat(purchase.commissionAmount) || 0;
      stats.totalNetPayment += parseFloat(purchase.netPayment) || 0;
    });

    return stats;
  };

  const handleViewDetails = (purchase) => {
    setSelectedPurchase(purchase);
    setOpenDetails(true);
  };

  const stats = calculateStats();

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ mb: 4, color: '#004b87' }}>
        <ReceiptIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
        Purchase History
      </Typography>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={2}>
          <Card sx={{ background: 'linear-gradient(135deg, #0066b3 0%, #0083d4 100%)', color: 'white' }}>
            <CardContent>
              <Typography variant="h4" fontWeight="bold">
                {stats.totalPurchases}
              </Typography>
              <Typography variant="body2">Total Purchases</Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={2}>
          <Card sx={{ background: 'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)', color: 'white' }}>
            <CardContent>
              <Typography variant="h4" fontWeight="bold">
                {stats.totalWeight.toFixed(2)}
              </Typography>
              <Typography variant="body2">Total Weight (kg)</Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={2}>
          <Card sx={{ background: 'linear-gradient(135deg, #ff6b00 0%, #ff8c33 100%)', color: 'white' }}>
            <CardContent>
              <Typography variant="h4" fontWeight="bold">
                ₹{stats.totalAmount.toLocaleString('en-IN')}
              </Typography>
              <Typography variant="body2">Total Amount</Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={2}>
          <Card sx={{ background: 'linear-gradient(135deg, #dc3545 0%, #e35d6a 100%)', color: 'white' }}>
            <CardContent>
              <Typography variant="h4" fontWeight="bold">
                ₹{stats.totalLoanDeduction.toLocaleString('en-IN')}
              </Typography>
              <Typography variant="body2">Loan Deduction</Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={2}>
          <Card sx={{ background: 'linear-gradient(135deg, #856404 0%, #a17c1b 100%)', color: 'white' }}>
            <CardContent>
              <Typography variant="h4" fontWeight="bold">
                ₹{stats.totalCommission.toLocaleString('en-IN')}
              </Typography>
              <Typography variant="body2">Total Commission</Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={2}>
          <Card sx={{ background: 'linear-gradient(135deg, #6610f2 0%, #7c3aed 100%)', color: 'white' }}>
            <CardContent>
              <Typography variant="h4" fontWeight="bold">
                ₹{stats.totalNetPayment.toLocaleString('en-IN')}
              </Typography>
              <Typography variant="body2">Net Payment</Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Filters */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              placeholder="Search by bill no, farmer name or code..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: <SearchIcon sx={{ color: '#666', mr: 1 }} />
              }}
              size="small"
            />
          </Grid>
          
          <Grid item xs={12} md={3}>
            <FormControl fullWidth size="small">
              <InputLabel>Date Filter</InputLabel>
              <Select
                value={dateFilter}
                label="Date Filter"
                onChange={(e) => setDateFilter(e.target.value)}
              >
                <MenuItem value="all">All Time</MenuItem>
                <MenuItem value="today">Today</MenuItem>
                <MenuItem value="week">Last 7 Days</MenuItem>
                <MenuItem value="month">Last 30 Days</MenuItem>
                <MenuItem value="custom">Custom Range</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          {dateFilter === 'custom' && (
            <>
              <Grid item xs={12} md={2}>
                <TextField
                  fullWidth
                  type="date"
                  label="Start Date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  size="small"
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid item xs={12} md={2}>
                <TextField
                  fullWidth
                  type="date"
                  label="End Date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  size="small"
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
            </>
          )}
          
          <Grid item xs={12} md={3}>
            <Button
              fullWidth
              variant="outlined"
              startIcon={<DownloadIcon />}
              onClick={() => {/* Export functionality */}}
              size="small"
            >
              Export Data
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* Purchases Table */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead sx={{ backgroundColor: '#f8f9fa' }}>
            <TableRow>
              <TableCell sx={{ fontWeight: '600' }}>Bill No</TableCell>
              <TableCell sx={{ fontWeight: '600' }}>Date</TableCell>
              <TableCell sx={{ fontWeight: '600' }}>Farmer</TableCell>
              <TableCell sx={{ fontWeight: '600' }}>Products</TableCell>
              <TableCell sx={{ fontWeight: '600' }} align="right">Weight (kg)</TableCell>
              <TableCell sx={{ fontWeight: '600' }} align="right">Total Amount</TableCell>
              <TableCell sx={{ fontWeight: '600' }} align="right">Loan Deduction</TableCell>
              <TableCell sx={{ fontWeight: '600' }} align="right">Net Payment</TableCell>
              <TableCell sx={{ fontWeight: '600' }}>Payment</TableCell>
              <TableCell sx={{ fontWeight: '600' }} align="center">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredPurchases.length > 0 ? (
              filteredPurchases.map((purchase) => (
                <TableRow key={purchase.id} hover>
                  <TableCell>
                    <Typography variant="body2" sx={{ fontWeight: '600', color: '#0066b3' }}>
                      {purchase.purchaseId}
                    </Typography>
                  </TableCell>
                  
                  <TableCell>
                    {new Date(purchase.purchaseDate).toLocaleDateString()}
                  </TableCell>
                  
                  <TableCell>
                    <Box>
                      <Typography variant="body2" fontWeight="medium">
                        {purchase.farmer?.name}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {purchase.farmer?.farmerCode}
                      </Typography>
                    </Box>
                  </TableCell>
                  
                  <TableCell>
                    <Box>
                      {purchase.purchaseItems?.map((item, index) => (
                        <Chip
                          key={index}
                          label={`${item.productType}: ${item.netWeight}kg`}
                          size="small"
                          sx={{ mr: 0.5, mb: 0.5 }}
                        />
                      ))}
                    </Box>
                  </TableCell>
                  
                  <TableCell align="right">
                    {parseFloat(purchase.totalWeightKg || 0).toFixed(2)}
                  </TableCell>
                  
                  <TableCell align="right">
                    <Typography fontWeight="medium">
                      ₹{parseFloat(purchase.totalAmount || 0).toLocaleString('en-IN')}
                    </Typography>
                  </TableCell>
                  
                  <TableCell align="right">
                    {purchase.loanDeduction > 0 ? (
                      <Typography color="#dc3545" fontWeight="medium">
                        ₹{parseFloat(purchase.loanDeduction || 0).toLocaleString('en-IN')}
                      </Typography>
                    ) : (
                      <Typography color="text.secondary">-</Typography>
                    )}
                  </TableCell>
                  
                  <TableCell align="right">
                    <Typography fontWeight="bold" color="#00a859">
                      ₹{parseFloat(purchase.netPayment || 0).toLocaleString('en-IN')}
                    </Typography>
                  </TableCell>
                  
                  <TableCell>
                    <Chip
                      label={purchase.paymentMethod || 'CASH'}
                      size="small"
                      sx={{
                        backgroundColor: purchase.paymentMethod === 'CASH' ? '#e8f5e8' : '#e3f2fd',
                        color: purchase.paymentMethod === 'CASH' ? '#00a859' : '#0066b3'
                      }}
                    />
                  </TableCell>
                  
                  <TableCell align="center">
                    <IconButton
                      size="small"
                      onClick={() => handleViewDetails(purchase)}
                      sx={{ color: '#0066b3' }}
                    >
                      <ViewIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={10} align="center" sx={{ py: 4 }}>
                  <Typography color="text.secondary">
                    No purchases found
                  </Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Purchase Details Dialog */}
      <Dialog open={openDetails} onClose={() => setOpenDetails(false)} maxWidth="md" fullWidth>
        {selectedPurchase && (
          <>
            <DialogTitle sx={{ color: '#004b87' }}>
              Purchase Details - {selectedPurchase.purchaseId}
            </DialogTitle>
            <DialogContent>
              <Grid container spacing={2} sx={{ mt: 1 }}>
                <Grid item xs={12}>
                  <Card variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="h6" sx={{ mb: 2 }}>Farmer Information</Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">Name:</Typography>
                        <Typography variant="body1">{selectedPurchase.farmer?.name}</Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">Father:</Typography>
                        <Typography variant="body1">{selectedPurchase.farmer?.fatherName || '-'}</Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">Mobile:</Typography>
                        <Typography variant="body1">{selectedPurchase.farmer?.mobile}</Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">Village:</Typography>
                        <Typography variant="body1">{selectedPurchase.farmer?.village}</Typography>
                      </Grid>
                    </Grid>
                  </Card>
                </Grid>

                <Grid item xs={12}>
                  <Card variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="h6" sx={{ mb: 2 }}>Product Details</Typography>
                    <TableContainer>
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell>Product Type</TableCell>
                            <TableCell align="right">Bags</TableCell>
                            <TableCell align="right">Weight/Bag</TableCell>
                            <TableCell align="right">Extra</TableCell>
                            <TableCell align="right">Deduction</TableCell>
                            <TableCell align="right">Net Weight</TableCell>
                            <TableCell align="right">Rate</TableCell>
                            <TableCell align="right">Amount</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {selectedPurchase.purchaseItems?.map((item, index) => (
                            <TableRow key={index}>
                              <TableCell>{item.productType}</TableCell>
                              <TableCell align="right">{item.numberOfBags || '-'}</TableCell>
                              <TableCell align="right">{item.weightPerBag || '-'}</TableCell>
                              <TableCell align="right">{item.extraQuantity || 0}</TableCell>
                              <TableCell align="right">{item.qualityDeduction || 0}</TableCell>
                              <TableCell align="right">{item.netWeight}</TableCell>
                              <TableCell align="right">₹{item.ratePerKg}</TableCell>
                              <TableCell align="right">₹{item.amount}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </Card>
                </Grid>

                <Grid item xs={12}>
                  <Card variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="h6" sx={{ mb: 2 }}>Payment Summary</Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">Total Weight:</Typography>
                        <Typography variant="body1">
                          {selectedPurchase.totalWeightKg} kg ({selectedPurchase.totalWeightQuintal} quintal)
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">Total Amount:</Typography>
                        <Typography variant="body1" fontWeight="bold">
                          ₹{parseFloat(selectedPurchase.totalAmount || 0).toLocaleString('en-IN')}
                        </Typography>
                      </Grid>
                      
                      {selectedPurchase.loan && (
                        <>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">Loan Deduction:</Typography>
                            <Typography variant="body1" color="#dc3545">
                              ₹{parseFloat(selectedPurchase.loanDeduction || 0).toLocaleString('en-IN')}
                            </Typography>
                          </Grid>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">Commission ({selectedPurchase.commissionRate}%):</Typography>
                            <Typography variant="body1" color="#856404">
                              ₹{parseFloat(selectedPurchase.commissionAmount || 0).toLocaleString('en-IN')}
                            </Typography>
                          </Grid>
                        </>
                      )}
                      
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">Net Payment:</Typography>
                        <Typography variant="body1" fontWeight="bold" color="#00a859">
                          ₹{parseFloat(selectedPurchase.netPayment || 0).toLocaleString('en-IN')}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">Amount Paid:</Typography>
                        <Typography variant="body1" color="#00a859">
                          ₹{parseFloat(selectedPurchase.amountPaid || 0).toLocaleString('en-IN')}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">Balance:</Typography>
                        <Typography variant="body1" color="#ff6b00">
                          ₹{parseFloat(selectedPurchase.balanceAmount || 0).toLocaleString('en-IN')}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">Payment Method:</Typography>
                        <Typography variant="body1">{selectedPurchase.paymentMethod}</Typography>
                      </Grid>
                      
                      {selectedPurchase.paymentReference && (
                        <Grid item xs={12}>
                          <Typography variant="body2" color="text.secondary">Payment Reference:</Typography>
                          <Typography variant="body1">{selectedPurchase.paymentReference}</Typography>
                        </Grid>
                      )}
                      
                      {selectedPurchase.notes && (
                        <Grid item xs={12}>
                          <Typography variant="body2" color="text.secondary">Notes:</Typography>
                          <Typography variant="body1">{selectedPurchase.notes}</Typography>
                        </Grid>
                      )}
                    </Grid>
                  </Card>
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setOpenDetails(false)}>Close</Button>
              <Button
                variant="contained"
                onClick={() => {
                  // Print functionality
                  window.print();
                }}
              >
                Print Bill
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
};

export default PurchaseSummary;