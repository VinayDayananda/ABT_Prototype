import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Paper,
  Typography,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Card,
  CardContent,
  CircularProgress,
  Alert,
} from '@mui/material';
import {
  Assessment as ReportIcon,
  TrendingUp as TrendIcon,
  Download as DownloadIcon,
  BarChart as ChartIcon,
  PieChart as PieChartIcon,
  AttachMoney as MoneyIcon,
  ShoppingCart as CartIcon,
} from '@mui/icons-material';
import Chip from '@mui/material/Chip';
import { Line, Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { dashboardService } from '../services/dashboardService';
import { purchaseService } from '../services/purchaseService';
import { salesService } from '../services/salesService';
import { farmerService } from '../services/farmerService';
import { format, subDays, subMonths, subYears, startOfMonth, endOfMonth } from 'date-fns';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const Reports = () => {
  const [reportPeriod, setReportPeriod] = useState('month');
  const [dashboardStats, setDashboardStats] = useState(null);
  const [purchases, setPurchases] = useState([]);
  const [sales, setSales] = useState([]);
  const [farmers, setFarmers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchReportData();
  }, [reportPeriod]);

  const fetchReportData = async () => {
    try {
      setLoading(true);
      setError(null);

      let startDate, endDate;
      const today = new Date();

      switch (reportPeriod) {
        case 'today':
          startDate = format(today, 'yyyy-MM-dd');
          endDate = format(today, 'yyyy-MM-dd');
          break;
        case 'week':
          startDate = format(subDays(today, 7), 'yyyy-MM-dd');
          endDate = format(today, 'yyyy-MM-dd');
          break;
        case 'month':
          startDate = format(startOfMonth(today), 'yyyy-MM-dd');
          endDate = format(endOfMonth(today), 'yyyy-MM-dd');
          break;
        case 'quarter':
          startDate = format(subMonths(today, 3), 'yyyy-MM-dd');
          endDate = format(today, 'yyyy-MM-dd');
          break;
        case 'year':
          startDate = format(subYears(today, 1), 'yyyy-MM-dd');
          endDate = format(today, 'yyyy-MM-dd');
          break;
        default:
          startDate = format(startOfMonth(today), 'yyyy-MM-dd');
          endDate = format(endOfMonth(today), 'yyyy-MM-dd');
      }

      const [statsRes, purchasesRes, salesRes, farmersRes] = await Promise.all([
        dashboardService.getDashboardStats(),
        purchaseService.getPurchasesByDateRange(startDate, endDate),
        salesService.getSalesByDateRange(startDate, endDate),
        farmerService.getAllFarmers(),
      ]);

      setDashboardStats(statsRes.data);
      setPurchases(purchasesRes.data || []);
      setSales(salesRes.data || []);
      setFarmers(farmersRes.data || []);
    } catch (error) {
      console.error('Error fetching report data:', error);
      setError('Failed to load report data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const calculateReportStats = () => {
    const totalCopra = purchases.reduce((sum, p) => sum + (parseFloat(p.weightKg) || 0), 0);
    const totalPaid = purchases.reduce((sum, p) => sum + (parseFloat(p.advancePaid) || 0), 0);
    const totalPending = purchases.reduce((sum, p) => sum + (parseFloat(p.balanceDue) || 0), 0);
    const totalSales = sales.reduce((sum, s) => sum + (parseFloat(s.totalAmount) || 0), 0);
    const totalProfit = sales.reduce((sum, s) => sum + (parseFloat(s.profit) || 0), 0);
    const totalLoans = farmers.reduce((sum, f) => sum + (parseFloat(f.balanceDue) || 0), 0);

    return {
      totalCopra,
      totalPaid,
      totalPending,
      totalSales,
      totalProfit,
      totalLoans,
    };
  };

  const prepareMonthlyPurchaseChart = () => {
    const monthlyData = {};
    
    purchases.forEach(purchase => {
      const month = format(new Date(purchase.purchaseDate), 'MMM');
      const weight = parseFloat(purchase.weightKg) || 0;
      monthlyData[month] = (monthlyData[month] || 0) + weight;
    });

    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    
    return {
      labels: months,
      datasets: [{
        label: 'Copra Purchased (kg)',
        data: months.map(month => monthlyData[month] || 0),
        borderColor: '#0066b3',
        backgroundColor: 'rgba(0, 102, 179, 0.1)',
        borderWidth: 3,
        fill: true,
        tension: 0.4,
      }],
    };
  };

  const prepareTopFarmersChart = () => {
    const farmerStats = farmers.map(farmer => ({
      name: farmer.name,
      totalCopra: parseFloat(farmer.totalCopraSold) || 0,
    }));

    const topFarmers = farmerStats
      .sort((a, b) => b.totalCopra - a.totalCopra)
      .slice(0, 5);

    return {
      labels: topFarmers.map(f => f.name),
      datasets: [{
        label: 'Copra (kg)',
        data: topFarmers.map(f => f.totalCopra),
        backgroundColor: '#00a859',
        borderWidth: 0,
        borderRadius: 4,
      }],
    };
  };

  const exportReport = () => {
    const stats = calculateReportStats();
    const periodText = {
      today: 'Today',
      week: 'This Week',
      month: 'This Month',
      quarter: 'This Quarter',
      year: 'This Year',
    }[reportPeriod];

    const reportContent = `
Ambika Traders - Copra Management System Report
Report Period: ${periodText}
Generated on: ${format(new Date(), 'dd/MM/yyyy HH:mm')}

SUMMARY STATISTICS:
-------------------
Total Copra Purchased: ${stats.totalCopra.toLocaleString()} kg
Total Amount Paid: ₹${stats.totalPaid.toLocaleString()}
Pending Payments: ₹${stats.totalPending.toLocaleString()}
Total Sales Revenue: ₹${stats.totalSales.toLocaleString()}
Total Profit: ₹${stats.totalProfit.toLocaleString()}
Loan Amount Given: ₹${stats.totalLoans.toLocaleString()}

PURCHASE TRANSACTIONS (${purchases.length}):
------------------------------------------
${purchases.map(p => `${p.purchaseId} | ${format(new Date(p.purchaseDate), 'dd/MM/yyyy')} | ${p.farmerName} | ${p.weightKg} kg | ₹${p.totalAmount} | ${p.status}`).join('\n')}

SALES TRANSACTIONS (${sales.length}):
-----------------------------------
${sales.map(s => `${s.saleId} | ${format(new Date(s.saleDate), 'dd/MM/yyyy')} | ${s.merchantName} | ${s.weightKg} kg | ₹${s.totalAmount} | Profit: ₹${s.profit}`).join('\n')}

TOP FARMERS BY VOLUME:
----------------------
${farmers
  .sort((a, b) => (parseFloat(b.totalCopraSold) || 0) - (parseFloat(a.totalCopraSold) || 0))
  .slice(0, 10)
  .map((f, i) => `${i + 1}. ${f.name}: ${parseFloat(f.totalCopraSold || 0).toLocaleString()} kg`)
  .join('\n')}
    `.trim();

    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ambika-traders-report-${format(new Date(), 'yyyy-MM-dd')}.txt`;
    a.click();
  };

  const stats = calculateReportStats();

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ color: '#004b87' }}>
          <ReportIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
          Reports & Analytics
        </Typography>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <FormControl size="small" sx={{ minWidth: 200 }}>
            <InputLabel>Report Period</InputLabel>
            <Select
              value={reportPeriod}
              label="Report Period"
              onChange={(e) => setReportPeriod(e.target.value)}
            >
              <MenuItem value="today">Today</MenuItem>
              <MenuItem value="week">This Week</MenuItem>
              <MenuItem value="month">This Month</MenuItem>
              <MenuItem value="quarter">This Quarter</MenuItem>
              <MenuItem value="year">This Year</MenuItem>
              <MenuItem value="custom">Custom Range</MenuItem>
            </Select>
          </FormControl>
          <Button
            variant="outlined"
            startIcon={<DownloadIcon />}
            onClick={exportReport}
            sx={{ color: '#0066b3', borderColor: '#0066b3' }}
          >
            Export Report
          </Button>
        </Box>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Summary Stats */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ borderLeft: '4px solid #0066b3' }}>
            <CardContent>
              <Typography variant="h4" sx={{ color: '#0066b3', mb: 1 }}>
                {stats.totalCopra.toLocaleString()} kg
              </Typography>
              <Typography variant="body2" color="text.secondary">
                <CartIcon sx={{ fontSize: 16, mr: 0.5, verticalAlign: 'middle' }} />
                Total Copra Purchased
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ borderLeft: '4px solid #00a859' }}>
            <CardContent>
              <Typography variant="h4" sx={{ color: '#00a859', mb: 1 }}>
                ₹{stats.totalPaid.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                <MoneyIcon sx={{ fontSize: 16, mr: 0.5, verticalAlign: 'middle' }} />
                Total Amount Paid
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ borderLeft: '4px solid #ff6b00' }}>
            <CardContent>
              <Typography variant="h4" sx={{ color: '#ff6b00', mb: 1 }}>
                ₹{stats.totalPending.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                <MoneyIcon sx={{ fontSize: 16, mr: 0.5, verticalAlign: 'middle' }} />
                Pending Payments
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ borderLeft: '4px solid #0083d4' }}>
            <CardContent>
              <Typography variant="h4" sx={{ color: '#0083d4', mb: 1 }}>
                ₹{stats.totalLoans.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                <MoneyIcon sx={{ fontSize: 16, mr: 0.5, verticalAlign: 'middle' }} />
                Loan Amount Given
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Charts */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#004b87' }}>
              <TrendIcon sx={{ mr: 1 }} />
              Monthly Copra Purchase Trend
            </Typography>
            <Box sx={{ height: 300 }}>
              <Line
                data={prepareMonthlyPurchaseChart()}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'top',
                    },
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      grid: {
                        color: 'rgba(0,0,0,0.05)',
                      },
                    },
                    x: {
                      grid: {
                        color: 'rgba(0,0,0,0.05)',
                      },
                    },
                  },
                }}
              />
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#004b87' }}>
              <ChartIcon sx={{ mr: 1 }} />
              Top Farmers by Volume
            </Typography>
            <Box sx={{ height: 300 }}>
              <Bar
                data={prepareTopFarmersChart()}
                options={{
                  indexAxis: 'y',
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'top',
                    },
                  },
                  scales: {
                    x: {
                      beginAtZero: true,
                      grid: {
                        color: 'rgba(0,0,0,0.05)',
                      },
                    },
                    y: {
                      grid: {
                        color: 'rgba(0,0,0,0.05)',
                      },
                    },
                  },
                }}
              />
            </Box>
          </Paper>
        </Grid>
      </Grid>

      {/* Payment History Table */}
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#004b87', mb: 2 }}>
          <MoneyIcon sx={{ mr: 1 }} />
          Payment History
        </Typography>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ bgcolor: '#f8f9fa' }}>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Date</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Farmer Name</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Amount (₹)</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Type</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Balance Before</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Balance After</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Reference</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {purchases.length > 0 ? (
                purchases
                  .filter(p => p.advancePaid > 0)
                  .sort((a, b) => new Date(b.purchaseDate) - new Date(a.purchaseDate))
                  .slice(0, 10)
                  .map((purchase, index) => (
                    <TableRow key={index} hover>
                      <TableCell>
                        {format(new Date(purchase.purchaseDate), 'dd/MM/yyyy')}
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" fontWeight="medium">
                          {purchase.farmerName}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {purchase.farmerCode}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography fontWeight="medium" color="#00a859">
                          ₹{parseFloat(purchase.advancePaid || 0).toLocaleString('en-IN', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {purchase.paymentMethod === 'CASH' ? 'Cash' : 
                           purchase.paymentMethod === 'UPI' ? 'UPI' : 'Bank Transfer'}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2">
                          ₹{parseFloat(purchase.totalAmount || 0).toLocaleString('en-IN', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography 
                          variant="body2"
                          color={purchase.balanceDue > 0 ? 'error' : 'success'}
                        >
                          ₹{parseFloat(purchase.balanceDue || 0).toLocaleString('en-IN', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" color="text.secondary">
                          {purchase.purchaseId}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} align="center" sx={{ py: 4 }}>
                    <Typography variant="body1" color="text.secondary">
                      No payment history found for the selected period
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
    </Box>
  );
};

export default Reports;