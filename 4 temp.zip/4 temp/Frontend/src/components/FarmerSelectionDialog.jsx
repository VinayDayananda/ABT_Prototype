import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Box,
  Chip,
  IconButton,
  InputAdornment,
  CircularProgress,
  Avatar
} from '@mui/material';
import {
  Search as SearchIcon,
  Person as PersonIcon,
  Phone as PhoneIcon,
  LocationOn as LocationIcon,
  CheckCircle as CheckCircleIcon,
  AccountBalance as BankIcon
} from '@mui/icons-material';
import { farmerService } from '../services/farmerService';

const FarmerSelectionDialog = ({ open, onClose, onSelectFarmer, excludeFarmerId = null }) => {
  const [farmers, setFarmers] = useState([]);
  const [filteredFarmers, setFilteredFarmers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFarmer, setSelectedFarmer] = useState(null);

  useEffect(() => {
    if (open) {
      fetchFarmers();
    }
  }, [open]);

  const fetchFarmers = async () => {
    try {
      setLoading(true);
      const response = await farmerService.getAllFarmers();
      let allFarmers = response.data || [];
      
      // Exclude the specified farmer if provided (for edit mode)
      if (excludeFarmerId) {
        allFarmers = allFarmers.filter(farmer => farmer.id !== excludeFarmerId);
      }
      
      setFarmers(allFarmers);
      setFilteredFarmers(allFarmers);
    } catch (error) {
      console.error('Error fetching farmers:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredFarmers(farmers);
    } else {
      const term = searchTerm.toLowerCase();
      const filtered = farmers.filter(farmer => 
        farmer.name?.toLowerCase().includes(term) ||
        farmer.mobile?.includes(term) ||
        farmer.farmerCode?.toLowerCase().includes(term) ||
        farmer.village?.toLowerCase().includes(term) ||
        farmer.district?.toLowerCase().includes(term) ||
        farmer.taluk?.toLowerCase().includes(term) ||
        farmer.hobli?.toLowerCase().includes(term)
      );
      setFilteredFarmers(filtered);
    }
  }, [searchTerm, farmers]);

  const handleSelectFarmer = (farmer) => {
    setSelectedFarmer(farmer);
  };

  const handleConfirmSelection = () => {
    if (selectedFarmer) {
      onSelectFarmer(selectedFarmer);
      handleClose();
    }
  };

  const handleClose = () => {
    setSelectedFarmer(null);
    setSearchTerm('');
    onClose();
  };

  const getBalanceColor = (balance) => {
    if (balance === 0) return 'success';
    if (balance < 10000) return 'info';
    if (balance < 50000) return 'warning';
    return 'error';
  };

  const getBalanceText = (balance) => {
    if (balance === 0) return 'No Balance';
    if (balance < 10000) return 'Low Balance';
    if (balance < 50000) return 'Medium Balance';
    return 'High Balance';
  };

  return (
    <Dialog 
      open={open} 
      onClose={handleClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 2,
          maxHeight: '80vh'
        }
      }}
    >
      <DialogTitle sx={{ 
        color: '#004b87',
        borderBottom: '1px solid #eee',
        pb: 2,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <PersonIcon sx={{ color: '#004b87' }} />
          <Typography variant="h6" fontWeight="bold">
            Select Farmer
          </Typography>
        </Box>
        {selectedFarmer && (
          <Chip
            label="1 farmer selected"
            color="primary"
            size="small"
            sx={{ fontWeight: 'medium' }}
          />
        )}
      </DialogTitle>
      
      <DialogContent sx={{ pt: 3 }}>
        {/* Search Bar */}
        <Box sx={{ mb: 3 }}>
          <TextField
            fullWidth
            placeholder="Search by name, mobile, village, farmer code, district, taluk, hobli..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: '#666' }} />
                </InputAdornment>
              ),
              sx: {
                borderRadius: 2,
                backgroundColor: '#f8f9fa',
                '&:hover': {
                  backgroundColor: '#fff',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                }
              }
            }}
            variant="outlined"
            size="medium"
            autoFocus
          />
        </Box>

        {/* Farmers Table */}
        <TableContainer 
          component={Paper} 
          variant="outlined"
          sx={{ 
            borderRadius: 2,
            maxHeight: 400,
            overflow: 'auto'
          }}
        >
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
              <CircularProgress />
            </Box>
          ) : (
            <Table stickyHeader>
              <TableHead>
                <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
                  <TableCell sx={{ fontWeight: '600', color: '#004b87', width: '50px' }}></TableCell>
                  <TableCell sx={{ fontWeight: '600', color: '#004b87' }}>Farmer Details</TableCell>
                  <TableCell sx={{ fontWeight: '600', color: '#004b87' }}>Contact & Location</TableCell>
                  <TableCell sx={{ fontWeight: '600', color: '#004b87' }}>Bank Details</TableCell>
                  <TableCell sx={{ fontWeight: '600', color: '#004b87' }} align="right">Balance</TableCell>
                  <TableCell sx={{ fontWeight: '600', color: '#004b87' }} align="center">Select</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredFarmers.length > 0 ? (
                  filteredFarmers.map((farmer) => (
                    <TableRow 
                      key={farmer.id}
                      hover
                      onClick={() => handleSelectFarmer(farmer)}
                      sx={{ 
                        cursor: 'pointer',
                        backgroundColor: selectedFarmer?.id === farmer.id ? '#f0f8ff' : 'inherit',
                        '&:hover': {
                          backgroundColor: selectedFarmer?.id === farmer.id ? '#e3f2fd' : '#fafafa'
                        }
                      }}
                    >
                      <TableCell>
                        <Avatar
                          sx={{
                            bgcolor: '#e3f2fd',
                            color: '#004b87',
                            width: 36,
                            height: 36,
                            fontSize: '0.875rem',
                            fontWeight: 'bold'
                          }}
                        >
                          {farmer.name?.charAt(0).toUpperCase()}
                        </Avatar>
                      </TableCell>
                      
                      <TableCell>
                        <Box>
                          <Typography variant="body1" fontWeight="medium">
                            {farmer.name}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {farmer.fatherName}
                          </Typography>
                          <Chip
                            label={`ID: ${farmer.farmerCode}`}
                            size="small"
                            sx={{ 
                              mt: 0.5,
                              backgroundColor: '#f0f8ff',
                              color: '#0066b3',
                              fontSize: '0.7rem',
                              fontWeight: '500'
                            }}
                          />
                        </Box>
                      </TableCell>
                      
                      <TableCell>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                            <PhoneIcon fontSize="small" sx={{ color: '#666', fontSize: 14 }} />
                            <Typography variant="body2">{farmer.mobile}</Typography>
                          </Box>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                            <LocationIcon fontSize="small" sx={{ color: '#666', fontSize: 14 }} />
                            <Typography variant="body2" sx={{ fontSize: '0.875rem' }}>
                              {farmer.village}, {farmer.taluk || farmer.district}
                            </Typography>
                          </Box>
                          <Typography variant="caption" color="text.secondary">
                            {farmer.district} • {farmer.hobli}
                          </Typography>
                        </Box>
                      </TableCell>
                      
                      <TableCell>
                        {farmer.bankName ? (
                          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                              <BankIcon fontSize="small" sx={{ color: '#666', fontSize: 14 }} />
                              <Typography variant="body2" sx={{ fontSize: '0.875rem' }}>
                                {farmer.bankName}
                              </Typography>
                            </Box>
                            {farmer.accountNumber && (
                              <Typography variant="caption" color="text.secondary">
                                A/C: ••••{farmer.accountNumber.slice(-4)}
                              </Typography>
                            )}
                          </Box>
                        ) : (
                          <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic' }}>
                            No bank details
                          </Typography>
                        )}
                      </TableCell>
                      
                      <TableCell align="right">
                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
                          <Typography 
                            variant="body1" 
                            fontWeight="bold"
                            color={farmer.balanceDue > 0 ? '#dc3545' : '#00a859'}
                          >
                            ₹{parseFloat(farmer.balanceDue || 0).toLocaleString('en-IN')}
                          </Typography>
                          <Chip
                            label={getBalanceText(farmer.balanceDue || 0)}
                            size="small"
                            color={getBalanceColor(farmer.balanceDue || 0)}
                            sx={{ mt: 0.5, fontSize: '0.65rem' }}
                          />
                        </Box>
                      </TableCell>
                      
                      <TableCell align="center">
                        <IconButton
                          size="small"
                          sx={{
                            color: selectedFarmer?.id === farmer.id ? '#00a859' : '#ddd',
                            '&:hover': {
                              color: '#00a859'
                            }
                          }}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSelectFarmer(farmer);
                          }}
                        >
                          <CheckCircleIcon 
                            fontSize="small" 
                            sx={{ 
                              fontSize: 24,
                              color: selectedFarmer?.id === farmer.id ? '#00a859' : 'inherit'
                            }}
                          />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} align="center" sx={{ py: 4 }}>
                      <Box sx={{ textAlign: 'center', py: 4 }}>
                        <PersonIcon sx={{ fontSize: 48, color: '#ddd', mb: 2 }} />
                        <Typography variant="body1" color="text.secondary">
                          No farmers found
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          Try a different search term
                        </Typography>
                      </Box>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </TableContainer>

        {/* Stats */}
        {filteredFarmers.length > 0 && (
          <Box sx={{ 
            display: 'flex', 
            justifyContent: 'space-between',
            alignItems: 'center',
            mt: 2,
            p: 1.5,
            backgroundColor: '#f8f9fa',
            borderRadius: 1
          }}>
            <Typography variant="body2" color="text.secondary">
              Showing {filteredFarmers.length} of {farmers.length} farmers
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {searchTerm && `Search results for "${searchTerm}"`}
            </Typography>
          </Box>
        )}
      </DialogContent>
      
      <DialogActions sx={{ px: 3, pb: 3, pt: 2, borderTop: '1px solid #eee' }}>
        <Button 
          onClick={handleClose}
          sx={{ 
            color: '#666',
            textTransform: 'none'
          }}
        >
          Cancel
        </Button>
        <Button 
          variant="contained" 
          onClick={handleConfirmSelection}
          disabled={!selectedFarmer}
          startIcon={<CheckCircleIcon />}
          sx={{ 
            textTransform: 'none',
            borderRadius: 2,
            background: selectedFarmer ? 
              'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)' : 
              'linear-gradient(135deg, #ccc 0%, #ddd 100%)',
            '&:hover': {
              background: selectedFarmer ? 
                'linear-gradient(135deg, #00994d 0%, #00b35d 100%)' : 
                'linear-gradient(135deg, #ccc 0%, #ddd 100%)',
            }
          }}
        >
          Select Farmer
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default FarmerSelectionDialog;