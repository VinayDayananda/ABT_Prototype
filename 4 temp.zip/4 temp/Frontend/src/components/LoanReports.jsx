import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  TextField,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Tooltip,
  Alert,
  CircularProgress,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tab,
  Tabs
} from '@mui/material';
import {
  Download as DownloadIcon,
  Print as PrintIcon,
  FilterList as FilterIcon,
  Refresh as RefreshIcon,
  PictureAsPdf as PdfIcon,
  TableChart as TableIcon,
  BarChart as ChartIcon,
  CalendarToday as CalendarIcon,
  Search as SearchIcon,
  Visibility as ViewIcon,
  Edit as EditIcon
} from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { loanService } from '../services/loanService';
import { farmerService } from '../services/farmerService';

const LoanReports = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  const [reportType, setReportType] = useState('ACTIVE_LOANS');
  const [filters, setFilters] = useState({
    startDate: null,
    endDate: new Date(),
    status: 'ALL',
    farmerId: '',
    minAmount: '',
    maxAmount: ''
  });
  const [reports, setReports] = useState({
    activeLoans: [],
    overdueLoans: [],
    repaymentHistory: [],
    farmerSummary: [],
    interestReport: []
  });
  const [farmers, setFarmers] = useState([]);
  const [selectedReport, setSelectedReport] = useState(null);
  const [openDetailDialog, setOpenDetailDialog] = useState(false);

  useEffect(() => {
    fetchFarmers();
  }, []);

  const fetchFarmers = async () => {
    try {
      const response = await farmerService.getAllFarmers();
      setFarmers(response.data);
    } catch (error) {
      console.error('Error fetching farmers:', error);
    }
  };

  const generateReport = async () => {
    try {
      setLoading(true);
      setError(null);

      const allLoans = await loanService.getAllLoans();
      const loans = allLoans.data;

      // Apply filters
      let filteredLoans = loans.filter(loan => {
        // Date filter
        if (filters.startDate) {
          const loanDate = new Date(loan.loanDate);
          if (loanDate < new Date(filters.startDate)) return false;
        }
        if (filters.endDate) {
          const loanDate = new Date(loan.loanDate);
          if (loanDate > new Date(filters.endDate)) return false;
        }
        
        // Status filter
        if (filters.status !== 'ALL' && loan.status !== filters.status) return false;
        
        // Farmer filter
        if (filters.farmerId && loan.farmer?.id !== parseInt(filters.farmerId)) return false;
        
        // Amount filter
        if (filters.minAmount && loan.loanAmount < parseFloat(filters.minAmount)) return false;
        if (filters.maxAmount && loan.loanAmount > parseFloat(filters.maxAmount)) return false;
        
        return true;
      });

      // Generate different reports based on type
      const activeLoans = filteredLoans.filter(l => l.status === 'ACTIVE');
      const overdueLoans = filteredLoans.filter(l => 
        l.status === 'ACTIVE' && l.dueDate && new Date(l.dueDate) < new Date()
      );
      
      // Repayment history (from transactions)
      const repaymentHistory = filteredLoans.flatMap(loan => 
        (loan.transactions || [])
          .filter(t => t.transactionType === 'COPRA_PAYMENT' || t.transactionType === 'CASH_PAYMENT')
          .map(t => ({
            ...t,
            farmerName: loan.farmer?.name,
            loanNumber: loan.loanNumber,
            loanAmount: loan.loanAmount
          }))
      ).sort((a, b) => new Date(b.transactionDate) - new Date(a.transactionDate));

      // Farmer summary
      const farmerMap = {};
      filteredLoans.forEach(loan => {
        if (loan.farmer) {
          const farmerId = loan.farmer.id;
          if (!farmerMap[farmerId]) {
            farmerMap[farmerId] = {
              farmer: loan.farmer,
              totalLoans: 0,
              activeLoans: 0,
              totalBorrowed: 0,
              totalRepaid: 0,
              totalDue: 0,
              totalInterest: 0
            };
          }
          
          farmerMap[farmerId].totalLoans++;
          farmerMap[farmerId].totalBorrowed += parseFloat(loan.loanAmount || 0);
          farmerMap[farmerId].totalInterest += parseFloat(loan.totalInterest || 0);
          
          if (loan.status === 'ACTIVE') {
            farmerMap[farmerId].activeLoans++;
            farmerMap[farmerId].totalDue += parseFloat(loan.remainingAmount || 0);
          } else if (loan.status === 'PAID') {
            farmerMap[farmerId].totalRepaid += parseFloat(loan.loanAmount || 0);
          }
        }
      });

      const farmerSummary = Object.values(farmerMap);

      // Interest report
      const interestReport = filteredLoans.map(loan => ({
        loanNumber: loan.loanNumber,
        farmerName: loan.farmer?.name,
        loanAmount: loan.loanAmount,
        interestRate: loan.interestRate,
        totalInterest: loan.totalInterest,
        loanDate: loan.loanDate,
        status: loan.status,
        interestPerDay: loan.remainingAmount * (loan.interestRate / 100) / 365
      }));

      setReports({
        activeLoans,
        overdueLoans,
        repaymentHistory,
        farmerSummary,
        interestReport
      });

    } catch (error) {
      console.error('Error generating report:', error);
      setError('Failed to generate report. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (field, value) => {
    setFilters(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleViewDetails = (report) => {
    setSelectedReport(report);
    setOpenDetailDialog(true);
  };

  const exportReport = (format) => {
    let data = [];
    let filename = 'loan_report';
    
    switch(reportType) {
      case 'ACTIVE_LOANS':
        data = reports.activeLoans;
        filename = 'active_loans_report';
        break;
      case 'OVERDUE_LOANS':
        data = reports.overdueLoans;
        filename = 'overdue_loans_report';
        break;
      case 'REPAYMENT_HISTORY':
        data = reports.repaymentHistory;
        filename = 'repayment_history_report';
        break;
      case 'FARMER_SUMMARY':
        data = reports.farmerSummary;
        filename = 'farmer_summary_report';
        break;
      case 'INTEREST_REPORT':
        data = reports.interestReport;
        filename = 'interest_report';
        break;
    }
    
    if (format === 'csv') {
      exportToCSV(data, filename);
    } else if (format === 'pdf') {
      // In production, you would use a PDF library like jsPDF
      alert('PDF export would be implemented with a PDF library');
    }
  };

  const exportToCSV = (data, filename) => {
    if (!data || data.length === 0) {
      alert('No data to export');
      return;
    }
    
    // Convert data to CSV
    const headers = Object.keys(data[0]).join(',');
    const rows = data.map(row => 
      Object.values(row).map(value => 
        typeof value === 'object' ? JSON.stringify(value) : value
      ).join(',')
    );
    
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'ACTIVE': return 'success';
      case 'PAID': return 'primary';
      case 'OVERDUE': return 'warning';
      case 'DEFAULTED': return 'error';
      default: return 'default';
    }
  };

  const renderReportTable = () => {
    switch(reportType) {
      case 'ACTIVE_LOANS':
        return renderActiveLoansTable();
      case 'OVERDUE_LOANS':
        return renderOverdueLoansTable();
      case 'REPAYMENT_HISTORY':
        return renderRepaymentHistoryTable();
      case 'FARMER_SUMMARY':
        return renderFarmerSummaryTable();
      case 'INTEREST_REPORT':
        return renderInterestReportTable();
      default:
        return null;
    }
  };

  const renderActiveLoansTable = () => (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
            <TableCell>Loan No</TableCell>
            <TableCell>Farmer</TableCell>
            <TableCell align="right">Loan Amount</TableCell>
            <TableCell align="right">Remaining</TableCell>
            <TableCell align="right">Interest Rate</TableCell>
            <TableCell>Loan Date</TableCell>
            <TableCell>Due Date</TableCell>
            <TableCell>Status</TableCell>
            <TableCell align="center">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {reports.activeLoans.map((loan, index) => (
            <TableRow key={index} hover>
              <TableCell>{loan.loanNumber}</TableCell>
              <TableCell>
                <Box>
                  <Typography variant="body2" fontWeight="medium">
                    {loan.farmer?.name}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {loan.farmer?.village}
                  </Typography>
                </Box>
              </TableCell>
              <TableCell align="right">
                ₹{parseFloat(loan.loanAmount || 0).toLocaleString('en-IN')}
              </TableCell>
              <TableCell align="right">
                <Typography fontWeight="bold" color="#dc3545">
                  ₹{parseFloat(loan.remainingAmount || 0).toLocaleString('en-IN')}
                </Typography>
              </TableCell>
              <TableCell align="right">{loan.interestRate}%</TableCell>
              <TableCell>
                {new Date(loan.loanDate).toLocaleDateString()}
              </TableCell>
              <TableCell>
                {loan.dueDate ? new Date(loan.dueDate).toLocaleDateString() : 'N/A'}
              </TableCell>
              <TableCell>
                <Chip 
                  label={loan.status} 
                  size="small" 
                  color={getStatusColor(loan.status)}
                />
              </TableCell>
              <TableCell align="center">
                <Tooltip title="View Details">
                  <IconButton size="small" onClick={() => handleViewDetails(loan)}>
                    <ViewIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );

  const renderOverdueLoansTable = () => (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
            <TableCell>Loan No</TableCell>
            <TableCell>Farmer</TableCell>
            <TableCell align="right">Overdue Amount</TableCell>
            <TableCell>Loan Date</TableCell>
            <TableCell>Due Date</TableCell>
            <TableCell>Days Overdue</TableCell>
            <TableCell>Contact</TableCell>
            <TableCell align="center">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {reports.overdueLoans.map((loan, index) => {
            const dueDate = new Date(loan.dueDate);
            const today = new Date();
            const daysOverdue = Math.ceil((today - dueDate) / (1000 * 60 * 60 * 24));
            
            return (
              <TableRow key={index} hover sx={{ backgroundColor: '#fff3cd' }}>
                <TableCell>{loan.loanNumber}</TableCell>
                <TableCell>
                  <Box>
                    <Typography variant="body2" fontWeight="medium">
                      {loan.farmer?.name}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {loan.farmer?.mobile}
                    </Typography>
                  </Box>
                </TableCell>
                <TableCell align="right">
                  <Typography fontWeight="bold" color="#dc3545">
                    ₹{parseFloat(loan.remainingAmount || 0).toLocaleString('en-IN')}
                  </Typography>
                </TableCell>
                <TableCell>
                  {new Date(loan.loanDate).toLocaleDateString()}
                </TableCell>
                <TableCell>
                  {new Date(loan.dueDate).toLocaleDateString()}
                </TableCell>
                <TableCell>
                  <Chip 
                    label={`${daysOverdue} days`} 
                    size="small" 
                    color="error"
                  />
                </TableCell>
                <TableCell>
                  <Button 
                    size="small" 
                    variant="outlined" 
                    color="primary"
                    onClick={() => window.open(`tel:${loan.farmer?.mobile}`)}
                  >
                    Call
                  </Button>
                </TableCell>
                <TableCell align="center">
                  <Tooltip title="Send Reminder">
                    <IconButton size="small">
                      <EditIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TableContainer>
  );

  const renderRepaymentHistoryTable = () => (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
            <TableCell>Date</TableCell>
            <TableCell>Loan No</TableCell>
            <TableCell>Farmer</TableCell>
            <TableCell align="right">Amount</TableCell>
            <TableCell>Payment Type</TableCell>
            <TableCell>Reference</TableCell>
            <TableCell>Notes</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {reports.repaymentHistory.map((transaction, index) => (
            <TableRow key={index} hover>
              <TableCell>
                {new Date(transaction.transactionDate).toLocaleDateString()}
              </TableCell>
              <TableCell>{transaction.loanNumber}</TableCell>
              <TableCell>{transaction.farmerName}</TableCell>
              <TableCell align="right">
                <Typography fontWeight="medium" color="#00a859">
                  ₹{parseFloat(transaction.amount || 0).toLocaleString('en-IN')}
                </Typography>
              </TableCell>
              <TableCell>
                <Chip 
                  label={transaction.transactionType.replace('_', ' ')} 
                  size="small"
                  sx={{ 
                    backgroundColor: transaction.transactionType === 'COPRA_PAYMENT' ? 
                      '#e8f5e8' : '#e3f2fd'
                  }}
                />
              </TableCell>
              <TableCell>{transaction.referenceNo || 'N/A'}</TableCell>
              <TableCell>
                <Typography variant="caption">
                  {transaction.notes || 'No notes'}
                </Typography>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );

  const renderFarmerSummaryTable = () => (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
            <TableCell>Farmer</TableCell>
            <TableCell align="right">Total Loans</TableCell>
            <TableCell align="right">Active Loans</TableCell>
            <TableCell align="right">Total Borrowed</TableCell>
            <TableCell align="right">Total Repaid</TableCell>
            <TableCell align="right">Total Due</TableCell>
            <TableCell align="right">Interest Paid</TableCell>
            <TableCell align="right">Repayment %</TableCell>
            <TableCell align="center">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {reports.farmerSummary.map((summary, index) => {
            const repaymentRate = summary.totalBorrowed > 0 ? 
              (summary.totalRepaid / summary.totalBorrowed) * 100 : 0;
            
            return (
              <TableRow key={index} hover>
                <TableCell>
                  <Box>
                    <Typography variant="body2" fontWeight="medium">
                      {summary.farmer.name}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {summary.farmer.farmerCode} • {summary.farmer.village}
                    </Typography>
                  </Box>
                </TableCell>
                <TableCell align="right">{summary.totalLoans}</TableCell>
                <TableCell align="right">
                  <Chip 
                    label={summary.activeLoans} 
                    size="small" 
                    color={summary.activeLoans > 0 ? 'warning' : 'default'}
                  />
                </TableCell>
                <TableCell align="right">
                  ₹{summary.totalBorrowed?.toLocaleString('en-IN')}
                </TableCell>
                <TableCell align="right">
                  <Typography color="#00a859">
                    ₹{summary.totalRepaid?.toLocaleString('en-IN')}
                  </Typography>
                </TableCell>
                <TableCell align="right">
                  <Typography fontWeight="bold" color="#dc3545">
                    ₹{summary.totalDue?.toLocaleString('en-IN')}
                  </Typography>
                </TableCell>
                <TableCell align="right">
                  ₹{summary.totalInterest?.toLocaleString('en-IN')}
                </TableCell>
                <TableCell align="right">
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                    <Typography sx={{ mr: 1 }}>
                      {repaymentRate.toFixed(1)}%
                    </Typography>
                    <Box sx={{ 
                      width: 60, 
                      height: 8, 
                      backgroundColor: '#e9ecef',
                      borderRadius: 4,
                      overflow: 'hidden'
                    }}>
                      <Box sx={{ 
                        width: `${Math.min(repaymentRate, 100)}%`, 
                        height: '100%',
                        backgroundColor: repaymentRate >= 80 ? '#00a859' : 
                                        repaymentRate >= 50 ? '#ffc107' : '#dc3545'
                      }} />
                    </Box>
                  </Box>
                </TableCell>
                <TableCell align="center">
                  <Tooltip title="View Farmer Details">
                    <IconButton 
                      size="small"
                      onClick={() => window.open(`/farmers/${summary.farmer.id}`, '_blank')}
                    >
                      <ViewIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TableContainer>
  );

  const renderInterestReportTable = () => (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
            <TableCell>Loan No</TableCell>
            <TableCell>Farmer</TableCell>
            <TableCell align="right">Loan Amount</TableCell>
            <TableCell align="right">Interest Rate</TableCell>
            <TableCell align="right">Total Interest</TableCell>
            <TableCell align="right">Daily Interest</TableCell>
            <TableCell>Loan Date</TableCell>
            <TableCell>Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {reports.interestReport.map((loan, index) => (
            <TableRow key={index} hover>
              <TableCell>{loan.loanNumber}</TableCell>
              <TableCell>{loan.farmerName}</TableCell>
              <TableCell align="right">
                ₹{parseFloat(loan.loanAmount || 0).toLocaleString('en-IN')}
              </TableCell>
              <TableCell align="right">{loan.interestRate}%</TableCell>
              <TableCell align="right">
                <Typography fontWeight="medium" color="#ff6b00">
                  ₹{parseFloat(loan.totalInterest || 0).toLocaleString('en-IN')}
                </Typography>
              </TableCell>
              <TableCell align="right">
                ₹{parseFloat(loan.interestPerDay || 0).toFixed(2)}
              </TableCell>
              <TableCell>
                {new Date(loan.loanDate).toLocaleDateString()}
              </TableCell>
              <TableCell>
                <Chip 
                  label={loan.status} 
                  size="small" 
                  color={getStatusColor(loan.status)}
                />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box>
        {/* Header */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" sx={{ fontWeight: 'bold', color: '#004b87', mb: 1 }}>
            Loan Reports & Analytics
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Generate comprehensive reports and analyze loan performance
          </Typography>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {/* Filter Card */}
        <Card sx={{ mb: 4, p: 3 }}>
          <Typography variant="h6" sx={{ mb: 3, color: '#004b87' }}>
            <FilterIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
            Report Filters
          </Typography>
          
          <Grid container spacing={3}>
            <Grid item xs={12} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel>Report Type</InputLabel>
                <Select
                  value={reportType}
                  label="Report Type"
                  onChange={(e) => setReportType(e.target.value)}
                >
                  <MenuItem value="ACTIVE_LOANS">Active Loans</MenuItem>
                  <MenuItem value="OVERDUE_LOANS">Overdue Loans</MenuItem>
                  <MenuItem value="REPAYMENT_HISTORY">Repayment History</MenuItem>
                  <MenuItem value="FARMER_SUMMARY">Farmer Summary</MenuItem>
                  <MenuItem value="INTEREST_REPORT">Interest Report</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} md={3}>
              <DatePicker
                label="Start Date"
                value={filters.startDate}
                onChange={(date) => handleFilterChange('startDate', date)}
                slotProps={{ textField: { size: 'small', fullWidth: true } }}
              />
            </Grid>
            
            <Grid item xs={12} md={3}>
              <DatePicker
                label="End Date"
                value={filters.endDate}
                onChange={(date) => handleFilterChange('endDate', date)}
                slotProps={{ textField: { size: 'small', fullWidth: true } }}
              />
            </Grid>
            
            <Grid item xs={12} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel>Status</InputLabel>
                <Select
                  value={filters.status}
                  label="Status"
                  onChange={(e) => handleFilterChange('status', e.target.value)}
                >
                  <MenuItem value="ALL">All Status</MenuItem>
                  <MenuItem value="ACTIVE">Active</MenuItem>
                  <MenuItem value="PAID">Paid</MenuItem>
                  <MenuItem value="OVERDUE">Overdue</MenuItem>
                  <MenuItem value="DEFAULTED">Defaulted</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel>Farmer</InputLabel>
                <Select
                  value={filters.farmerId}
                  label="Farmer"
                  onChange={(e) => handleFilterChange('farmerId', e.target.value)}
                >
                  <MenuItem value="">All Farmers</MenuItem>
                  {farmers.map(farmer => (
                    <MenuItem key={farmer.id} value={farmer.id}>
                      {farmer.name} ({farmer.farmerCode})
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} md={3}>
              <TextField
                fullWidth
                size="small"
                label="Min Amount"
                value={filters.minAmount}
                onChange={(e) => handleFilterChange('minAmount', e.target.value)}
                type="number"
                InputProps={{ startAdornment: '₹' }}
              />
            </Grid>
            
            <Grid item xs={12} md={3}>
              <TextField
                fullWidth
                size="small"
                label="Max Amount"
                value={filters.maxAmount}
                onChange={(e) => handleFilterChange('maxAmount', e.target.value)}
                type="number"
                InputProps={{ startAdornment: '₹' }}
              />
            </Grid>
            
            <Grid item xs={12} md={3}>
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Button
                  fullWidth
                  variant="contained"
                  startIcon={loading ? <CircularProgress size={20} color="inherit" /> : <SearchIcon />}
                  onClick={generateReport}
                  disabled={loading}
                  sx={{
                    background: 'linear-gradient(135deg, #0066b3 0%, #0083d4 100%)'
                  }}
                >
                  {loading ? 'Generating...' : 'Generate Report'}
                </Button>
                
                <Button
                  variant="outlined"
                  onClick={() => setFilters({
                    startDate: null,
                    endDate: new Date(),
                    status: 'ALL',
                    farmerId: '',
                    minAmount: '',
                    maxAmount: ''
                  })}
                  startIcon={<RefreshIcon />}
                >
                  Reset
                </Button>
              </Box>
            </Grid>
          </Grid>
        </Card>

        {/* Report Actions */}
        <Card sx={{ mb: 3, p: 2 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="h6">
              {reportType.split('_').map(word => word.charAt(0) + word.slice(1).toLowerCase()).join(' ')} Report
              <Typography variant="caption" sx={{ ml: 2, color: 'text.secondary' }}>
                {(() => {
                  const reportData = {
                    'ACTIVE_LOANS': reports.activeLoans,
                    'OVERDUE_LOANS': reports.overdueLoans,
                    'REPAYMENT_HISTORY': reports.repaymentHistory,
                    'FARMER_SUMMARY': reports.farmerSummary,
                    'INTEREST_REPORT': reports.interestReport
                  }[reportType];
                  return `${reportData?.length || 0} records found`;
                })()}
              </Typography>
            </Typography>
            
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Tooltip title="Export as CSV">
                <Button
                  variant="outlined"
                  startIcon={<DownloadIcon />}
                  onClick={() => exportReport('csv')}
                  disabled={loading}
                >
                  CSV
                </Button>
              </Tooltip>
              
              <Tooltip title="Export as PDF">
                <Button
                  variant="outlined"
                  startIcon={<PdfIcon />}
                  onClick={() => exportReport('pdf')}
                  disabled={loading}
                >
                  PDF
                </Button>
              </Tooltip>
              
              <Tooltip title="Print Report">
                <Button
                  variant="outlined"
                  startIcon={<PrintIcon />}
                  onClick={() => window.print()}
                  disabled={loading}
                >
                  Print
                </Button>
              </Tooltip>
            </Box>
          </Box>
        </Card>

        {/* Report Table */}
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
            <CircularProgress />
          </Box>
        ) : renderReportTable()}

        {/* Report Detail Dialog */}
        <Dialog 
          open={openDetailDialog} 
          onClose={() => setOpenDetailDialog(false)}
          maxWidth="md"
          fullWidth
        >
          {selectedReport && (
            <>
              <DialogTitle sx={{ color: '#004b87' }}>
                Loan Details - {selectedReport.loanNumber}
              </DialogTitle>
              <DialogContent>
                <Grid container spacing={2} sx={{ mt: 1 }}>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2" color="text.secondary">Farmer Name</Typography>
                    <Typography variant="body1">{selectedReport.farmer?.name}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2" color="text.secondary">Mobile</Typography>
                    <Typography variant="body1">{selectedReport.farmer?.mobile}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2" color="text.secondary">Loan Amount</Typography>
                    <Typography variant="body1" fontWeight="medium">
                      ₹{parseFloat(selectedReport.loanAmount || 0).toLocaleString('en-IN')}
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2" color="text.secondary">Remaining Amount</Typography>
                    <Typography variant="body1" fontWeight="bold" color="#dc3545">
                      ₹{parseFloat(selectedReport.remainingAmount || 0).toLocaleString('en-IN')}
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2" color="text.secondary">Interest Rate</Typography>
                    <Typography variant="body1">{selectedReport.interestRate}%</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2" color="text.secondary">Status</Typography>
                    <Chip 
                      label={selectedReport.status} 
                      color={getStatusColor(selectedReport.status)}
                      size="small"
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2" color="text.secondary">Loan Date</Typography>
                    <Typography variant="body1">
                      {new Date(selectedReport.loanDate).toLocaleDateString()}
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2" color="text.secondary">Due Date</Typography>
                    <Typography variant="body1">
                      {selectedReport.dueDate ? 
                        new Date(selectedReport.dueDate).toLocaleDateString() : 'Not set'}
                    </Typography>
                  </Grid>
                  {selectedReport.purpose && (
                    <Grid item xs={12}>
                      <Typography variant="subtitle2" color="text.secondary">Purpose</Typography>
                      <Typography variant="body1">{selectedReport.purpose}</Typography>
                    </Grid>
                  )}
                  {selectedReport.notes && (
                    <Grid item xs={12}>
                      <Typography variant="subtitle2" color="text.secondary">Notes</Typography>
                      <Typography variant="body1">{selectedReport.notes}</Typography>
                    </Grid>
                  )}
                </Grid>
                
                {/* Transaction History */}
                {selectedReport.transactions && selectedReport.transactions.length > 0 && (
                  <Box sx={{ mt: 4 }}>
                    <Typography variant="h6" sx={{ mb: 2 }}>Transaction History</Typography>
                    <TableContainer component={Paper} variant="outlined">
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell>Date</TableCell>
                            <TableCell>Type</TableCell>
                            <TableCell align="right">Amount</TableCell>
                            <TableCell>Notes</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {selectedReport.transactions.map((t, idx) => (
                            <TableRow key={idx}>
                              <TableCell>
                                {new Date(t.transactionDate).toLocaleDateString()}
                              </TableCell>
                              <TableCell>{t.transactionType.replace('_', ' ')}</TableCell>
                              <TableCell align="right">
                                ₹{parseFloat(t.amount || 0).toLocaleString('en-IN')}
                              </TableCell>
                              <TableCell>{t.notes}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </Box>
                )}
              </DialogContent>
              <DialogActions>
                <Button onClick={() => setOpenDetailDialog(false)}>Close</Button>
                <Button 
                  variant="contained" 
                  onClick={() => window.open(`/loans/${selectedReport.id}`, '_blank')}
                >
                  View Full Details
                </Button>
              </DialogActions>
            </>
          )}
        </Dialog>
      </Box>
    </LocalizationProvider>
  );
};

export default LoanReports;