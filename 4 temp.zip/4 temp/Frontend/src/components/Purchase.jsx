import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  TextField,
  Button,
  Card,
  CardContent,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Divider,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Autocomplete,
  Chip,
  IconButton,
  Tooltip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Collapse,
  Switch,
  FormControlLabel
} from '@mui/material';
import {
  ShoppingCart as PurchaseIcon,
  AttachMoney as MoneyIcon,
  CheckCircle as CheckIcon,
  Schedule as ClockIcon,
  Save as SaveIcon,
  Refresh as RefreshIcon,
  AccountBalance as LoanIcon,
  Add as AddIcon,
  Remove as RemoveIcon,
  Info as InfoIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  LocalShipping as BagIcon,
  Scale as ScaleIcon,
  Receipt as ReceiptIcon
} from '@mui/icons-material';
import { purchaseService } from '../services/purchaseService';
import { farmerService } from '../services/farmerService';
import { loanService } from '../services/loanService';
import FarmerSelectionDialog from './FarmerSelectionDialog';

const Purchase = () => {
  const [farmers, setFarmers] = useState([]);
  const [selectedFarmer, setSelectedFarmer] = useState(null);
  const [farmerLoans, setFarmerLoans] = useState([]);
  const [selectedLoan, setSelectedLoan] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loanLoading, setLoanLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [openLoanDialog, setOpenLoanDialog] = useState(false);
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);
  
  // Product types
  const [productTypes] = useState([
    { value: 'COPRA', label: 'Copra' },
    { value: 'CHURU_HOLU', label: 'Churu/Holu' },
    { value: 'COWTU', label: 'Cowtu' }
  ]);

  // Form data structure
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    purchaseItems: [
      {
        productType: 'COPRA',
        numberOfBags: '',
        weightPerBag: '43',
        extraQuantity: '',
        qualityDeduction: '',
        ratePerKg: '300',
        calculatedNetWeight: 0,
        calculatedAmount: 0
      }
    ],
    paymentMethod: 'CASH',
    paymentReference: '',
    amountPaid: '',
    loanPaymentType: 'NONE',
    loanDeduction: '',
    notes: ''
  });

  // Rates for different products
  const [productRates] = useState({
    COPRA: '300',
    CHURU_HOLU: '150',
    COWTU: '50'
  });

  const [openFarmerDialog, setOpenFarmerDialog] = useState(false);

  // Fetch farmers on component mount
  useEffect(() => {
    fetchFarmers();
  }, []);

  const fetchFarmers = async () => {
    try {
      setLoading(true);
      const response = await farmerService.getAllFarmers();
      setFarmers(response.data);
    } catch (error) {
      console.error('Error fetching farmers:', error);
      setError('Failed to load farmers. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Fetch loans when farmer is selected
  const fetchFarmerLoans = async (farmerId) => {
    if (!farmerId) {
      setFarmerLoans([]);
      setSelectedLoan(null);
      return;
    }
    
    try {
      setLoanLoading(true);
      const response = await loanService.getActiveLoansByFarmer(farmerId);
      setFarmerLoans(response.data);
      
      // Calculate total loan amount with interest
      if (response.data.length > 0) {
        let totalLoanWithInterest = 0;
        response.data.forEach(loan => {
          // Calculate interest up to today
          const loanDate = new Date(loan.loanDate);
          const today = new Date();
          const daysDiff = Math.floor((today - loanDate) / (1000 * 60 * 60 * 24));
          const interest = (loan.remainingAmount * loan.interestRate * daysDiff) / (100 * 365);
          totalLoanWithInterest += loan.remainingAmount + interest;
        });
        
        // Set loan deduction to total loan amount
        setFormData(prev => ({
          ...prev,
          loanDeduction: totalLoanWithInterest.toFixed(2)
        }));
      }
    } catch (error) {
      console.error('Error fetching farmer loans:', error);
    } finally {
      setLoanLoading(false);
    }
  };

  const handleFarmerSelect = (farmer) => {
    setSelectedFarmer(farmer);
    fetchFarmerLoans(farmer.id);
    setOpenFarmerDialog(false);
  };

  const handleInputChange = (e, index = null) => {
    const { name, value } = e.target;
    
    if (index !== null) {
      // Update specific purchase item
      const updatedItems = [...formData.purchaseItems];
      updatedItems[index] = {
        ...updatedItems[index],
        [name]: value
      };
      
      // Recalculate net weight and amount for this item
      if (name === 'numberOfBags' || name === 'weightPerBag' || 
          name === 'extraQuantity' || name === 'qualityDeduction' ||
          name === 'ratePerKg' || name === 'productType') {
        
        let netWeight = 0;
        
        if (updatedItems[index].productType === 'COPRA') {
          // For copra: (bags * weight per bag) + extra - deduction
          const bags = parseFloat(updatedItems[index].numberOfBags) || 0;
          const weightPerBag = parseFloat(updatedItems[index].weightPerBag) || 0;
          const extra = parseFloat(updatedItems[index].extraQuantity) || 0;
          const deduction = parseFloat(updatedItems[index].qualityDeduction) || 0;
          
          netWeight = (bags * weightPerBag) + extra - deduction;
        } else {
          // For churu/holu and cowtu: direct weight entry
          netWeight = parseFloat(updatedItems[index].extraQuantity) || 0;
        }
        
        if (netWeight < 0) netWeight = 0;
        
        const rate = parseFloat(updatedItems[index].ratePerKg) || 0;
        const amount = netWeight * rate;
        
        updatedItems[index] = {
          ...updatedItems[index],
          calculatedNetWeight: netWeight,
          calculatedAmount: amount
        };
      }
      
      setFormData(prev => ({
        ...prev,
        purchaseItems: updatedItems
      }));
    } else {
      // Update other form fields
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const addProductItem = () => {
    const newItem = {
      productType: 'COPRA',
      numberOfBags: '',
      weightPerBag: '43',
      extraQuantity: '',
      qualityDeduction: '',
      ratePerKg: productRates.COPRA,
      calculatedNetWeight: 0,
      calculatedAmount: 0
    };
    
    setFormData(prev => ({
      ...prev,
      purchaseItems: [...prev.purchaseItems, newItem]
    }));
  };

  const removeProductItem = (index) => {
    if (formData.purchaseItems.length > 1) {
      const updatedItems = [...formData.purchaseItems];
      updatedItems.splice(index, 1);
      setFormData(prev => ({
        ...prev,
        purchaseItems: updatedItems
      }));
    }
  };

  const calculateTotals = () => {
    let totalWeightKg = 0;
    let totalWeightQuintal = 0;
    let totalAmount = 0;
    let copraWeight = 0;
    let churuHoluWeight = 0;
    let cowtuWeight = 0;
    
    formData.purchaseItems.forEach(item => {
      totalWeightKg += item.calculatedNetWeight || 0;
      totalAmount += item.calculatedAmount || 0;
      
      if (item.productType === 'COPRA') {
        copraWeight += item.calculatedNetWeight || 0;
      } else if (item.productType === 'CHURU_HOLU') {
        churuHoluWeight += item.calculatedNetWeight || 0;
      } else if (item.productType === 'COWTU') {
        cowtuWeight += item.calculatedNetWeight || 0;
      }
    });
    
    totalWeightQuintal = totalWeightKg / 100;
    
    return {
      totalWeightKg,
      totalWeightQuintal,
      totalAmount,
      copraWeight,
      churuHoluWeight,
      cowtuWeight
    };
  };

  const calculateNetPayment = () => {
    const totals = calculateTotals();
    const loanDeduction = parseFloat(formData.loanDeduction) || 0;
    const commissionRate = selectedLoan ? 2 : 0;
    const amountAfterLoan = totals.totalAmount - loanDeduction;
    
    // Calculate commission (2% of amount after loan deduction)
    const commissionAmount = selectedLoan ? (amountAfterLoan * commissionRate) / 100 : 0;
    const netPayment = amountAfterLoan - commissionAmount;
    
    return {
      ...totals,
      loanDeduction,
      commissionRate,
      commissionAmount,
      netPayment: netPayment > 0 ? netPayment : 0,
      amountAfterLoan
    };
  };

  const resetForm = () => {
    setSelectedFarmer(null);
    setSelectedLoan(null);
    setFarmerLoans([]);
    setFormData({
      date: new Date().toISOString().split('T')[0],
      purchaseItems: [
        {
          productType: 'COPRA',
          numberOfBags: '',
          weightPerBag: '43',
          extraQuantity: '',
          qualityDeduction: '',
          ratePerKg: '300',
          calculatedNetWeight: 0,
          calculatedAmount: 0
        }
      ],
      paymentMethod: 'CASH',
      paymentReference: '',
      amountPaid: '',
      loanPaymentType: 'NONE',
      loanDeduction: '',
      notes: ''
    });
    setError(null);
    setSuccess(null);
  };

  const savePurchase = async () => {
    try {
      setLoading(true);
      setError(null);
      setSuccess(null);

      // Validation
      if (!selectedFarmer) {
        throw new Error('Please select a farmer');
      }

      const totals = calculateTotals();
      if (totals.totalWeightKg <= 0) {
        throw new Error('Please enter valid product quantities');
      }

      // Prepare purchase items data
      const purchaseItems = formData.purchaseItems.map(item => ({
        productType: item.productType,
        numberOfBags: item.productType === 'COPRA' ? parseInt(item.numberOfBags) : null,
        weightPerBag: item.productType === 'COPRA' ? parseFloat(item.weightPerBag) : null,
        extraQuantity: parseFloat(item.extraQuantity) || 0,
        qualityDeduction: parseFloat(item.qualityDeduction) || 0,
        netWeight: item.calculatedNetWeight,
        ratePerKg: parseFloat(item.ratePerKg),
        amount: item.calculatedAmount
      }));

      // Calculate net payment
      const payment = calculateNetPayment();

      // Prepare purchase data
      const purchaseData = {
        farmer: { id: selectedFarmer.id },
        purchaseDate: formData.date,
        purchaseItems: purchaseItems.map(item => ({
            productType: item.productType,
            numberOfBags: item.numberOfBags,
            weightPerBag: item.weightPerBag,
            extraQuantity: item.extraQuantity,
            qualityDeduction: item.qualityDeduction,
            netWeight: item.netWeight,
            ratePerKg: item.ratePerKg,
            amount: item.amount
            // DO NOT include purchase field here
          })),
        paymentMethod: formData.paymentMethod,
        paymentReference: formData.paymentReference || '',
        amountPaid: parseFloat(formData.amountPaid) || 0,
        notes: formData.notes || '',
        loan: selectedLoan ? { id: selectedLoan.id } : null,
        loanPaymentType: formData.loanPaymentType,
        loanDeduction: payment.loanDeduction,
        commissionRate: payment.commissionRate,
        commissionAmount: payment.commissionAmount,
        netPayment: payment.netPayment,
        totalWeightKg: payment.totalWeightKg,
        totalWeightQuintal: payment.totalWeightQuintal,
        totalAmount: payment.totalAmount
      };

      // Call API
      const response = await purchaseService.createPurchase(purchaseData);
      
      const purchaseId = response.data.purchaseId || `PUR${Date.now().toString().slice(-6)}`;
      
      // Build success message
      let successMessage = `Purchase saved successfully!\nBill Number: ${purchaseId}\n`;
      successMessage += `Farmer: ${selectedFarmer.name}\n`;
      successMessage += `Total Weight: ${payment.totalWeightKg.toFixed(2)} kg (${payment.totalWeightQuintal.toFixed(2)} quintal)\n`;
      successMessage += `Total Amount: ₹${payment.totalAmount.toLocaleString('en-IN')}\n`;
      
      if (selectedLoan) {
        successMessage += `\nLoan Details:\n`;
        successMessage += `Loan Deduction: ₹${payment.loanDeduction.toLocaleString('en-IN')}\n`;
        successMessage += `Commission (${payment.commissionRate}%): ₹${payment.commissionAmount.toLocaleString('en-IN')}\n`;
        successMessage += `Net Payment to Farmer: ₹${payment.netPayment.toLocaleString('en-IN')}\n`;
        successMessage += `Amount Paid: ₹${(parseFloat(formData.amountPaid) || 0).toLocaleString('en-IN')}\n`;
        successMessage += `Balance: ₹${(payment.netPayment - (parseFloat(formData.amountPaid) || 0)).toLocaleString('en-IN')}`;
      } else {
        successMessage += `\nAmount Paid: ₹${(parseFloat(formData.amountPaid) || 0).toLocaleString('en-IN')}\n`;
        successMessage += `Balance: ₹${(payment.totalAmount - (parseFloat(formData.amountPaid) || 0)).toLocaleString('en-IN')}`;
      }
      
      setSuccess(successMessage);
      
      // Generate bill
      generateBill(purchaseId, payment);
      
      // Reset form after a delay
      setTimeout(() => {
        resetForm();
      }, 3000);

    } catch (error) {
      console.error('Error saving purchase:', error);
      setError(error.response?.data?.message || error.message || 'Failed to save purchase. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const generateBill = (purchaseId, payment) => {
    if (!selectedFarmer) return;

    const billContent = `
AMBIKA TRADERS
Copra Purchase Bill
Tiptur, Karnataka | Phone: 9876543210

Bill No: ${purchaseId}
Date: ${new Date(formData.date).toLocaleDateString()}
Farmer: ${selectedFarmer.name}
Father: ${selectedFarmer.fatherName || 'N/A'}
Mobile: ${selectedFarmer.mobile}
Village: ${selectedFarmer.village}

-----------------------------------------------------------------
Product Details:
-----------------------------------------------------------------
`.trim();

    let productDetails = '';
    formData.purchaseItems.forEach((item, index) => {
      productDetails += `
${item.productType}:
  ${item.productType === 'COPRA' ? `Bags: ${item.numberOfBags} x ${item.weightPerBag} kg` : ''}
  Extra Quantity: ${item.extraQuantity || 0} kg
  Quality Deduction: ${item.qualityDeduction || 0} kg
  Net Weight: ${item.calculatedNetWeight || 0} kg
  Rate: ₹${item.ratePerKg}/kg
  Amount: ₹${item.calculatedAmount || 0}
-----------------------------------------------------------------
`;
    });

    let paymentDetails = `
-----------------------------------------------------------------
SUMMARY:
-----------------------------------------------------------------
Total Weight: ${payment.totalWeightKg.toFixed(2)} kg (${payment.totalWeightQuintal.toFixed(2)} quintal)
Total Amount: ₹${payment.totalAmount.toLocaleString('en-IN')}
`;

    if (selectedLoan) {
      paymentDetails += `
Loan Deduction: ₹${payment.loanDeduction.toLocaleString('en-IN')}
Commission (${payment.commissionRate}%): ₹${payment.commissionAmount.toLocaleString('en-IN')}
-----------------------------------------------------------------
NET PAYMENT: ₹${payment.netPayment.toLocaleString('en-IN')}
`;
    } else {
      paymentDetails += `
-----------------------------------------------------------------
NET PAYMENT: ₹${payment.totalAmount.toLocaleString('en-IN')}
`;
    }

    paymentDetails += `
Amount Paid: ₹${(parseFloat(formData.amountPaid) || 0).toLocaleString('en-IN')}
Balance Due: ₹${(payment.netPayment - (parseFloat(formData.amountPaid) || 0)).toLocaleString('en-IN')}
-----------------------------------------------------------------

Payment Method: ${formData.paymentMethod}
${formData.paymentReference ? `Reference: ${formData.paymentReference}\n` : ''}
${formData.notes ? `Notes: ${formData.notes}\n` : ''}

Thank you for your business!
Signature: _________________________`;

    const finalContent = billContent + productDetails + paymentDetails;

    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Bill - ${purchaseId}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; }
            .bill-header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
            .bill-details { margin-bottom: 20px; }
            .bill-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            .bill-table th, .bill-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            .bill-table th { background: #f5f5f5; }
            .bill-total { text-align: right; font-size: 1.2rem; font-weight: bold; border-top: 2px solid #333; padding-top: 10px; margin-top: 20px; }
            .loan-section { background: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0; }
            .product-section { margin-bottom: 20px; }
            .product-title { font-weight: bold; background: #f8f9fa; padding: 5px; border-radius: 3px; }
            @media print {
              body { margin: 0; padding: 10px; }
              .no-print { display: none !important; }
            }
          </style>
        </head>
        <body>
          <div class="bill-header">
            <h2>AMBIKA TRADERS</h2>
            <p>Copra Purchase Bill</p>
            <p>Tiptur, Karnataka | Phone: 9876543210</p>
          </div>
          
          <div class="bill-details">
            <p><strong>Bill No:</strong> ${purchaseId}</p>
            <p><strong>Date:</strong> ${new Date(formData.date).toLocaleDateString()}</p>
            <p><strong>Farmer:</strong> ${selectedFarmer.name}</p>
            <p><strong>Father:</strong> ${selectedFarmer.fatherName || 'N/A'}</p>
            <p><strong>Mobile:</strong> ${selectedFarmer.mobile}</p>
            <p><strong>Village:</strong> ${selectedFarmer.village}</p>
          </div>
          
          <div class="product-section">
            <h3>Product Details:</h3>
            ${formData.purchaseItems.map((item, index) => `
              <div style="margin-bottom: 15px; border: 1px solid #ddd; padding: 10px; border-radius: 5px;">
                <div class="product-title">${item.productType}</div>
                ${item.productType === 'COPRA' ? `
                  <p><strong>Bags:</strong> ${item.numberOfBags} x ${item.weightPerBag} kg = ${(item.numberOfBags * item.weightPerBag).toFixed(2)} kg</p>
                ` : ''}
                <p><strong>Extra Quantity:</strong> ${item.extraQuantity || 0} kg</p>
                <p><strong>Quality Deduction:</strong> ${item.qualityDeduction || 0} kg</p>
                <p><strong>Net Weight:</strong> ${item.calculatedNetWeight || 0} kg</p>
                <p><strong>Rate:</strong> ₹${item.ratePerKg}/kg</p>
                <p><strong>Amount:</strong> ₹${item.calculatedAmount || 0}</p>
              </div>
            `).join('')}
          </div>
          
          <table class="bill-table">
            <thead>
              <tr>
                <th>Description</th>
                <th>Quantity</th>
                <th>Rate (₹/kg)</th>
                <th>Amount (₹)</th>
              </tr>
            </thead>
            <tbody>
              ${formData.purchaseItems.map((item, index) => `
                <tr>
                  <td>${item.productType}</td>
                  <td>${item.calculatedNetWeight || 0} kg</td>
                  <td>${item.ratePerKg}</td>
                  <td>₹${item.calculatedAmount || 0}</td>
                </tr>
              `).join('')}
              
              <tr>
                <td colspan="3" style="text-align: right;"><strong>Sub Total:</strong></td>
                <td><strong>₹${payment.totalAmount.toLocaleString('en-IN')}</strong></td>
              </tr>
              
              ${selectedLoan ? `
                <tr>
                  <td colspan="3" style="text-align: right;"><strong>Loan Deduction:</strong></td>
                  <td>₹${payment.loanDeduction.toLocaleString('en-IN')}</td>
                </tr>
                <tr>
                  <td colspan="3" style="text-align: right;"><strong>Commission (${payment.commissionRate}%):</strong></td>
                  <td>₹${payment.commissionAmount.toLocaleString('en-IN')}</td>
                </tr>
                <tr class="bill-total">
                  <td colspan="3" style="text-align: right;"><strong>NET PAYMENT TO FARMER:</strong></td>
                  <td><strong>₹${payment.netPayment.toLocaleString('en-IN')}</strong></td>
                </tr>
              ` : `
                <tr class="bill-total">
                  <td colspan="3" style="text-align: right;"><strong>NET PAYMENT TO FARMER:</strong></td>
                  <td><strong>₹${payment.totalAmount.toLocaleString('en-IN')}</strong></td>
                </tr>
              `}
              
              <tr>
                <td colspan="3" style="text-align: right;"><strong>Amount Paid:</strong></td>
                <td>₹${(parseFloat(formData.amountPaid) || 0).toLocaleString('en-IN')}</td>
              </tr>
              <tr>
                <td colspan="3" style="text-align: right;"><strong>Balance Due:</strong></td>
                <td>₹${(payment.netPayment - (parseFloat(formData.amountPaid) || 0)).toLocaleString('en-IN')}</td>
              </tr>
            </tbody>
          </table>
          
          ${selectedLoan ? `
          <div class="loan-section">
            <p><strong>Loan Details:</strong></p>
            <p>Loan Amount Deducted: ₹${payment.loanDeduction.toLocaleString('en-IN')}</p>
            <p>Remaining Loan Balance will be adjusted in next purchase.</p>
          </div>
          ` : ''}
          
          <div style="margin-top: 30px; text-align: center;">
            <p>Thank you for your business!</p>
            <p>Signature: _________________________</p>
          </div>
          
          <div class="no-print" style="margin-top: 20px; text-align: center;">
            <button onclick="window.print()" style="padding: 10px 20px; background: #0066b3; color: white; border: none; cursor: pointer;">
              Print Bill
            </button>
            <button onclick="window.close()" style="padding: 10px 20px; background: #666; color: white; border: none; margin-left: 10px; cursor: pointer;">
              Close
            </button>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleCreateLoan = async () => {
    try {
      setLoading(true);
      setError(null);

      if (!selectedFarmer) {
        throw new Error('Please select a farmer first');
      }

      // Open loan creation dialog (you need to implement this)
      setOpenLoanDialog(true);
      
    } catch (error) {
      console.error('Error creating loan:', error);
      setError(error.response?.data?.message || error.message || 'Failed to create loan. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const totals = calculateTotals();
  const payment = calculateNetPayment();

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ mb: 4, color: '#004b87' }}>
        <PurchaseIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
        New Copra Purchase
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {success && (
        <Alert severity="success" sx={{ mb: 3 }} onClose={() => setSuccess(null)}>
          {success.split('\n').map((line, index) => (
            <div key={index}>{line}</div>
          ))}
        </Alert>
      )}

      {/* Rate Information Card */}
      <Card sx={{ mb: 4, borderLeft: '4px solid #00a859' }}>
        <CardContent>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Typography variant="h6" sx={{ color: '#004b87' }}>
                Today's Rates
              </Typography>
              <Typography variant="body2">
                Copra: ₹{productRates.COPRA}/kg
              </Typography>
              <Typography variant="body2">
                Churu/Holu: ₹{productRates.CHURU_HOLU}/kg
              </Typography>
              <Typography variant="body2">
                Cowtu: ₹{productRates.COWTU}/kg
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="h6" sx={{ color: '#004b87' }}>
                Standard Bag Weight
              </Typography>
              <Typography variant="body2" sx={{ color: '#00a859' }}>
                <CheckIcon fontSize="small" /> 40-45 kg per bag
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="h6" sx={{ color: '#004b87' }}>
                Commission Rate
              </Typography>
              <Typography variant="body2">
                2% for farmers with loans
              </Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Purchase Form */}
      <Paper sx={{ p: 4, mb: 4 }}>
        <Grid container spacing={3}>
          {/* Farmer Selection */}
          <Grid item xs={12}>
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle2" sx={{ mb: 1, color: '#004b87' }}>
                Select Farmer *
              </Typography>
              {selectedFarmer ? (
                <Card variant="outlined" sx={{ p: 2, borderRadius: 2, backgroundColor: '#f8f9fa' }}>
                  <Grid container alignItems="center" spacing={2}>
                    <Grid item>
                      <BagIcon sx={{ fontSize: 40, color: '#0066b3' }} />
                    </Grid>
                    <Grid item xs>
                      <Box>
                        <Typography variant="body1" fontWeight="medium">
                          {selectedFarmer.name}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {selectedFarmer.fatherName} • {selectedFarmer.farmerCode}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {selectedFarmer.mobile} • {selectedFarmer.village}, {selectedFarmer.district}
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item>
                      <Box sx={{ textAlign: 'right' }}>
                        <Typography variant="body2" color="text.secondary">
                          Current Balance
                        </Typography>
                        <Typography 
                          variant="h6" 
                          fontWeight="bold"
                          color={selectedFarmer.balanceDue > 0 ? '#dc3545' : '#00a859'}
                        >
                          ₹{parseFloat(selectedFarmer.balanceDue || 0).toLocaleString('en-IN')}
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item>
                      <Button
                        size="small"
                        variant="outlined"
                        onClick={() => setOpenFarmerDialog(true)}
                      >
                        Change
                      </Button>
                    </Grid>
                  </Grid>
                </Card>
              ) : (
                <Button
                  fullWidth
                  variant="outlined"
                  onClick={() => setOpenFarmerDialog(true)}
                  sx={{
                    py: 2,
                    borderRadius: 2,
                    borderStyle: 'dashed',
                    borderColor: '#ccc',
                    '&:hover': {
                      borderColor: '#0066b3',
                      backgroundColor: 'rgba(0, 102, 179, 0.04)'
                    }
                  }}
                >
                  Click to Select Farmer
                </Button>
              )}
            </Box>
          </Grid>

          {/* Farmer Loan Information */}
          {selectedFarmer && farmerLoans.length > 0 && (
            <Grid item xs={12}>
              <Card sx={{ backgroundColor: '#fff3cd', mb: 2 }}>
                <CardContent sx={{ p: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <Box>
                      <Typography variant="subtitle1" fontWeight="bold" color="#856404">
                        <LoanIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                        Active Loans: {farmerLoans.length}
                      </Typography>
                      <Typography variant="body2" color="#856404">
                        Total Due: ₹{farmerLoans.reduce((sum, loan) => sum + parseFloat(loan.remainingAmount || 0), 0).toLocaleString('en-IN')}
                      </Typography>
                    </Box>
                    <Tooltip title="This farmer has active loans. Commission will be applied.">
                      <InfoIcon color="action" />
                    </Tooltip>
                  </Box>
                  
                  {/* Loan selection */}
                  <FormControl fullWidth sx={{ mt: 2 }} size="small">
                    <InputLabel>Select Loan to Deduct</InputLabel>
                    <Select
                      value={selectedLoan ? selectedLoan.id : ''}
                      onChange={(e) => {
                        const loanId = e.target.value;
                        const loan = farmerLoans.find(l => l.id === loanId);
                        setSelectedLoan(loan);
                      }}
                      label="Select Loan to Deduct"
                      disabled={loanLoading}
                    >
                      <MenuItem value="">
                        <em>No loan deduction</em>
                      </MenuItem>
                      {farmerLoans.map((loan) => (
                        <MenuItem key={loan.id} value={loan.id}>
                          Loan #{loan.loanNumber} - ₹{loan.remainingAmount?.toLocaleString('en-IN') || '0'} remaining
                          (Interest: {loan.interestRate}%)
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  
                  {selectedLoan && (
                    <Box sx={{ mt: 2, p: 2, backgroundColor: '#e8f5e8', borderRadius: 1 }}>
                      <Typography variant="body2" color="#00a859">
                        <CheckIcon fontSize="small" sx={{ mr: 1, verticalAlign: 'middle' }} />
                        Loan #{selectedLoan.loanNumber} selected for deduction
                      </Typography>
                      <Typography variant="caption" display="block">
                        Amount: ₹{selectedLoan.remainingAmount?.toLocaleString('en-IN') || '0'} 
                        | Interest Rate: {selectedLoan.interestRate}% 
                        | Date: {new Date(selectedLoan.loanDate).toLocaleDateString()}
                      </Typography>
                    </Box>
                  )}
                </CardContent>
              </Card>
            </Grid>
          )}

          {/* Date */}
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              type="date"
              label="Purchase Date"
              name="date"
              value={formData.date}
              onChange={handleInputChange}
              InputLabelProps={{ shrink: true }}
              disabled={loading}
            />
          </Grid>

          {/* Loan Payment Type */}
          {selectedLoan && (
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel>Loan Payment Type</InputLabel>
                <Select
                  name="loanPaymentType"
                  value={formData.loanPaymentType}
                  label="Loan Payment Type"
                  onChange={handleInputChange}
                  disabled={loading}
                >
                  <MenuItem value="NONE">No Loan Payment</MenuItem>
                  <MenuItem value="FULL_PAYMENT">Full Payment (Principal + Interest)</MenuItem>
                  <MenuItem value="INTEREST_ONLY">Interest Only</MenuItem>
                  <MenuItem value="PARTIAL_PAYMENT">Partial Payment</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          )}

          {/* Loan Deduction Amount */}
          {selectedLoan && formData.loanPaymentType === 'PARTIAL_PAYMENT' && (
            <Grid item xs={12}>
              <TextField
                fullWidth
                type="number"
                label="Loan Deduction Amount (₹)"
                name="loanDeduction"
                value={formData.loanDeduction}
                onChange={handleInputChange}
                InputProps={{
                  startAdornment: '₹'
                }}
                helperText="Enter amount to deduct from loan"
              />
            </Grid>
          )}

          {/* Product Items Table */}
          <Grid item xs={12}>
            <Typography variant="h6" sx={{ mb: 2, color: '#004b87' }}>
              Product Details
            </Typography>
            
            {formData.purchaseItems.map((item, index) => (
              <Card key={index} sx={{ mb: 2, p: 2, border: '1px solid #e0e0e0' }}>
                <Grid container spacing={2} alignItems="center">
                  <Grid item xs={12} md={2}>
                    <FormControl fullWidth size="small">
                      <InputLabel>Product Type</InputLabel>
                      <Select
                        name="productType"
                        value={item.productType}
                        label="Product Type"
                        onChange={(e) => handleInputChange(e, index)}
                        disabled={loading}
                      >
                        {productTypes.map((type) => (
                          <MenuItem key={type.value} value={type.value}>
                            {type.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>

                  {item.productType === 'COPRA' && (
                    <>
                      <Grid item xs={12} md={2}>
                        <TextField
                          fullWidth
                          type="number"
                          label="Number of Bags"
                          name="numberOfBags"
                          value={item.numberOfBags}
                          onChange={(e) => handleInputChange(e, index)}
                          size="small"
                          disabled={loading}
                        />
                      </Grid>
                      <Grid item xs={12} md={2}>
                        <TextField
                          fullWidth
                          type="number"
                          label="Weight per Bag (kg)"
                          name="weightPerBag"
                          value={item.weightPerBag}
                          onChange={(e) => handleInputChange(e, index)}
                          size="small"
                          disabled={loading}
                        />
                      </Grid>
                    </>
                  )}

                  <Grid item xs={12} md={2}>
                    <TextField
                      fullWidth
                      type="number"
                      label={item.productType === 'COPRA' ? "Extra Quantity (kg)" : "Weight (kg)"}
                      name="extraQuantity"
                      value={item.extraQuantity}
                      onChange={(e) => handleInputChange(e, index)}
                      size="small"
                      disabled={loading}
                      helperText={item.productType === 'COPRA' ? "Small bags extra" : "Enter weight"}
                    />
                  </Grid>

                  <Grid item xs={12} md={2}>
                    <TextField
                      fullWidth
                      type="number"
                      label="Quality Deduction (kg)"
                      name="qualityDeduction"
                      value={item.qualityDeduction}
                      onChange={(e) => handleInputChange(e, index)}
                      size="small"
                      disabled={loading}
                      helperText="Deduct for quality issues"
                    />
                  </Grid>

                  <Grid item xs={12} md={2}>
                    <TextField
                      fullWidth
                      type="number"
                      label="Rate per KG (₹)"
                      name="ratePerKg"
                      value={item.ratePerKg}
                      onChange={(e) => handleInputChange(e, index)}
                      size="small"
                      disabled={loading}
                    />
                  </Grid>

                  <Grid item xs={12} md={2}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <IconButton
                        size="small"
                        onClick={() => removeProductItem(index)}
                        disabled={formData.purchaseItems.length <= 1}
                        color="error"
                      >
                        <RemoveIcon />
                      </IconButton>
                      <Box sx={{ textAlign: 'center' }}>
                        <Typography variant="caption" display="block">
                          Net Weight: {item.calculatedNetWeight.toFixed(2)} kg
                        </Typography>
                        <Typography variant="body2" fontWeight="bold">
                          ₹{item.calculatedAmount.toLocaleString('en-IN')}
                        </Typography>
                      </Box>
                    </Box>
                  </Grid>
                </Grid>
              </Card>
            ))}

            <Button
              variant="outlined"
              startIcon={<AddIcon />}
              onClick={addProductItem}
              sx={{ mt: 1 }}
              disabled={loading}
            >
              Add Another Product
            </Button>
          </Grid>

          {/* Advanced Options */}
          <Grid item xs={12}>
            <FormControlLabel
              control={
                <Switch
                  checked={showAdvancedOptions}
                  onChange={(e) => setShowAdvancedOptions(e.target.checked)}
                  color="primary"
                />
              }
              label="Show Advanced Options"
            />
          </Grid>

          <Collapse in={showAdvancedOptions} timeout="auto" unmountOnExit>
            <Grid item xs={12}>
              <Card sx={{ p: 2, backgroundColor: '#f8f9fa' }}>
                <Grid container spacing={2}>
                  <Grid item xs={12} md={6}>
                    <TextField
                      fullWidth
                      label="Payment Method"
                      name="paymentMethod"
                      value={formData.paymentMethod}
                      onChange={handleInputChange}
                      select
                      size="small"
                    >
                      <MenuItem value="CASH">Cash</MenuItem>
                      <MenuItem value="BANK_TRANSFER">Bank Transfer</MenuItem>
                      <MenuItem value="UPI">UPI</MenuItem>
                    </TextField>
                  </Grid>
                  
                  <Grid item xs={12} md={6}>
                    <TextField
                      fullWidth
                      label="Payment Reference"
                      name="paymentReference"
                      value={formData.paymentReference}
                      onChange={handleInputChange}
                      size="small"
                      placeholder="Transaction ID, UPI Ref, etc."
                      disabled={formData.paymentMethod === 'CASH'}
                    />
                  </Grid>
                  
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Amount Paid (₹)"
                      name="amountPaid"
                      value={formData.amountPaid}
                      onChange={handleInputChange}
                      type="number"
                      size="small"
                      InputProps={{
                        startAdornment: '₹'
                      }}
                      helperText="Enter amount paid to farmer now"
                    />
                  </Grid>
                  
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Notes"
                      name="notes"
                      value={formData.notes}
                      onChange={handleInputChange}
                      multiline
                      rows={2}
                      size="small"
                      placeholder="Additional notes about this purchase..."
                    />
                  </Grid>
                </Grid>
              </Card>
            </Grid>
          </Collapse>

          {/* Summary Card */}
          <Grid item xs={12}>
            <Card sx={{ 
              mt: 3, 
              p: 3, 
              backgroundColor: '#f8f9fa', 
              borderRadius: 2,
              borderLeft: '4px solid #0066b3'
            }}>
              <Grid container spacing={2}>
                <Grid item xs={12} md={4}>
                  <Box sx={{ textAlign: 'center' }}>
                    <ScaleIcon sx={{ fontSize: 40, color: '#0066b3', mb: 1 }} />
                    <Typography variant="h6">Total Weight</Typography>
                    <Typography variant="h4" color="#004b87">
                      {totals.totalWeightKg.toFixed(2)} kg
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {totals.totalWeightQuintal.toFixed(2)} quintal
                    </Typography>
                  </Box>
                </Grid>
                
                <Grid item xs={12} md={4}>
                  <Box sx={{ textAlign: 'center' }}>
                    <ReceiptIcon sx={{ fontSize: 40, color: '#00a859', mb: 1 }} />
                    <Typography variant="h6">Total Amount</Typography>
                    <Typography variant="h4" color="#00a859">
                      ₹{totals.totalAmount.toLocaleString('en-IN')}
                    </Typography>
                  </Box>
                </Grid>
                
                <Grid item xs={12} md={4}>
                  <Box sx={{ textAlign: 'center' }}>
                    <MoneyIcon sx={{ fontSize: 40, color: selectedLoan ? '#dc3545' : '#ff6b00', mb: 1 }} />
                    <Typography variant="h6">Net Payment</Typography>
                    <Typography variant="h4" color={selectedLoan ? '#dc3545' : '#ff6b00'}>
                      ₹{payment.netPayment.toLocaleString('en-IN')}
                    </Typography>
                    {selectedLoan && (
                      <Typography variant="caption" color="text.secondary">
                        After loan deduction & commission
                      </Typography>
                    )}
                  </Box>
                </Grid>
              </Grid>
              
              <Divider sx={{ my: 2 }} />
              
              <Grid container spacing={2}>
                {selectedLoan && (
                  <>
                    <Grid item xs={12} md={4}>
                      <Typography variant="body2" color="text.secondary">
                        Loan Deduction
                      </Typography>
                      <Typography variant="body1" fontWeight="bold" color="#dc3545">
                        ₹{payment.loanDeduction.toLocaleString('en-IN')}
                      </Typography>
                    </Grid>
                    
                    <Grid item xs={12} md={4}>
                      <Typography variant="body2" color="text.secondary">
                        Commission ({payment.commissionRate}%)
                      </Typography>
                      <Typography variant="body1" fontWeight="bold" color="#856404">
                        ₹{payment.commissionAmount.toLocaleString('en-IN')}
                      </Typography>
                    </Grid>
                  </>
                )}
                
                <Grid item xs={12} md={4}>
                  <Typography variant="body2" color="text.secondary">
                    Amount Paid
                  </Typography>
                  <Typography variant="body1" fontWeight="bold" color="#00a859">
                    ₹{(parseFloat(formData.amountPaid) || 0).toLocaleString('en-IN')}
                  </Typography>
                </Grid>
                
                <Grid item xs={12} md={4}>
                  <Typography variant="body2" color="text.secondary">
                    Balance Due
                  </Typography>
                  <Typography variant="body1" fontWeight="bold" color="#ff6b00">
                    ₹{(payment.netPayment - (parseFloat(formData.amountPaid) || 0)).toLocaleString('en-IN')}
                  </Typography>
                </Grid>
              </Grid>
            </Card>
          </Grid>

          {/* Action Buttons */}
          <Grid item xs={12}>
            <Box sx={{ mt: 4, display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
              <Button
                variant="outlined"
                startIcon={<RefreshIcon />}
                onClick={resetForm}
                sx={{ px: 4 }}
                disabled={loading}
              >
                Reset
              </Button>
              <Button
                variant="contained"
                color="success"
                startIcon={loading ? <CircularProgress size={20} color="inherit" /> : <SaveIcon />}
                onClick={savePurchase}
                sx={{ px: 4 }}
                disabled={loading || !selectedFarmer || totals.totalWeightKg <= 0}
              >
                {loading ? 'Saving...' : 'SAVE & PRINT BILL'}
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Paper>

      {/* Farmer Selection Dialog */}
      <FarmerSelectionDialog
        open={openFarmerDialog}
        onClose={() => setOpenFarmerDialog(false)}
        onSelectFarmer={handleFarmerSelect}
      />
    </Box>
  );
};

export default Purchase;