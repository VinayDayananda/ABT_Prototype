import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  TextField,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Divider,
  Alert,
  CircularProgress,
  IconButton,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import {
  Download as DownloadIcon,
  Print as PrintIcon,
  PictureAsPdf as PdfIcon,
  Email as EmailIcon,
  Share as ShareIcon,
  CalendarToday as CalendarIcon,
  AccountBalance as AccountIcon,
  Receipt as ReceiptIcon,
  ArrowBack as BackIcon
} from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { useParams, useNavigate } from 'react-router-dom';
import { loanService } from '../services/loanService';
import { farmerService } from '../services/farmerService';

const LoanStatement = () => {
  const { farmerId } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [farmer, setFarmer] = useState(null);
  const [loans, setLoans] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [filters, setFilters] = useState({
    startDate: null,
    endDate: new Date()
  });
  const [openEmailDialog, setOpenEmailDialog] = useState(false);
  const [emailData, setEmailData] = useState({
    email: '',
    subject: 'Your Loan Statement',
    message: ''
  });

  useEffect(() => {
    if (farmerId) {
      fetchData();
    }
  }, [farmerId]);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const [farmerRes, loansRes] = await Promise.all([
        farmerService.getFarmerById(farmerId),
        loanService.getLoansByFarmer(farmerId)
      ]);
      
      setFarmer(farmerRes.data);
      setLoans(loansRes.data);
      
      // Combine all transactions from all loans
      const allTransactions = loansRes.data.flatMap(loan => 
        (loan.transactions || []).map(t => ({
          ...t,
          loanNumber: loan.loanNumber,
          loanAmount: loan.loanAmount,
          interestRate: loan.interestRate
        }))
      ).sort((a, b) => new Date(b.transactionDate) - new Date(a.transactionDate));
      
      setTransactions(allTransactions);
      
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to load loan statement. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const calculateSummary = () => {
    const activeLoans = loans.filter(l => l.status === 'ACTIVE');
    const paidLoans = loans.filter(l => l.status === 'PAID');
    
    const totalBorrowed = loans.reduce((sum, loan) => 
      sum + parseFloat(loan.loanAmount || 0), 0);
    
    const totalRepaid = paidLoans.reduce((sum, loan) => 
      sum + parseFloat(loan.loanAmount || 0), 0);
    
    const totalDue = activeLoans.reduce((sum, loan) => 
      sum + parseFloat(loan.remainingAmount || 0), 0);
    
    const totalInterest = loans.reduce((sum, loan) => 
      sum + parseFloat(loan.totalInterest || 0), 0);
    
    return {
      totalBorrowed,
      totalRepaid,
      totalDue,
      totalInterest,
      activeLoanCount: activeLoans.length,
      totalLoanCount: loans.length
    };
  };

  const filteredTransactions = transactions.filter(t => {
    if (!filters.startDate && !filters.endDate) return true;
    
    const tDate = new Date(t.transactionDate);
    
    if (filters.startDate && tDate < new Date(filters.startDate)) return false;
    if (filters.endDate && tDate > new Date(filters.endDate)) return false;
    
    return true;
  });

  const generateStatement = () => {
    const summary = calculateSummary();
    const statement = {
      farmer: farmer,
      generatedDate: new Date().toLocaleDateString(),
      period: filters.startDate && filters.endDate ? 
        `${new Date(filters.startDate).toLocaleDateString()} to ${new Date(filters.endDate).toLocaleDateString()}` :
        'All Time',
      summary,
      loans: loans.map(loan => ({
        loanNumber: loan.loanNumber,
        loanAmount: loan.loanAmount,
        remainingAmount: loan.remainingAmount,
        interestRate: loan.interestRate,
        status: loan.status,
        loanDate: loan.loanDate
      })),
      transactions: filteredTransactions
    };
    
    return statement;
  };

  const exportToPDF = () => {
    // This would use a PDF library like jsPDF in production
    const statement = generateStatement();
    alert(`PDF statement generated for ${farmer.name}. This would create a downloadable PDF in production.`);
    
    // Example of what would be implemented:
    // const doc = new jsPDF();
    // doc.text(`Loan Statement for ${farmer.name}`, 10, 10);
    // ... more PDF generation code
    // doc.save(`Loan_Statement_${farmer.name}_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  const printStatement = () => {
    const printContent = document.getElementById('statement-print');
    const printWindow = window.open('', '_blank');
    
    printWindow.document.write(`
      <html>
        <head>
          <title>Loan Statement - ${farmer?.name}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px; }
            .section { margin-bottom: 30px; }
            .section-title { background: #f5f5f5; padding: 10px; font-weight: bold; border-left: 4px solid #0066b3; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f8f9fa; }
            .total-row { font-weight: bold; background-color: #f8f9fa; }
            .positive { color: #00a859; }
            .negative { color: #dc3545; }
            @media print {
              body { margin: 0; padding: 10px; }
              .no-print { display: none !important; }
            }
          </style>
        </head>
        <body>
          ${printContent.innerHTML}
        </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  const sendEmail = async () => {
    try {
      // In production, you would call an API to send the email
      const statement = generateStatement();
      const emailContent = `
Dear ${farmer.name},

Please find your loan statement attached.

Summary:
- Total Borrowed: ₹${statement.summary.totalBorrowed.toLocaleString('en-IN')}
- Total Repaid: ₹${statement.summary.totalRepaid.toLocaleString('en-IN')}
- Total Due: ₹${statement.summary.totalDue.toLocaleString('en-IN')}
- Active Loans: ${statement.summary.activeLoanCount}

Statement Period: ${statement.period}
Generated On: ${statement.generatedDate}

Thank you for your business.

Best regards,
Ambit Traders
      `;
      
      alert(`Email would be sent to ${emailData.email} with the statement.`);
      setOpenEmailDialog(false);
      
    } catch (error) {
      console.error('Error sending email:', error);
      alert('Failed to send email. Please try again.');
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'ACTIVE': return 'warning';
      case 'PAID': return 'success';
      case 'OVERDUE': return 'error';
      case 'DEFAULTED': return 'error';
      default: return 'default';
    }
  };

  const summary = calculateSummary();

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error" sx={{ m: 3 }}>
        {error}
      </Alert>
    );
  }

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box>
        {/* Header */}
        <Box sx={{ mb: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <Tooltip title="Go Back">
              <IconButton onClick={() => navigate(-1)} sx={{ mr: 2 }}>
                <BackIcon />
              </IconButton>
            </Tooltip>
            <Typography variant="h4" sx={{ fontWeight: 'bold', color: '#004b87' }}>
              Loan Statement
            </Typography>
          </Box>
          
          {farmer && (
            <Card sx={{ mb: 3 }}>
              <CardContent>
                <Grid container spacing={2}>
                  <Grid item xs={12} md={4}>
                    <Typography variant="h6" sx={{ color: '#004b87' }}>
                      {farmer.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {farmer.farmerCode} • {farmer.village}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {farmer.mobile}
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={12} md={8}>
                    <Grid container spacing={2}>
                      <Grid item xs={6} md={3}>
                        <Box sx={{ textAlign: 'center' }}>
                          <Typography variant="h6" color="#0066b3">
                            {summary.totalLoanCount}
                          </Typography>
                          <Typography variant="caption">Total Loans</Typography>
                        </Box>
                      </Grid>
                      <Grid item xs={6} md={3}>
                        <Box sx={{ textAlign: 'center' }}>
                          <Typography variant="h6" color="#00a859">
                            ₹{summary.totalRepaid.toLocaleString('en-IN')}
                          </Typography>
                          <Typography variant="caption">Total Repaid</Typography>
                        </Box>
                      </Grid>
                      <Grid item xs={6} md={3}>
                        <Box sx={{ textAlign: 'center' }}>
                          <Typography variant="h6" color="#dc3545">
                            ₹{summary.totalDue.toLocaleString('en-IN')}
                          </Typography>
                          <Typography variant="caption">Total Due</Typography>
                        </Box>
                      </Grid>
                      <Grid item xs={6} md={3}>
                        <Box sx={{ textAlign: 'center' }}>
                          <Typography variant="h6" color="#ff6b00">
                            ₹{summary.totalInterest.toLocaleString('en-IN')}
                          </Typography>
                          <Typography variant="caption">Interest Paid</Typography>
                        </Box>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          )}
        </Box>

        {/* Filter Card */}
        <Card sx={{ mb: 4, p: 3 }}>
          <Grid container spacing={3} alignItems="center">
            <Grid item xs={12} md={3}>
              <DatePicker
                label="Start Date"
                value={filters.startDate}
                onChange={(date) => setFilters(prev => ({ ...prev, startDate: date }))}
                slotProps={{ textField: { size: 'small', fullWidth: true } }}
              />
            </Grid>
            
            <Grid item xs={12} md={3}>
              <DatePicker
                label="End Date"
                value={filters.endDate}
                onChange={(date) => setFilters(prev => ({ ...prev, endDate: date }))}
                slotProps={{ textField: { size: 'small', fullWidth: true } }}
              />
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Box sx={{ display: 'flex', gap: 1, justifyContent: 'flex-end' }}>
                <Button
                  variant="outlined"
                  startIcon={<PrintIcon />}
                  onClick={printStatement}
                >
                  Print
                </Button>
                
                <Button
                  variant="outlined"
                  startIcon={<PdfIcon />}
                  onClick={exportToPDF}
                >
                  PDF
                </Button>
                
                <Button
                  variant="outlined"
                  startIcon={<DownloadIcon />}
                  onClick={() => {
                    const statement = generateStatement();
                    const dataStr = JSON.stringify(statement, null, 2);
                    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
                    const link = document.createElement('a');
                    link.setAttribute('href', dataUri);
                    link.setAttribute('download', `loan_statement_${farmer.name}_${new Date().toISOString().split('T')[0]}.json`);
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                  }}
                >
                  JSON
                </Button>
                
                <Button
                  variant="contained"
                  startIcon={<EmailIcon />}
                  onClick={() => setOpenEmailDialog(true)}
                  sx={{
                    background: 'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)'
                  }}
                >
                  Email
                </Button>
              </Box>
            </Grid>
          </Grid>
        </Card>

        {/* Statement Content (Printable) */}
        <Box id="statement-print">
          {/* Statement Header */}
          <Card sx={{ mb: 3, backgroundColor: '#f8f9fa' }}>
            <CardContent>
              <Box sx={{ textAlign: 'center', mb: 3 }}>
                <Typography variant="h5" fontWeight="bold" color="#004b87">
                  AMBIKA TRADERS
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Copra Traders | Tiptur, Karnataka
                </Typography>
                <Typography variant="h6" sx={{ mt: 2 }}>
                  LOAN STATEMENT
                </Typography>
              </Box>
              
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography variant="subtitle2" color="text.secondary">Farmer Details</Typography>
                  <Typography variant="body1" fontWeight="medium">{farmer.name}</Typography>
                  <Typography variant="body2">{farmer.fatherName ? `S/o ${farmer.fatherName}` : ''}</Typography>
                  <Typography variant="body2">{farmer.village}, {farmer.taluk}</Typography>
                  <Typography variant="body2">Mobile: {farmer.mobile}</Typography>
                </Grid>
                
                <Grid item xs={6} sx={{ textAlign: 'right' }}>
                  <Typography variant="subtitle2" color="text.secondary">Statement Period</Typography>
                  <Typography variant="body1">
                    {filters.startDate && filters.endDate ? 
                      `${new Date(filters.startDate).toLocaleDateString()} to ${new Date(filters.endDate).toLocaleDateString()}` :
                      'All Transactions'
                    }
                  </Typography>
                  <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 2 }}>
                    Generated On
                  </Typography>
                  <Typography variant="body1">
                    {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}
                  </Typography>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Loan Summary */}
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 3, color: '#004b87' }}>
                <AccountIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                Loan Summary
              </Typography>
              
              <Grid container spacing={2}>
                <Grid item xs={6} md={3}>
                  <Paper sx={{ p: 2, textAlign: 'center', backgroundColor: '#e3f2fd' }}>
                    <Typography variant="h5" color="#0066b3">
                      ₹{summary.totalBorrowed.toLocaleString('en-IN')}
                    </Typography>
                    <Typography variant="caption">Total Borrowed</Typography>
                  </Paper>
                </Grid>
                
                <Grid item xs={6} md={3}>
                  <Paper sx={{ p: 2, textAlign: 'center', backgroundColor: '#e8f5e8' }}>
                    <Typography variant="h5" color="#00a859">
                      ₹{summary.totalRepaid.toLocaleString('en-IN')}
                    </Typography>
                    <Typography variant="caption">Total Repaid</Typography>
                  </Paper>
                </Grid>
                
                <Grid item xs={6} md={3}>
                  <Paper sx={{ p: 2, textAlign: 'center', backgroundColor: '#ffeaea' }}>
                    <Typography variant="h5" color="#dc3545">
                      ₹{summary.totalDue.toLocaleString('en-IN')}
                    </Typography>
                    <Typography variant="caption">Total Due</Typography>
                  </Paper>
                </Grid>
                
                <Grid item xs={6} md={3}>
                  <Paper sx={{ p: 2, textAlign: 'center', backgroundColor: '#fff3cd' }}>
                    <Typography variant="h5" color="#856404">
                      ₹{summary.totalInterest.toLocaleString('en-IN')}
                    </Typography>
                    <Typography variant="caption">Interest Paid</Typography>
                  </Paper>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Active Loans */}
          {loans.filter(l => l.status === 'ACTIVE').length > 0 && (
            <Card sx={{ mb: 3 }}>
              <CardContent>
                <Typography variant="h6" sx={{ mb: 3, color: '#004b87' }}>
                  Active Loans
                </Typography>
                
                <TableContainer component={Paper} variant="outlined">
                  <Table size="small">
                    <TableHead>
                      <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
                        <TableCell>Loan No</TableCell>
                        <TableCell align="right">Loan Amount</TableCell>
                        <TableCell align="right">Remaining</TableCell>
                        <TableCell align="right">Interest Rate</TableCell>
                        <TableCell>Loan Date</TableCell>
                        <TableCell>Due Date</TableCell>
                        <TableCell>Status</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {loans.filter(l => l.status === 'ACTIVE').map((loan, index) => (
                        <TableRow key={index} hover>
                          <TableCell>{loan.loanNumber}</TableCell>
                          <TableCell align="right">
                            ₹{parseFloat(loan.loanAmount || 0).toLocaleString('en-IN')}
                          </TableCell>
                          <TableCell align="right">
                            <Typography fontWeight="bold" color="#dc3545">
                              ₹{parseFloat(loan.remainingAmount || 0).toLocaleString('en-IN')}
                            </Typography>
                          </TableCell>
                          <TableCell align="right">{loan.interestRate}%</TableCell>
                          <TableCell>
                            {new Date(loan.loanDate).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            {loan.dueDate ? 
                              new Date(loan.dueDate).toLocaleDateString() : 'Not set'
                            }
                          </TableCell>
                          <TableCell>
                            <Chip 
                              label={loan.status} 
                              size="small" 
                              color={getStatusColor(loan.status)}
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          )}

          {/* Transaction History */}
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 3, color: '#004b87' }}>
                <ReceiptIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                Transaction History
              </Typography>
              
              <TableContainer component={Paper} variant="outlined">
                <Table>
                  <TableHead>
                    <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
                      <TableCell>Date</TableCell>
                      <TableCell>Loan No</TableCell>
                      <TableCell>Description</TableCell>
                      <TableCell align="right">Principal</TableCell>
                      <TableCell align="right">Interest</TableCell>
                      <TableCell align="right">Total</TableCell>
                      <TableCell>Balance</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {filteredTransactions.map((transaction, index) => (
                      <TableRow key={index} hover>
                        <TableCell>
                          {new Date(transaction.transactionDate).toLocaleDateString()}
                        </TableCell>
                        <TableCell>{transaction.loanNumber}</TableCell>
                        <TableCell>
                          {transaction.transactionType.replace('_', ' ')}
                          {transaction.notes && (
                            <Typography variant="caption" display="block" color="text.secondary">
                              {transaction.notes}
                            </Typography>
                          )}
                        </TableCell>
                        <TableCell align="right">
                          {transaction.principalAmount > 0 && (
                            <Typography>
                              ₹{parseFloat(transaction.principalAmount || 0).toLocaleString('en-IN')}
                            </Typography>
                          )}
                        </TableCell>
                        <TableCell align="right">
                          {transaction.interestAmount > 0 && (
                            <Typography color="#ff6b00">
                              ₹{parseFloat(transaction.interestAmount || 0).toLocaleString('en-IN')}
                            </Typography>
                          )}
                        </TableCell>
                        <TableCell align="right">
                          <Typography 
                            fontWeight="medium"
                            color={transaction.transactionType === 'LOAN_DISBURSEMENT' ? '#dc3545' : '#00a859'}
                          >
                            {transaction.transactionType === 'LOAN_DISBURSEMENT' ? '-' : ''}
                            ₹{parseFloat(transaction.amount || 0).toLocaleString('en-IN')}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            ₹{parseFloat(transaction.remainingBalance || 0).toLocaleString('en-IN')}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    ))}
                    
                    {/* Summary Row */}
                    <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
                      <TableCell colSpan={3}>
                        <Typography fontWeight="bold">Total</Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography fontWeight="bold">
                          ₹{filteredTransactions
                            .reduce((sum, t) => sum + parseFloat(t.principalAmount || 0), 0)
                            .toLocaleString('en-IN')}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography fontWeight="bold" color="#ff6b00">
                          ₹{filteredTransactions
                            .reduce((sum, t) => sum + parseFloat(t.interestAmount || 0), 0)
                            .toLocaleString('en-IN')}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography fontWeight="bold">
                          ₹{filteredTransactions
                            .reduce((sum, t) => sum + (
                              t.transactionType === 'LOAN_DISBURSEMENT' ? 
                              -parseFloat(t.amount || 0) : parseFloat(t.amount || 0)
                            ), 0)
                            .toLocaleString('en-IN')}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography fontWeight="bold">
                          ₹{summary.totalDue.toLocaleString('en-IN')}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>

          {/* Footer */}
          <Card sx={{ backgroundColor: '#f8f9fa' }}>
            <CardContent>
              <Box sx={{ textAlign: 'center', py: 2 }}>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  This is a computer-generated statement. No signature required.
                </Typography>
                <Divider sx={{ mb: 2 }} />
                <Typography variant="body2">
                  <strong>Ambit Traders</strong> | Tiptur Market, Karnataka | Phone: 9876543210
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Email: info@ambikatraders.com | www.ambikatraders.com
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Box>

        {/* Email Dialog */}
        <Dialog open={openEmailDialog} onClose={() => setOpenEmailDialog(false)}>
          <DialogTitle>Email Loan Statement</DialogTitle>
          <DialogContent>
            <TextField
              autoFocus
              margin="dense"
              label="Email Address"
              type="email"
              fullWidth
              variant="outlined"
              value={emailData.email}
              onChange={(e) => setEmailData(prev => ({ ...prev, email: e.target.value }))}
              sx={{ mb: 2 }}
            />
            <TextField
              margin="dense"
              label="Subject"
              type="text"
              fullWidth
              variant="outlined"
              value={emailData.subject}
              onChange={(e) => setEmailData(prev => ({ ...prev, subject: e.target.value }))}
              sx={{ mb: 2 }}
            />
            <TextField
              margin="dense"
              label="Message"
              type="text"
              fullWidth
              multiline
              rows={4}
              variant="outlined"
              value={emailData.message}
              onChange={(e) => setEmailData(prev => ({ ...prev, message: e.target.value }))}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenEmailDialog(false)}>Cancel</Button>
            <Button 
              variant="contained" 
              onClick={sendEmail}
              disabled={!emailData.email}
            >
              Send Email
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </LocalizationProvider>
  );
};

export default LoanStatement;