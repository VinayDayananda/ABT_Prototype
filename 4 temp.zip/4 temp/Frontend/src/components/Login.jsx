import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Paper,
  Container,
  Grow,
  Zoom,
} from '@mui/material';
import {
  Language as LanguageIcon,
  Lock as LockIcon,
  Person as PersonIcon,
  Login as LoginIcon,
  Palette as PaletteIcon,
  Business as BusinessIcon,
} from '@mui/icons-material';

const Login = ({ onLogin }) => {
  const [credentials, setCredentials] = useState({
    role: '',
    password: 'password123',
  });
  
  const [language, setLanguage] = useState(() => {
    return localStorage.getItem('appLanguage') || 'en';
  });
  
  const [theme, setTheme] = useState('blue');

  // Language translations
  const translations = {
    en: {
      title: 'Ambika Traders',
      subtitle: 'Professional Copra Management System',
      welcome: 'Welcome Back',
      roleLabel: 'Select User Role',
      admin: 'Admin',
      owner: 'Owner',
      manager: 'Manager',
      accountant: 'Accountant',
      password: 'Password',
      signIn: 'Sign In to Dashboard',
      demoTitle: 'Demo Credentials',
      demo1: 'Select any role from dropdown',
      demo2: 'Password:',
      copyright: '© 2025 Ambika Traders | Secure Login System',
      english: 'English',
      kannada: 'Kannada',
      theme: 'Theme',
      blueOcean: 'Blue Ocean',
      sunsetOrange: 'Sunset Orange',
      greenForest: 'Green Forest',
      purpleRoyal: 'Purple Royal',
      corporateBlue: 'Corporate Blue',
    },
    kn: {
      title: 'ಅಂಬಿಕಾ ವ್ಯಾಪಾರಿಗಳು',
      subtitle: 'ವೃತ್ತಿಪರ ಕೊಪ್ರಾ ನಿರ್ವಹಣಾ ವ್ಯವಸ್ಥೆ',
      welcome: 'ಮತ್ತೆ ಸ್ವಾಗತ',
      roleLabel: 'ಬಳಕೆದಾರರ ಪಾತ್ರವನ್ನು ಆಯ್ಕೆಮಾಡಿ',
      admin: 'ನಿರ್ವಾಹಕ',
      owner: 'ಮಾಲೀಕ',
      manager: 'ವ್ಯವಸ್ಥಾಪಕ',
      accountant: 'ಲೆಕ್ಕಿಗ',
      password: 'ಪಾಸ್ವರ್ಡ್',
      signIn: 'ಡ್ಯಾಶ್ಬೋರ್ಡ್ಗೆ ಸೈನ್ ಇನ್ ಮಾಡಿ',
      demoTitle: 'ಡೆಮೊ ಕ್ರೆಡೆನ್ಷಿಯಲ್ಸ್',
      demo1: 'ಡ್ರಾಪ್ಡೌನ್ ನಿಂದ ಯಾವುದೇ ಪಾತ್ರವನ್ನು ಆಯ್ಕೆಮಾಡಿ',
      demo2: 'ಪಾಸ್ವರ್ಡ್:',
      copyright: '© 2025 ಅಂಬಿಕಾ ವ್ಯಾಪಾರಿಗಳು | ಸುರಕ್ಷಿತ ಲಾಗಿನ್ ವ್ಯವಸ್ಥೆ',
      english: 'English',
      kannada: 'ಕನ್ನಡ',
      theme: 'ಥೀಮ್',
      blueOcean: 'ನೀಲಿ ಸಮುದ್ರ',
      sunsetOrange: 'ಸೂರ್ಯಾಸ್ತ ಕಿತ್ತಳೆ',
      greenForest: 'ಹಸಿರು ಅರಣ್ಯ',
      purpleRoyal: 'ರಾಜಕೀಯ ನೇರಳೆ',
      corporateBlue: 'ಕಾರ್ಪೊರೇಟ್ ನೀಲಿ',
    }
  };

  const t = translations[language];

  const themes = {
    blue: { 
      primary: '#0066b3', 
      gradient: 'linear-gradient(135deg, #004b87 0%, #0066b3 50%, #00a859 100%)',
      name: t.blueOcean
    },
    orange: { 
      primary: '#ff6b00', 
      gradient: 'linear-gradient(135deg, #cc5600 0%, #ff6b00 50%, #ff8f33 100%)',
      name: t.sunsetOrange
    },
    green: { 
      primary: '#2e7d32', 
      gradient: 'linear-gradient(135deg, #1b5e20 0%, #2e7d32 50%, #43a047 100%)',
      name: t.greenForest
    },
    purple: { 
      primary: '#673ab7', 
      gradient: 'linear-gradient(135deg, #4527a0 0%, #673ab7 50%, #9575cd 100%)',
      name: t.purpleRoyal
    },
    corporate: { 
      primary: '#1565c0', 
      gradient: 'linear-gradient(135deg, #0d47a1 0%, #1565c0 50%, #42a5f5 100%)',
      name: t.corporateBlue
    },
  };

  const handleLogin = () => {
    if (credentials.role && credentials.password === 'password123') {
      localStorage.setItem('userRole', credentials.role);
      localStorage.setItem('isLoggedIn', 'true');
      onLogin();
    } else if (!credentials.role) {
      alert(language === 'kn' ? 'ದಯವಿಟ್ಟು ಪಾತ್ರವನ್ನು ಆಯ್ಕೆಮಾಡಿ' : 'Please select a role');
    } else {
      alert(language === 'kn' ? 'ಅಮಾನ್ಯ ಪಾಸ್ವರ್ಡ್. "password123" ಬಳಸಿ' : 'Invalid password. Use "password123"');
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleLogin();
    }
  };

  const handleLanguageChange = (lang) => {
    setLanguage(lang);
    localStorage.setItem('appLanguage', lang);
  };

  return (
    <Box
      sx={{
        minHeight: '100vh',
        background: themes[theme].gradient,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        p: 3,
        position: 'relative',
        overflow: 'hidden',
        '&::before': {
          content: '""',
          position: 'absolute',
          width: '100%',
          height: '100%',
          background: 'radial-gradient(circle at 20% 80%, rgba(255,255,255,0.1) 0%, transparent 50%)',
        },
      }}
    >
      {/* Animated Background Elements */}
      <Box sx={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        overflow: 'hidden',
        zIndex: 0,
      }}>
        {[...Array(20)].map((_, i) => (
          <Box
            key={i}
            sx={{
              position: 'absolute',
              width: Math.random() * 100 + 50,
              height: Math.random() * 100 + 50,
              borderRadius: '50%',
              background: `rgba(255,255,255,${Math.random() * 0.1})`,
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animation: `float ${Math.random() * 10 + 10}s infinite ease-in-out`,
              animationDelay: `${Math.random() * 5}s`,
              '@keyframes float': {
                '0%, 100%': { transform: 'translateY(0) rotate(0deg)' },
                '50%': { transform: 'translateY(-20px) rotate(180deg)' },
              },
            }}
          />
        ))}
      </Box>

      {/* Theme Switcher - Top Left */}
      <Box sx={{ 
        position: 'absolute', 
        top: 20, 
        left: 20,
        display: 'flex',
        gap: 1,
        zIndex: 2,
        alignItems: 'center',
      }}>
        <PaletteIcon sx={{ color: 'white', fontSize: 20 }} />
        <Box sx={{ display: 'flex', gap: 0.5 }}>
          {Object.entries(themes).map(([key, themeData]) => (
            <Button
              key={key}
              onClick={() => setTheme(key)}
              sx={{
                minWidth: 'auto',
                width: 32,
                height: 32,
                borderRadius: '6px',
                backgroundColor: theme === key ? 'white' : 'rgba(255,255,255,0.2)',
                color: theme === key ? themeData.primary : 'white',
                border: theme === key ? `2px solid white` : 'none',
                '&:hover': {
                  backgroundColor: 'rgba(255,255,255,0.3)',
                },
                fontSize: '0.7rem',
                fontWeight: theme === key ? 'bold' : 'normal',
              }}
            >
              {key.charAt(0).toUpperCase()}
            </Button>
          ))}
        </Box>
      </Box>

      {/* Language Selector - Top Right */}
      <Box sx={{ 
        position: 'absolute', 
        top: 20, 
        right: 20,
        zIndex: 2,
      }}>
        <Button
          startIcon={<LanguageIcon />}
          onClick={() => handleLanguageChange(language === 'en' ? 'kn' : 'en')}
          sx={{
            color: 'white',
            border: '1px solid rgba(255,255,255,0.3)',
            backgroundColor: 'rgba(255,255,255,0.1)',
            textTransform: 'none',
            borderRadius: '20px',
            px: 2,
            py: 1,
            '&:hover': {
              backgroundColor: 'rgba(255,255,255,0.2)',
            },
          }}
        >
          {language === 'en' ? t.english : t.kannada}
        </Button>
      </Box>

      <Zoom in timeout={800}>
        <Container maxWidth="xs" sx={{ position: 'relative', zIndex: 1 }}>
          <Card
            sx={{
              borderRadius: 4,
              boxShadow: '0 25px 50px rgba(0,0,0,0.25)',
              overflow: 'hidden',
              background: 'rgba(255, 255, 255, 0.95)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            {/* Card Header */}
            <Box sx={{
              p: 3,
              textAlign: 'center',
              background: themes[theme].gradient,
              color: 'white',
              position: 'relative',
              overflow: 'hidden',
            }}>
              <Box sx={{
                position: 'absolute',
                top: -50,
                right: -50,
                width: 100,
                height: 100,
                borderRadius: '50%',
                background: 'rgba(255,255,255,0.1)',
              }} />
              <Box sx={{
                position: 'absolute',
                bottom: -30,
                left: -30,
                width: 80,
                height: 80,
                borderRadius: '50%',
                background: 'rgba(255,255,255,0.1)',
              }} />
              
              <Box sx={{
                width: 70,
                height: 70,
                backgroundColor: 'white',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 20px',
                boxShadow: '0 10px 20px rgba(0,0,0,0.2)',
              }}>
                <BusinessIcon sx={{ fontSize: 40, color: themes[theme].primary }} />
              </Box>
              
              <Typography variant="h4" sx={{ fontWeight: 'bold', mb: 1 }}>
                {t.title}
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.9 }}>
                {t.subtitle}
              </Typography>
            </Box>

            <CardContent sx={{ p: 4 }}>
              <Grow in timeout={1000}>
                <Box>
                  <Typography variant="h6" sx={{ 
                    mb: 3, 
                    textAlign: 'center',
                    color: themes[theme].primary,
                    fontWeight: 600,
                  }}>
                    {t.welcome}
                  </Typography>

                  <Box component="form" onKeyPress={handleKeyPress}>
                    <FormControl fullWidth sx={{ mb: 2 }}>
                      <InputLabel sx={{ fontSize: '0.9rem' }}>{t.roleLabel}</InputLabel>
                      <Select
                        value={credentials.role}
                        label={t.roleLabel}
                        onChange={(e) => setCredentials({ ...credentials, role: e.target.value })}
                        startAdornment={<PersonIcon sx={{ mr: 1, color: '#666' }} />}
                        sx={{
                          '& .MuiSelect-select': {
                            display: 'flex',
                            alignItems: 'center',
                          }
                        }}
                      >
                        <MenuItem value="admin">
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#ff4444' }} />
                            {t.admin}
                          </Box>
                        </MenuItem>
                        <MenuItem value="owner">
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#0066b3' }} />
                            {t.owner}
                          </Box>
                        </MenuItem>
                        <MenuItem value="manager">
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#00a859' }} />
                            {t.manager}
                          </Box>
                        </MenuItem>
                        <MenuItem value="accountant">
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#ff6b00' }} />
                            {t.accountant}
                          </Box>
                        </MenuItem>
                      </Select>
                    </FormControl>

                    <TextField
                      fullWidth
                      label={t.password}
                      type="password"
                      value={credentials.password}
                      onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                      sx={{ mb: 3 }}
                      InputProps={{
                        startAdornment: <LockIcon sx={{ mr: 1, color: '#666' }} />,
                      }}
                    />

                    <Button
                      fullWidth
                      variant="contained"
                      onClick={handleLogin}
                      size="large"
                      startIcon={<LoginIcon />}
                      sx={{
                        background: themes[theme].gradient,
                        '&:hover': {
                          background: themes[theme].gradient,
                          transform: 'translateY(-2px)',
                          boxShadow: '0 10px 25px rgba(0,0,0,0.2)',
                        },
                        py: 1.5,
                        mb: 3,
                        fontSize: '1rem',
                        fontWeight: 600,
                        borderRadius: '10px',
                        transition: 'all 0.3s ease',
                      }}
                    >
                      {t.signIn}
                    </Button>
                  </Box>

                  <Paper
                    elevation={0}
                    sx={{
                      p: 2.5,
                      backgroundColor: 'rgba(0, 102, 179, 0.05)',
                      borderRadius: 3,
                      borderLeft: `4px solid ${themes[theme].primary}`,
                    }}
                  >
                    <Typography variant="subtitle2" sx={{ 
                      fontWeight: 'bold', 
                      mb: 1.5, 
                      color: themes[theme].primary,
                      display: 'flex',
                      alignItems: 'center',
                      gap: 1,
                    }}>
                      <Box sx={{ 
                        width: 6, 
                        height: 6, 
                        borderRadius: '50%', 
                        bgcolor: themes[theme].primary 
                      }} />
                      {t.demoTitle}
                    </Typography>
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
                      <Typography variant="body2" sx={{ color: '#666', display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Box sx={{ width: 4, height: 4, borderRadius: '50%', bgcolor: themes[theme].primary }} />
                        {t.demo1}
                      </Typography>
                      <Typography variant="body2" sx={{ color: '#666', display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Box sx={{ width: 4, height: 4, borderRadius: '50%', bgcolor: themes[theme].primary }} />
                        {t.demo2} <strong>password123</strong>
                      </Typography>
                    </Box>
                  </Paper>

                  <Box sx={{ mt: 3, textAlign: 'center' }}>
                    <Typography variant="caption" sx={{ color: '#999', fontSize: '0.75rem' }}>
                      {t.copyright}
                    </Typography>
                    <Typography variant="caption" sx={{ 
                      color: '#999', 
                      fontSize: '0.7rem',
                      display: 'block',
                      mt: 0.5,
                    }}>
                      {t.theme}: <strong>{themes[theme].name}</strong> • {t.language}: <strong>{language === 'en' ? t.english : t.kannada}</strong>
                    </Typography>
                  </Box>
                </Box>
              </Grow>
            </CardContent>
          </Card>
        </Container>
      </Zoom>
    </Box>
  );
};

export default Login;