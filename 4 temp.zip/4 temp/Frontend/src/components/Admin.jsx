import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Chip,
} from '@mui/material';
import {
  Settings as SettingsIcon,
  PersonAdd as PersonAddIcon,
  CloudDownload as DownloadIcon,
  CloudUpload as UploadIcon,
  Delete as DeleteIcon,
  CheckCircle as CheckIcon,
 // Error as ErrorIcon,
  Security as SecurityIcon,
  Storage as StorageIcon, // Changed from Database to Storage
  Refresh as RefreshIcon,
  Edit as EditIcon,
} from '@mui/icons-material';

const Admin = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [users, setUsers] = useState([]);
  const [openUserDialog, setOpenUserDialog] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [userForm, setUserForm] = useState({
    username: '',
    password: '',
    fullName: '',
    role: 'manager',
  });
  const [licenseForm, setLicenseForm] = useState({
    licenseType: 'Basic (1 Year)',
    expiryDate: '2026-03-15',
  });

  // Mock system info - Replace with API call
  const [systemInfo, setSystemInfo] = useState({
    version: '1.0.0',
    lastBackup: '15 Mar 2025',
    dbSize: '45.2 MB',
    status: 'operational',
    licenseStatus: 'active',
    daysRemaining: 365,
  });

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      // Mock API call - Replace with actual API
      const mockUsers = [
        { id: 1, username: 'admin', fullName: 'Vinay Kumar', role: 'admin', avatar: 'VK', createdAt: '2024-01-01' },
        { id: 2, username: 'owner', fullName: 'Shivanna Gowda', role: 'owner', avatar: 'SG', createdAt: '2024-01-01' },
        { id: 3, username: 'manager1', fullName: 'Ramesh Gowda', role: 'manager', avatar: 'RG', createdAt: '2024-01-15' },
        { id: 4, username: 'accountant', fullName: 'Lakshmi Bai', role: 'accountant', avatar: 'LB', createdAt: '2024-01-20' },
      ];
      setUsers(mockUsers);
    } catch (error) {
      console.error('Error fetching users:', error);
      setError('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenUserDialog = (user = null) => {
    if (user) {
      setEditingUser(user);
      setUserForm({
        username: user.username,
        password: '',
        fullName: user.fullName,
        role: user.role,
      });
    } else {
      setEditingUser(null);
      setUserForm({
        username: '',
        password: '',
        fullName: '',
        role: 'manager',
      });
    }
    setOpenUserDialog(true);
  };

  const handleCloseUserDialog = () => {
    setOpenUserDialog(false);
    setEditingUser(null);
  };

  const handleUserFormChange = (e) => {
    const { name, value } = e.target;
    setUserForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleLicenseFormChange = (e) => {
    const { name, value } = e.target;
    setLicenseForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleCreateUser = async () => {
    try {
      setLoading(true);
      setError(null);
      setSuccess(null);

      // Validate form
      if (!userForm.username || !userForm.password || !userForm.fullName) {
        throw new Error('All fields are required');
      }

      // Mock API call - Replace with actual API
      const newUser = {
        id: users.length + 1,
        ...userForm,
        avatar: userForm.fullName.split(' ').map(n => n[0]).join(''),
        createdAt: new Date().toISOString().split('T')[0],
      };

      setUsers([...users, newUser]);
      setSuccess('User created successfully!');
      handleCloseUserDialog();
    } catch (error) {
      setError(error.message || 'Failed to create user');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateUser = async () => {
    try {
      setLoading(true);
      setError(null);
      setSuccess(null);

      // Mock API call - Replace with actual API
      const updatedUsers = users.map(user => 
        user.id === editingUser.id 
          ? { ...user, ...userForm, password: userForm.password || user.password }
          : user
      );

      setUsers(updatedUsers);
      setSuccess('User updated successfully!');
      handleCloseUserDialog();
    } catch (error) {
      setError('Failed to update user');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (id) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      try {
        setLoading(true);
        setError(null);
        
        // Mock API call - Replace with actual API
        const updatedUsers = users.filter(user => user.id !== id);
        setUsers(updatedUsers);
        setSuccess('User deleted successfully!');
      } catch (error) {
        setError('Failed to delete user');
      } finally {
        setLoading(false);
      }
    }
  };

  const handleRenewLicense = async () => {
    try {
      setLoading(true);
      setError(null);
      setSuccess(null);

      // Mock API call - Replace with actual API
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setSystemInfo(prev => ({
        ...prev,
        licenseStatus: 'active',
        daysRemaining: 365,
        lastBackup: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
      }));
      
      setSuccess('License renewed successfully!');
    } catch (error) {
      setError('Failed to renew license');
    } finally {
      setLoading(false);
    }
  };

  const handleBackupDatabase = async () => {
    try {
      setLoading(true);
      setError(null);
      setSuccess(null);

      // Mock API call - Replace with actual API
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setSystemInfo(prev => ({
        ...prev,
        lastBackup: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
      }));
      
      setSuccess('Database backup completed successfully!');
    } catch (error) {
      setError('Failed to backup database');
    } finally {
      setLoading(false);
    }
  };

  const handleRestoreDatabase = async () => {
    try {
      setLoading(true);
      setError(null);
      setSuccess(null);

      if (!window.confirm('Are you sure you want to restore database? This will overwrite current data.')) {
        return;
      }

      // Mock API call - Replace with actual API
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setSuccess('Database restore completed successfully!');
    } catch (error) {
      setError('Failed to restore database');
    } finally {
      setLoading(false);
    }
  };

  const getRoleColor = (role) => {
    switch(role) {
      case 'admin':
        return { bg: '#0066b3', color: 'white' };
      case 'owner':
        return { bg: '#00a859', color: 'white' };
      case 'manager':
        return { bg: '#ff6b00', color: 'white' };
      case 'accountant':
        return { bg: '#6f42c1', color: 'white' };
      default:
        return { bg: '#6c757d', color: 'white' };
    }
  };

  const getSystemStatusColor = (status) => {
    return status === 'operational' ? '#00a859' : '#dc3545';
  };

  if (loading && !openUserDialog) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ mb: 4, color: '#004b87' }}>
        <SettingsIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
        Admin Settings
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {success && (
        <Alert severity="success" sx={{ mb: 3 }} onClose={() => setSuccess(null)}>
          {success}
        </Alert>
      )}

      {/* License and User Management Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#004b87' }}>
                <SecurityIcon sx={{ mr: 1 }} />
                License Management
              </Typography>
              <FormControl fullWidth sx={{ mb: 2 }}>
                <InputLabel>License Type</InputLabel>
                <Select
                  name="licenseType"
                  value={licenseForm.licenseType}
                  onChange={handleLicenseFormChange}
                  label="License Type"
                  size="small"
                >
                  <MenuItem value="Basic (1 Year)">Basic (1 Year)</MenuItem>
                  <MenuItem value="Standard (2 Years)">Standard (2 Years)</MenuItem>
                  <MenuItem value="Premium (3 Years)">Premium (3 Years)</MenuItem>
                </Select>
              </FormControl>
              <TextField
                fullWidth
                type="date"
                label="License Expiry Date"
                name="expiryDate"
                value={licenseForm.expiryDate}
                onChange={handleLicenseFormChange}
                InputLabelProps={{ shrink: true }}
                size="small"
                sx={{ mb: 2 }}
              />
              <Box sx={{ p: 1.5, backgroundColor: '#e8f5e8', borderRadius: 1, mb: 2 }}>
                <Typography variant="body2" sx={{ color: '#00a859', display: 'flex', alignItems: 'center' }}>
                  <CheckIcon sx={{ mr: 1 }} />
                  {systemInfo.licenseStatus === 'active' ? 'Active' : 'Expired'} 
                  (Expires in {systemInfo.daysRemaining} days)
                </Typography>
              </Box>
              <Button
                fullWidth
                variant="contained"
                startIcon={<RefreshIcon />}
                onClick={handleRenewLicense}
                sx={{ background: 'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)' }}
              >
                Renew License
              </Button>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#004b87' }}>
                <PersonAddIcon sx={{ mr: 1 }} />
                User Management
              </Typography>
              <TextField
                fullWidth
                label="Username"
                name="username"
                value={userForm.username}
                onChange={handleUserFormChange}
                size="small"
                sx={{ mb: 2 }}
              />
              <TextField
                fullWidth
                type="password"
                label="Password"
                name="password"
                value={userForm.password}
                onChange={handleUserFormChange}
                size="small"
                sx={{ mb: 2 }}
                placeholder={editingUser ? "Leave blank to keep current" : ""}
              />
              <TextField
                fullWidth
                label="Full Name"
                name="fullName"
                value={userForm.fullName}
                onChange={handleUserFormChange}
                size="small"
                sx={{ mb: 2 }}
              />
              <FormControl fullWidth sx={{ mb: 2 }}>
                <InputLabel>Role</InputLabel>
                <Select
                  name="role"
                  value={userForm.role}
                  onChange={handleUserFormChange}
                  label="Role"
                  size="small"
                >
                  <MenuItem value="owner">Owner</MenuItem>
                  <MenuItem value="manager">Manager</MenuItem>
                  <MenuItem value="accountant">Accountant</MenuItem>
                  <MenuItem value="operator">Operator</MenuItem>
                </Select>
              </FormControl>
              <Button
                fullWidth
                variant="contained"
                startIcon={<PersonAddIcon />}
                onClick={editingUser ? handleUpdateUser : handleCreateUser}
                sx={{ background: 'linear-gradient(135deg, #0066b3 0%, #0083d4 100%)' }}
              >
                {editingUser ? 'Update User' : 'Create User'}
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* System Configuration */}
      <Card sx={{ mb: 4 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#004b87' }}>
            <StorageIcon sx={{ mr: 1 }} />
            System Configuration
          </Typography>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2, height: '100%' }}>
                <Typography variant="subtitle1" gutterBottom sx={{ color: '#004b87' }}>
                  Backup & Restore
                </Typography>
                <Button
                  fullWidth
                  variant="contained"
                  startIcon={<DownloadIcon />}
                  onClick={handleBackupDatabase}
                  sx={{ mb: 2, background: 'linear-gradient(135deg, #0066b3 0%, #0083d4 100%)' }}
                >
                  Backup Database
                </Button>
                <Button
                  fullWidth
                  variant="outlined"
                  startIcon={<UploadIcon />}
                  onClick={handleRestoreDatabase}
                  sx={{ color: '#0066b3', borderColor: '#0066b3' }}
                >
                  Restore Database
                </Button>
              </Paper>
            </Grid>
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2, height: '100%' }}>
                <Typography variant="subtitle1" gutterBottom sx={{ color: '#004b87' }}>
                  System Information
                </Typography>
                <Box sx={{ mb: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    Version:
                  </Typography>
                  <Typography variant="body1" fontWeight="medium">
                    {systemInfo.version}
                  </Typography>
                </Box>
                <Box sx={{ mb: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    Last Backup:
                  </Typography>
                  <Typography variant="body1" fontWeight="medium">
                    {systemInfo.lastBackup}
                  </Typography>
                </Box>
                <Box sx={{ mb: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    Database Size:
                  </Typography>
                  <Typography variant="body1" fontWeight="medium">
                    {systemInfo.dbSize}
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    System Status:
                  </Typography>
                  <Typography variant="body1" fontWeight="medium" sx={{ color: getSystemStatusColor(systemInfo.status) }}>
                    {systemInfo.status === 'operational' ? 'All Systems Operational' : 'System Issues Detected'}
                  </Typography>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#004b87' }}>
            <PersonAddIcon sx={{ mr: 1 }} />
            User List
          </Typography>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow sx={{ bgcolor: '#f8f9fa' }}>
                  <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>User</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Username</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Role</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Created</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {users.map((user) => {
                  const roleColors = getRoleColor(user.role);
                  return (
                    <TableRow key={user.id} hover>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <Box
                            sx={{
                              width: 40,
                              height: 40,
                              borderRadius: '50%',
                              backgroundColor: '#0066b3',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              color: 'white',
                              fontWeight: 'bold',
                              mr: 2,
                            }}
                          >
                            {user.avatar}
                          </Box>
                          <Box>
                            <Typography variant="body1" fontWeight="medium">
                              {user.fullName}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {user.email || 'No email'}
                            </Typography>
                          </Box>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">{user.username}</Typography>
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                          size="small"
                          sx={{
                            backgroundColor: roleColors.bg,
                            color: roleColors.color,
                            fontWeight: 'medium',
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {new Date(user.createdAt).toLocaleDateString()}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: 1 }}>
                          <IconButton
                            color="primary"
                            onClick={() => handleOpenUserDialog(user)}
                            size="small"
                            sx={{ 
                              backgroundColor: 'rgba(0, 102, 179, 0.1)',
                              '&:hover': { backgroundColor: 'rgba(0, 102, 179, 0.2)' }
                            }}
                          >
                            <EditIcon fontSize="small" />
                          </IconButton>
                          {user.role !== 'admin' && (
                            <IconButton
                              color="error"
                              onClick={() => handleDeleteUser(user.id)}
                              size="small"
                              sx={{ 
                                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                                '&:hover': { backgroundColor: 'rgba(220, 53, 69, 0.2)' }
                              }}
                            >
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          )}
                        </Box>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* User Dialog */}
      <Dialog open={openUserDialog} onClose={handleCloseUserDialog} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ color: '#004b87' }}>
          {editingUser ? 'Edit User' : 'Add New User'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Username"
                name="username"
                value={userForm.username}
                onChange={handleUserFormChange}
                size="small"
                disabled={!!editingUser}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                type="password"
                label="Password"
                name="password"
                value={userForm.password}
                onChange={handleUserFormChange}
                size="small"
                placeholder={editingUser ? "Leave blank to keep current password" : ""}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Full Name"
                name="fullName"
                value={userForm.fullName}
                onChange={handleUserFormChange}
                size="small"
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth size="small">
                <InputLabel>Role</InputLabel>
                <Select
                  name="role"
                  value={userForm.role}
                  onChange={handleUserFormChange}
                  label="Role"
                >
                  <MenuItem value="owner">Owner</MenuItem>
                  <MenuItem value="manager">Manager</MenuItem>
                  <MenuItem value="accountant">Accountant</MenuItem>
                  <MenuItem value="operator">Operator</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseUserDialog} sx={{ color: '#666' }}>
            Cancel
          </Button>
          <Button 
            variant="contained" 
            onClick={editingUser ? handleUpdateUser : handleCreateUser}
            sx={{ background: 'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)' }}
          >
            {editingUser ? 'Update' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Admin;