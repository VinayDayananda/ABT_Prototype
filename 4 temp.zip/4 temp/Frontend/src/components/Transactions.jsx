import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Grid,
  IconButton,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  CircularProgress,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon,
  Download as DownloadIcon,
  Print as PrintIcon,
  FilterList as FilterIcon,
} from '@mui/icons-material';
import { purchaseService } from '../services/purchaseService';
import { farmerService } from '../services/farmerService';
import { format } from 'date-fns';

const Transactions = () => {
  const [transactions, setTransactions] = useState([]);
  const [farmers, setFarmers] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');
  const [selectedFarmer, setSelectedFarmer] = useState('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    farmerId: '',
    purchaseDate: format(new Date(), 'yyyy-MM-dd'),
    weightKg: '',
    ratePerQuintal: '',
    advancePaid: '',
    paymentMethod: 'CASH',
    tenderOption: 'WAIT_NEXT_TENDER',
    notes: '',
  });

  useEffect(() => {
    fetchTransactions();
    fetchFarmers();
  }, []);

  const fetchTransactions = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await purchaseService.getAllPurchases();
      setTransactions(response.data);
    } catch (error) {
      console.error('Error fetching transactions:', error);
      setError('Failed to load transactions. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const fetchFarmers = async () => {
    try {
      const response = await farmerService.getAllFarmers();
      setFarmers(response.data);
    } catch (error) {
      console.error('Error fetching farmers:', error);
    }
  };

  const handleOpenDialog = (transaction = null) => {
    if (transaction) {
      setEditingTransaction(transaction);
      setFormData({
        farmerId: transaction.farmerId,
        purchaseDate: format(new Date(transaction.purchaseDate), 'yyyy-MM-dd'),
        weightKg: transaction.weightKg,
        ratePerQuintal: transaction.ratePerQuintal,
        advancePaid: transaction.advancePaid,
        paymentMethod: transaction.paymentMethod,
        tenderOption: transaction.tenderOption,
        notes: transaction.notes || '',
      });
    } else {
      setEditingTransaction(null);
      setFormData({
        farmerId: '',
        purchaseDate: format(new Date(), 'yyyy-MM-dd'),
        weightKg: '',
        ratePerQuintal: '',
        advancePaid: '',
        paymentMethod: 'CASH',
        tenderOption: 'WAIT_NEXT_TENDER',
        notes: '',
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingTransaction(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const calculateAmounts = () => {
    const weight = parseFloat(formData.weightKg) || 0;
    const rate = parseFloat(formData.ratePerQuintal) || 0;
    const advance = parseFloat(formData.advancePaid) || 0;
    
    const totalAmount = (weight / 100) * rate;
    const balance = totalAmount - advance;
    
    return {
      totalAmount,
      balance,
      weightQuintal: weight / 100,
    };
  };

  const handleSubmit = async () => {
    try {
      setError(null);
      const amounts = calculateAmounts();
      const transactionData = {
        ...formData,
        totalAmount: amounts.totalAmount,
        balanceDue: amounts.balance,
      };

      if (editingTransaction) {
        await purchaseService.updatePurchase(editingTransaction.id, transactionData);
      } else {
        await purchaseService.createPurchase(transactionData);
      }
      
      await fetchTransactions();
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving transaction:', error);
      setError('Failed to save transaction. Please try again.');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this transaction?')) {
      try {
        setError(null);
        await purchaseService.deletePurchase(id);
        await fetchTransactions();
      } catch (error) {
        console.error('Error deleting transaction:', error);
        setError('Failed to delete transaction. Please try again.');
      }
    }
  };

  const exportTransactions = () => {
    const csvContent = transactions.map(t => 
      `${t.purchaseId},${format(new Date(t.purchaseDate), 'dd/MM/yyyy')},${t.farmerName},${t.weightKg},${t.ratePerQuintal},${t.totalAmount},${t.advancePaid},${t.balanceDue},${t.tenderOption},${t.status}`
    ).join('\n');
    
    const blob = new Blob([`ID,Date,Farmer,Weight(kg),Rate(₹/q),Total(₹),Advance(₹),Balance(₹),Tender,Status\n${csvContent}`], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'transactions.csv';
    a.click();
  };

  const filteredTransactions = transactions.filter((transaction) => {
    // Search filter
    const matchesSearch = 
      transaction.purchaseId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.farmerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.farmerCode?.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Farmer filter
    const matchesFarmer = selectedFarmer === 'all' || transaction.farmerId == selectedFarmer;
    
    // Date filter
    const transactionDate = new Date(transaction.purchaseDate);
    const start = startDate ? new Date(startDate) : null;
    const end = endDate ? new Date(endDate) : null;
    
    const matchesDate = 
      (!start || transactionDate >= start) && 
      (!end || transactionDate <= end);
    
    // Status filter
    let matchesStatus = true;
    if (filter === 'today') {
      const today = new Date();
      matchesStatus = format(transactionDate, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd');
    } else if (filter === 'week') {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      matchesStatus = transactionDate >= weekAgo;
    } else if (filter === 'month') {
      const monthAgo = new Date();
      monthAgo.setMonth(monthAgo.getMonth() - 1);
      matchesStatus = transactionDate >= monthAgo;
    }
    
    return matchesSearch && matchesFarmer && matchesDate && matchesStatus;
  });

const getStatusInfo = (balance, tenderOption) => {
  if (balance === 0) {
    return { text: 'Paid', color: '#00a859', bg: '#e8f5e8' };
  } else if (tenderOption === 'WAIT_NEXT_TENDER') {
    return { text: 'Waiting', color: '#0066b3', bg: '#e3f2fd' };
  } else {
    return { text: 'Pending', color: '#ff6b00', bg: '#fff3cd' };
  }
};

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ color: '#004b87' }}>
          <FilterIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
          Copra Transactions
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
          sx={{ background: 'linear-gradient(135deg, #0066b3 0%, #0083d4 100%)' }}
        >
          New Transaction
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Filter Bar */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={2}>
            <TextField
              fullWidth
              type="date"
              label="From"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              size="small"
            />
          </Grid>
          <Grid item xs={12} md={2}>
            <TextField
              fullWidth
              type="date"
              label="To"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              size="small"
            />
          </Grid>
          <Grid item xs={12} md={2}>
            <FormControl fullWidth size="small">
              <InputLabel>Period</InputLabel>
              <Select
                value={filter}
                label="Period"
                onChange={(e) => setFilter(e.target.value)}
              >
                <MenuItem value="all">All Transactions</MenuItem>
                <MenuItem value="today">Today</MenuItem>
                <MenuItem value="week">This Week</MenuItem>
                <MenuItem value="month">This Month</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={2}>
            <FormControl fullWidth size="small">
              <InputLabel>Farmer</InputLabel>
              <Select
                value={selectedFarmer}
                label="Farmer"
                onChange={(e) => setSelectedFarmer(e.target.value)}
              >
                <MenuItem value="all">All Farmers</MenuItem>
                {farmers.map((farmer) => (
                  <MenuItem key={farmer.id} value={farmer.id}>
                    {farmer.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={3}>
            <TextField
              fullWidth
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
              size="small"
            />
          </Grid>
          <Grid item xs={12} md={1}>
            <Button
              fullWidth
              variant="outlined"
              startIcon={<DownloadIcon />}
              onClick={exportTransactions}
              sx={{ color: '#0066b3', borderColor: '#0066b3' }}
            >
              Export
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* Transactions Table */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow sx={{ bgcolor: '#f8f9fa' }}>
              <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Date</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>ID</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Farmer</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Copra (kg)</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Rate (₹/q)</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Total (₹)</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Advance (₹)</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Balance (₹)</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Tender</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Status</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredTransactions.length > 0 ? (
              filteredTransactions.map((transaction) => {
                const statusInfo = getStatusInfo(transaction.balanceDue, transaction.tenderOption);
                return (
                  <TableRow key={transaction.id} hover>
                    <TableCell>
                      {format(new Date(transaction.purchaseDate), 'dd/MM/yyyy')}
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" fontWeight="medium">
                        {transaction.purchaseId}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Box>
                        <Typography variant="body2" fontWeight="medium">
                          {transaction.farmerName}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {transaction.farmerCode}
                        </Typography>
                      </Box>
                    </TableCell>
                    <TableCell align="right">
                      {parseFloat(transaction.weightKg).toLocaleString('en-IN', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </TableCell>
                    <TableCell align="right">
                      {parseFloat(transaction.ratePerQuintal).toLocaleString()}
                    </TableCell>
                    <TableCell align="right">
                      <Typography fontWeight="medium">
                        ₹{parseFloat(transaction.totalAmount).toLocaleString('en-IN', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      ₹{parseFloat(transaction.advancePaid || 0).toLocaleString('en-IN', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </TableCell>
                    <TableCell align="right">
                      <Typography
                        fontWeight="bold"
                        color={transaction.balanceDue > 0 ? 'error' : 'success'}
                      >
                        ₹{parseFloat(transaction.balanceDue || 0).toLocaleString('en-IN', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={transaction.tenderOption === 'SELL_TODAY' ? 'Today' : 'Next'}
                        size="small"
                        sx={{
                          backgroundColor: transaction.tenderOption === 'SELL_TODAY' ? '#e8f5e8' : '#fff3cd',
                          color: transaction.tenderOption === 'SELL_TODAY' ? '#00a859' : '#856404',
                        }}
                      />
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={statusInfo.text}
                        size="small"
                        sx={{
                          backgroundColor: statusInfo.bg,
                          color: statusInfo.color,
                          fontWeight: 'medium',
                        }}
                      />
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', gap: 0.5 }}>
                        <IconButton
                          color="primary"
                          onClick={() => handleOpenDialog(transaction)}
                          size="small"
                          sx={{ 
                            backgroundColor: 'rgba(0, 102, 179, 0.1)',
                            '&:hover': { backgroundColor: 'rgba(0, 102, 179, 0.2)' }
                          }}
                        >
                          <EditIcon fontSize="small" />
                        </IconButton>
                        <IconButton
                          color="error"
                          onClick={() => handleDelete(transaction.id)}
                          size="small"
                          sx={{ 
                            backgroundColor: 'rgba(220, 53, 69, 0.1)',
                            '&:hover': { backgroundColor: 'rgba(220, 53, 69, 0.2)' }
                          }}
                        >
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                        <IconButton
                          color="warning"
                          size="small"
                          sx={{ 
                            backgroundColor: 'rgba(255, 107, 0, 0.1)',
                            '&:hover': { backgroundColor: 'rgba(255, 107, 0, 0.2)' }
                          }}
                        >
                          <PrintIcon fontSize="small" />
                        </IconButton>
                      </Box>
                    </TableCell>
                  </TableRow>
                );
              })
            ) : (
              <TableRow>
                <TableCell colSpan={11} align="center" sx={{ py: 4 }}>
                  <Typography variant="body1" color="text.secondary">
                    No transactions found
                  </Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Transaction Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ color: '#004b87' }}>
          {editingTransaction ? 'Edit Transaction' : 'New Copra Transaction'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <FormControl fullWidth size="small">
                <InputLabel>Farmer</InputLabel>
                <Select
                  name="farmerId"
                  value={formData.farmerId}
                  onChange={handleInputChange}
                  label="Farmer"
                >
                  <MenuItem value="">Select Farmer</MenuItem>
                  {farmers.map((farmer) => (
                    <MenuItem key={farmer.id} value={farmer.id}>
                      {farmer.name} ({farmer.farmerCode})
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                type="date"
                label="Date"
                name="purchaseDate"
                value={formData.purchaseDate}
                onChange={handleInputChange}
                InputLabelProps={{ shrink: true }}
                size="small"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                type="number"
                label="Weight (KG)"
                name="weightKg"
                value={formData.weightKg}
                onChange={handleInputChange}
                size="small"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                type="number"
                label="Rate per Quintal"
                name="ratePerQuintal"
                value={formData.ratePerQuintal}
                onChange={handleInputChange}
                size="small"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                type="number"
                label="Advance Amount (₹)"
                name="advancePaid"
                value={formData.advancePaid}
                onChange={handleInputChange}
                size="small"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth size="small">
                <InputLabel>Payment Method</InputLabel>
                <Select
                  name="paymentMethod"
                  value={formData.paymentMethod}
                  onChange={handleInputChange}
                  label="Payment Method"
                >
                  <MenuItem value="CASH">Cash</MenuItem>
                  <MenuItem value="BANK_TRANSFER">Bank Transfer</MenuItem>
                  <MenuItem value="UPI">UPI</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth size="small">
                <InputLabel>Tender Option</InputLabel>
                <Select
                  name="tenderOption"
                  value={formData.tenderOption}
                  onChange={handleInputChange}
                  label="Tender Option"
                >
                  <MenuItem value="SELL_TODAY">Sell Today</MenuItem>
                  <MenuItem value="WAIT_NEXT_TENDER">Wait for Next Tender</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Notes"
                name="notes"
                value={formData.notes}
                onChange={handleInputChange}
                multiline
                rows={2}
                size="small"
              />
            </Grid>
            {formData.weightKg && formData.ratePerQuintal && (
              <Grid item xs={12}>
                <Paper sx={{ p: 2, backgroundColor: '#f8f9fa' }}>
                  <Typography variant="subtitle2" gutterBottom>
                    Amount Calculation
                  </Typography>
                  <Grid container spacing={1}>
                    <Grid item xs={6}>
                      <Typography variant="body2">Weight in Quintal:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2" align="right">
                        {(parseFloat(formData.weightKg) / 100).toFixed(2)} q
                      </Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2">Total Amount:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2" align="right" fontWeight="bold">
                        ₹{calculateAmounts().totalAmount.toLocaleString('en-IN', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2">Balance:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography 
                        variant="body2" 
                        align="right" 
                        fontWeight="bold"
                        color={calculateAmounts().balance > 0 ? 'error' : 'success'}
                      >
                        ₹{calculateAmounts().balance.toLocaleString('en-IN', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </Typography>
                    </Grid>
                  </Grid>
                </Paper>
              </Grid>
            )}
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} sx={{ color: '#666' }}>
            Cancel
          </Button>
          <Button 
            variant="contained" 
            onClick={handleSubmit}
            sx={{ background: 'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)' }}
          >
            {editingTransaction ? 'Update' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Transactions;