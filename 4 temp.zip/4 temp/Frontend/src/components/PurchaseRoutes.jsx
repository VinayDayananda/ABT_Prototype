import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Purchase from './Purchase';
import PurchaseSummary from './PurchaseSummary';

const PurchaseRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Purchase />} />
      <Route path="/new" element={<Purchase />} />
      <Route path="/history" element={<PurchaseSummary />} />
    </Routes>
  );
};

export default PurchaseRoutes;