import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  CircularProgress,
} from '@mui/material';
import {
  People as PeopleIcon,
  ShoppingCart as PurchaseIcon,
  AttachMoney as MoneyIcon,
  Store as StoreIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({
    totalFarmers: 0,
    totalCopra: 0,
    pendingPayments: 0,
    activeMerchants: 0,
  });

  useEffect(() => {
    // Simple initialization - no API calls for now
    setLoading(false);
  }, []);

  const statCards = [
    {
      title: 'Registered Farmers',
      value: stats.totalFarmers,
      icon: <PeopleIcon />,
      color: '#0066b3',
      path: '/farmers',
    },
    {
      title: 'Current Copra Stock',
      value: `${stats.totalCopra} kg`,
      icon: <PurchaseIcon />,
      color: '#00a859',
      path: '/transactions',
    },
    {
      title: 'Pending Payments',
      value: `₹${stats.pendingPayments}`,
      icon: <MoneyIcon />,
      color: '#ff6b00',
      path: '/transactions',
    },
    {
      title: 'Active Merchants',
      value: stats.activeMerchants,
      icon: <StoreIcon />,
      color: '#0083d4',
      path: '/merchants',
    },
  ];

  const quickActions = [
    { label: 'Add New Farmer', path: '/farmers', color: '#0066b3' },
    { label: 'Record Purchase', path: '/purchase', color: '#00a859' },
    { label: 'Add Merchant', path: '/merchants', color: '#0083d4' },
    { label: 'View Reports', path: '/reports', color: '#ff6b00' },
  ];

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ mb: 4, color: '#004b87' }}>
        Dashboard Overview
      </Typography>

      {/* Welcome Banner */}
      <Paper sx={{ p: 3, mb: 4, background: 'linear-gradient(135deg, #004b87 0%, #0066b3 100%)', color: 'white' }}>
        <Typography variant="h5" gutterBottom>
          Welcome to Ambika Traders!
        </Typography>
        <Typography variant="body1" sx={{ opacity: 0.9 }}>
          Copra Management System
        </Typography>
        <Typography variant="caption" sx={{ display: 'block', mt: 2, opacity: 0.7 }}>
          Get started by adding farmers, recording purchases, and managing merchants
        </Typography>
      </Paper>

      {/* Quick Actions */}
      <Typography variant="h6" gutterBottom sx={{ mb: 2, color: '#004b87' }}>
        Quick Actions
      </Typography>
      <Grid container spacing={2} sx={{ mb: 4 }}>
        {quickActions.map((action, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <Button
              fullWidth
              variant="contained"
              onClick={() => navigate(action.path)}
              sx={{
                p: 3,
                background: `linear-gradient(135deg, ${action.color} 0%, ${action.color}80 100%)`,
                color: 'white',
                fontSize: '1rem',
                fontWeight: 'bold',
                '&:hover': {
                  transform: 'translateY(-2px)',
                  boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
                },
                transition: 'all 0.3s ease',
              }}
            >
              {action.label}
            </Button>
          </Grid>
        ))}
      </Grid>

      {/* Stats Grid - Placeholder */}
      <Typography variant="h6" gutterBottom sx={{ mb: 2, color: '#004b87' }}>
        System Overview
      </Typography>
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {statCards.map((stat, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <Card
              sx={{
                height: '100%',
                borderLeft: `4px solid ${stat.color}`,
                transition: 'all 0.3s ease',
                cursor: 'pointer',
                '&:hover': {
                  transform: 'translateY(-4px)',
                  boxShadow: '0 8px 25px rgba(0,0,0,0.15)',
                },
              }}
              onClick={() => navigate(stat.path)}
            >
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Box
                    sx={{
                      width: 60,
                      height: 60,
                      borderRadius: 2,
                      backgroundColor: stat.color,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'white',
                      mr: 2,
                    }}
                  >
                    {stat.icon}
                  </Box>
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="h4" component="div" sx={{ fontWeight: 'bold' }}>
                      {stat.value}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {stat.title}
                    </Typography>
                  </Box>
                </Box>
                <Typography variant="caption" sx={{ color: '#666', display: 'block', mt: 0.5 }}>
                  Click to view details
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Getting Started Guide */}
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom sx={{ color: '#004b87' }}>
          Getting Started Guide
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, backgroundColor: '#f8f9fa', borderRadius: 2 }}>
              <Typography variant="subtitle1" gutterBottom sx={{ color: '#004b87' }}>
                1. Add Farmers
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Go to "Farmers" page to register new farmers with their contact and bank details
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, backgroundColor: '#f8f9fa', borderRadius: 2 }}>
              <Typography variant="subtitle1" gutterBottom sx={{ color: '#004b87' }}>
                2. Record Purchases
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Use "New Purchase" page to record copra purchases from farmers
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, backgroundColor: '#f8f9fa', borderRadius: 2 }}>
              <Typography variant="subtitle1" gutterBottom sx={{ color: '#004b87' }}>
                3. Manage Merchants
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Add merchants in "Merchants" page for selling copra
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 2, backgroundColor: '#f8f9fa', borderRadius: 2 }}>
              <Typography variant="subtitle1" gutterBottom sx={{ color: '#004b87' }}>
                4. View Transactions
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Check all purchases and payments in "Transactions" page
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Paper>

      {/* Footer Note */}
      <Box sx={{ mt: 4, textAlign: 'center' }}>
        <Typography variant="body2" color="text.secondary">
          Note: Data will be loaded automatically when backend APIs are configured
        </Typography>
      </Box>
    </Box>
  );
};

export default Dashboard;