import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Grid,
  Card,
  CardContent,
  IconButton,
  Chip,
  Divider,
  CircularProgress,
} from '@mui/material';
import {
  Send as SendIcon,
  Help as HelpIcon,
  Person as PersonIcon,
  SmartToy as BotIcon,
  ArrowForward as ArrowIcon,
  QuestionAnswer as QAIcon,
  Description as DocIcon,
  Phone as PhoneIcon,
  Email as EmailIcon,
  Schedule as ScheduleIcon,
} from '@mui/icons-material';

const Help = () => {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const quickQuestions = [
    { id: 'add_farmer', text: 'How to add a new farmer?' },
    { id: 'new_purchase', text: 'How to record a new copra purchase?' },
    { id: 'tender_rates', text: 'How to update tender rates?' },
    { id: 'generate_bill', text: 'How to generate a bill?' },
    { id: 'sales_merchant', text: 'How to sell copra to merchants?' },
    { id: 'reports', text: 'How to generate reports?' },
  ];

  useEffect(() => {
    // Initial bot message
    setMessages([
      {
        id: 1,
        text: "Hello! I'm the Ambika Traders Assistant. I'm here to help you with the Copra Management System. How can I assist you today?",
        sender: 'bot',
        timestamp: new Date(),
      },
    ]);
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const getBotResponse = (userMessage) => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('farmer') || lowerMessage.includes('add')) {
      return {
        text: `To add a new farmer:\n
1. Go to the "Farmers" tab\n
2. Click "Add New Farmer" button\n
3. Fill in the farmer details:\n   - Full Name\n   - Mobile Number\n   - Address\n   - Village\n   - Bank Details\n   - UPI ID\n
4. Upload a photo if needed\n
5. Click "Save Farmer"\n\n
The system will automatically generate a farmer code and add them to your database.`,
        quickLinks: ['Farmers Management', 'Add Farmer']
      };
    } else if (lowerMessage.includes('purchase') || lowerMessage.includes('buy')) {
      return {
        text: `To record a new copra purchase:\n
1. Go to the "New Purchase" tab\n
2. Select the farmer from dropdown\n
3. Enter the purchase date\n
4. Enter copra weight in kg (system auto-converts to quintal)\n
5. Enter current market rate per kg\n
6. Choose tender option:\n   - Sell Today: Immediate sale\n   - Wait for Next Tender: Hold for better price\n
7. Enter advance amount if any\n
8. Select payment method (Cash/UPI/Bank)\n
9. Click "Save & Print Bill"\n\n
The system will calculate total amount and generate a printable bill.`,
        quickLinks: ['New Purchase', 'Generate Bill']
      };
    } else if (lowerMessage.includes('rate') || lowerMessage.includes('tender')) {
      return {
        text: `To update tender rates:\n
1. Go to the "Tender Rates" tab\n
2. Click "Add New Rate"\n
3. Select market:\n   - Tiptur Market (Monday & Thursday)\n   - Arsikere Market (Tuesday & Friday)\n
4. Enter the date\n
5. Enter rate per quintal\n
6. Click "Save Rate"\n\n
The system automatically tracks rate changes and shows trends in charts. You can view historical rates and compare markets.`,
        quickLinks: ['Tender Rates', 'Market Trends']
      };
    } else if (lowerMessage.includes('bill') || lowerMessage.includes('print')) {
      return {
        text: `To generate a bill:\n
OPTION 1 - From New Purchase:\n
1. After saving a purchase, click "Generate Bill"\n
2. System opens print-friendly format\n
3. Print directly or save as PDF\n\n
OPTION 2 - From Transactions:\n
1. Go to "Transactions" tab\n
2. Find the transaction\n
3. Click print icon\n\n
Bill includes:\n- Company details\n- Farmer information\n- Copra quantity & rate\n- Amount calculation\n- Advance paid & balance\n- Payment terms`,
        quickLinks: ['Transactions', 'Print Bill']
      };
    } else if (lowerMessage.includes('sale') || lowerMessage.includes('merchant')) {
      return {
        text: `To sell copra to merchants:\n
1. Go to the "Sales" tab\n
2. Click "New Sale"\n
3. Select merchant from dropdown\n
4. Enter sale details:\n   - Sale date\n   - Copra weight\n   - Sale rate per quintal\n   - Average purchase rate\n
5. System calculates profit automatically\n
6. Select payment method\n
7. Click "Save Sale"\n\n
Features:\n- Profit calculation\n- Stock management\n- Merchant history\n- Export sales data`,
        quickLinks: ['Sales', 'Merchants']
      };
    } else if (lowerMessage.includes('report') || lowerMessage.includes('analysis')) {
      return {
        text: `To generate reports:\n
1. Go to the "Reports" tab\n
2. Select report period:\n   - Today\n   - This Week\n   - This Month\n   - This Quarter\n   - This Year\n   - Custom Range\n
3. View statistics:\n   - Total copra purchased\n   - Amount paid vs pending\n   - Sales revenue & profit\n   - Loan amounts\n
4. Charts available:\n   - Monthly purchase trend\n   - Top farmers by volume\n   - Payment status distribution\n
5. Click "Export Report" to download\n\n
Available reports:\n- Purchase summary\n- Payment status\n- Sales analysis\n- Farmer performance\n- Profit & loss`,
        quickLinks: ['Reports', 'Export Data']
      };
    } else if (lowerMessage.includes('admin') || lowerMessage.includes('setting')) {
      return {
        text: `Admin settings are available in the "Admin" tab:\n\n
LICENSE MANAGEMENT:\n- View license status\n- Renew license\n- Update expiry date\n\n
USER MANAGEMENT:\n- Add new users\n- Edit existing users\n- Assign roles (Owner/Manager/Accountant/Operator)\n- Delete users\n\n
SYSTEM CONFIGURATION:\n- Backup database\n- Restore database\n- View system information\n- Check database size\n- Monitor system status\n\n
Note: Admin access is restricted to authorized users only.`,
        quickLinks: ['Admin Settings', 'User Management']
      };
    } else {
      return {
        text: "I'm here to help you with the Copra Management System. You can ask about:\n\n• Adding and managing farmers\n• Recording copra purchases\n• Updating tender rates\n• Generating bills\n• Selling to merchants\n• Creating reports\n• Admin settings\n\nUse the quick questions below or type your specific question.",
        quickLinks: ['Quick Start', 'Documentation']
      };
    }
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    // Add user message
    const userMessage = {
      id: messages.length + 1,
      text: inputMessage,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setLoading(true);

    // Simulate bot response delay
    setTimeout(() => {
      const botResponse = getBotResponse(inputMessage);
      const botMessage = {
        id: messages.length + 2,
        text: botResponse.text,
        sender: 'bot',
        timestamp: new Date(),
        quickLinks: botResponse.quickLinks,
      };
      setMessages(prev => [...prev, botMessage]);
      setLoading(false);
    }, 1000);
  };

  const handleQuickQuestion = (questionId) => {
    let questionText = '';
    switch(questionId) {
      case 'add_farmer':
        questionText = 'How to add a new farmer?';
        break;
      case 'new_purchase':
        questionText = 'How to record a new copra purchase?';
        break;
      case 'tender_rates':
        questionText = 'How to update tender rates?';
        break;
      case 'generate_bill':
        questionText = 'How to generate a bill?';
        break;
      case 'sales_merchant':
        questionText = 'How to sell copra to merchants?';
        break;
      case 'reports':
        questionText = 'How to generate reports?';
        break;
      default:
        questionText = 'How can I use this system?';
    }
    setInputMessage(questionText);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const contactInfo = [
    { icon: <PhoneIcon />, label: 'Support Phone', value: '+91 98765 43210', color: '#0066b3' },
    { icon: <EmailIcon />, label: 'Email', value: 'support@ambikatraders.com', color: '#00a859' },
    { icon: <ScheduleIcon />, label: 'Support Hours', value: '9:00 AM - 6:00 PM (Mon-Sat)', color: '#ff6b00' },
  ];

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ mb: 4, color: '#004b87' }}>
        <HelpIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
        Help & Support
      </Typography>

      <Grid container spacing={3}>
        {/* Left Column - Chat Assistant */}
        <Grid item xs={12} md={8}>
          <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <CardContent sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#004b87' }}>
                <QAIcon sx={{ mr: 1 }} />
                Chat Assistant
              </Typography>
              
              {/* Chat Messages */}
              <Paper 
                sx={{ 
                  flex: 1, 
                  p: 2, 
                  mb: 2, 
                  backgroundColor: '#f9f9f9',
                  overflow: 'auto',
                  maxHeight: '400px',
                }}
              >
                {messages.map((message) => (
                  <Box
                    key={message.id}
                    sx={{
                      mb: 2,
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: message.sender === 'user' ? 'flex-end' : 'flex-start',
                    }}
                  >
                    <Box
                      sx={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        maxWidth: '80%',
                      }}
                    >
                      {message.sender === 'bot' && (
                        <Box
                          sx={{
                            width: 32,
                            height: 32,
                            borderRadius: '50%',
                            backgroundColor: '#00a859',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: 'white',
                            mr: 1,
                            mt: 0.5,
                          }}
                        >
                          <BotIcon fontSize="small" />
                        </Box>
                      )}
                      <Paper
                        sx={{
                          p: 2,
                          backgroundColor: message.sender === 'user' ? '#0066b3' : 'white',
                          color: message.sender === 'user' ? 'white' : 'inherit',
                          borderRadius: 2,
                          borderTopLeftRadius: message.sender === 'bot' ? 0 : 12,
                          borderTopRightRadius: message.sender === 'user' ? 0 : 12,
                          boxShadow: 1,
                          whiteSpace: 'pre-line',
                        }}
                      >
                        <Typography variant="body2">{message.text}</Typography>
                        
                        {message.quickLinks && (
                          <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                            {message.quickLinks.map((link, index) => (
                              <Chip
                                key={index}
                                label={link}
                                size="small"
                                sx={{
                                  backgroundColor: 'rgba(0, 102, 179, 0.1)',
                                  color: '#0066b3',
                                  fontSize: '0.7rem',
                                  height: '20px',
                                }}
                              />
                            ))}
                          </Box>
                        )}
                      </Paper>
                      {message.sender === 'user' && (
                        <Box
                          sx={{
                            width: 32,
                            height: 32,
                            borderRadius: '50%',
                            backgroundColor: '#0066b3',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: 'white',
                            ml: 1,
                            mt: 0.5,
                          }}
                        >
                          <PersonIcon fontSize="small" />
                        </Box>
                      )}
                    </Box>
                    <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, mx: 1 }}>
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </Typography>
                  </Box>
                ))}
                {loading && (
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Box
                      sx={{
                        width: 32,
                        height: 32,
                        borderRadius: '50%',
                        backgroundColor: '#00a859',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'white',
                        mr: 1,
                      }}
                    >
                      <BotIcon fontSize="small" />
                    </Box>
                    <Paper sx={{ p: 2 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <CircularProgress size={16} sx={{ mr: 1 }} />
                        <Typography variant="body2">Thinking...</Typography>
                      </Box>
                    </Paper>
                  </Box>
                )}
                <div ref={messagesEndRef} />
              </Paper>

              {/* Quick Questions */}
              <Box sx={{ mb: 2 }}>
                <Typography variant="subtitle2" gutterBottom sx={{ color: '#666' }}>
                  Quick Questions:
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  {quickQuestions.map((q) => (
                    <Chip
                      key={q.id}
                      label={q.text}
                      onClick={() => handleQuickQuestion(q.id)}
                      size="small"
                      sx={{
                        backgroundColor: 'rgba(0, 102, 179, 0.1)',
                        color: '#0066b3',
                        border: '1px solid rgba(0, 102, 179, 0.3)',
                        '&:hover': {
                          backgroundColor: 'rgba(0, 102, 179, 0.2)',
                        },
                        cursor: 'pointer',
                      }}
                    />
                  ))}
                </Box>
              </Box>

              {/* Chat Input */}
              <Box sx={{ display: 'flex', gap: 1 }}>
                <TextField
                  fullWidth
                  multiline
                  maxRows={3}
                  placeholder="Type your question here..."
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  variant="outlined"
                  size="small"
                />
                <Button
                  variant="contained"
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim() || loading}
                  sx={{ 
                    background: 'linear-gradient(135deg, #0066b3 0%, #0083d4 100%)',
                    minWidth: '100px',
                  }}
                  endIcon={<SendIcon />}
                >
                  Send
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Right Column - Contact & Resources */}
        <Grid item xs={12} md={4}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#004b87' }}>
                <DocIcon sx={{ mr: 1 }} />
                Resources & Support
              </Typography>

              {/* Contact Information */}
              <Box sx={{ mb: 3 }}>
                <Typography variant="subtitle1" gutterBottom sx={{ color: '#004b87' }}>
                  Contact Support
                </Typography>
                {contactInfo.map((info, index) => (
                  <Box
                    key={index}
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      mb: 2,
                      p: 1.5,
                      backgroundColor: '#f8f9fa',
                      borderRadius: 1,
                      borderLeft: `3px solid ${info.color}`,
                    }}
                  >
                    <Box
                      sx={{
                        width: 40,
                        height: 40,
                        borderRadius: '50%',
                        backgroundColor: info.color,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'white',
                        mr: 2,
                      }}
                    >
                      {info.icon}
                    </Box>
                    <Box>
                      <Typography variant="caption" color="text.secondary">
                        {info.label}
                      </Typography>
                      <Typography variant="body2" fontWeight="medium">
                        {info.value}
                      </Typography>
                    </Box>
                  </Box>
                ))}
              </Box>

              <Divider sx={{ my: 2 }} />

              {/* Quick Links */}
              <Box sx={{ mb: 3 }}>
                <Typography variant="subtitle1" gutterBottom sx={{ color: '#004b87' }}>
                  Quick Links
                </Typography>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                  {[
                    { label: 'User Manual', href: '#', icon: <DocIcon sx={{ mr: 1 }} /> },
                    { label: 'Video Tutorials', href: '#', icon: <ArrowIcon sx={{ mr: 1 }} /> },
                    { label: 'FAQ', href: '#', icon: <QAIcon sx={{ mr: 1 }} /> },
                    { label: 'System Updates', href: '#', icon: <ArrowIcon sx={{ mr: 1 }} /> },
                  ].map((link, index) => (
                    <Button
                      key={index}
                      startIcon={link.icon}
                      href={link.href}
                      sx={{
                        justifyContent: 'flex-start',
                        color: '#0066b3',
                        textTransform: 'none',
                        '&:hover': {
                          backgroundColor: 'rgba(0, 102, 179, 0.1)',
                        },
                      }}
                    >
                      {link.label}
                    </Button>
                  ))}
                </Box>
              </Box>

              <Divider sx={{ my: 2 }} />

              {/* System Information */}
              <Box>
                <Typography variant="subtitle1" gutterBottom sx={{ color: '#004b87' }}>
                  System Information
                </Typography>
                <Box sx={{ backgroundColor: '#f8f9fa', p: 2, borderRadius: 1 }}>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    Version
                  </Typography>
                  <Typography variant="body1" fontWeight="medium" sx={{ color: '#0066b3' }}>
                    1.0.0
                  </Typography>
                  
                  <Typography variant="body2" color="text.secondary" gutterBottom sx={{ mt: 2 }}>
                    Last Updated
                  </Typography>
                  <Typography variant="body1" fontWeight="medium" sx={{ color: '#0066b3' }}>
                    15 March 2025
                  </Typography>
                  
                  <Typography variant="body2" color="text.secondary" gutterBottom sx={{ mt: 2 }}>
                    Status
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Box
                      sx={{
                        width: 8,
                        height: 8,
                        borderRadius: '50%',
                        backgroundColor: '#00a859',
                        mr: 1,
                      }}
                    />
                    <Typography variant="body1" fontWeight="medium" sx={{ color: '#00a859' }}>
                      System Operational
                    </Typography>
                  </Box>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Help;