import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Grid,
  IconButton,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  InputAdornment,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  CircularProgress,
  Card,
  CardContent,
  Tooltip,
  TableSortLabel, // Added
  TablePagination, // Added
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon,
  Download as DownloadIcon,
  AttachMoney as MoneyIcon,
  TrendingUp as TrendingIcon,
  Payment as PaymentIcon,
  Receipt as ReceiptIcon,
  Person as PersonIcon,
  CalendarToday as CalendarIcon,
  History as HistoryIcon,
  PersonAdd as PersonAddIcon
} from '@mui/icons-material';
import { loanService } from '../services/loanService';
import FarmerSelectionDialog from './FarmerSelectionDialog';

const Loans = () => {
  const [loans, setLoans] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [openPaymentDialog, setOpenPaymentDialog] = useState(false);
  const [openFarmerSelectionDialog, setOpenFarmerSelectionDialog] = useState(false);
  const [editingLoan, setEditingLoan] = useState(null);
  const [selectedLoan, setSelectedLoan] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [selectedFarmer, setSelectedFarmer] = useState(null);
  
  const [formData, setFormData] = useState({
    farmerId: '',
    loanAmount: '',
    interestRate: '2.0',
    loanDate: new Date().toISOString().split('T')[0],
    dueDate: '',
    purpose: '',
    notes: ''
  });
  
  const [paymentData, setPaymentData] = useState({
    amount: '',
    paymentMethod: 'CASH',
    referenceNo: '',
    notes: ''
  });

  // Sorting state
  const [order, setOrder] = useState('desc');
  const [orderBy, setOrderBy] = useState('loanDate');
  
  // Pagination state
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const loansRes = await loanService.getAllLoans();
      
      // Check if loans have farmer data
      console.log('Loans data:', loansRes.data);
      
      if (loansRes.data && loansRes.data.length > 0) {
        // Log first loan to check structure
        console.log('First loan structure:', loansRes.data[0]);
        console.log('First loan farmer:', loansRes.data[0]?.farmer);
      }
      
      setLoans(loansRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to load data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Sorting functions
  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const descendingComparator = (a, b, orderBy) => {
    if (b[orderBy] < a[orderBy]) {
      return -1;
    }
    if (b[orderBy] > a[orderBy]) {
      return 1;
    }
    return 0;
  };

  const getComparator = (order, orderBy) => {
    return order === 'desc'
      ? (a, b) => descendingComparator(a, b, orderBy)
      : (a, b) => -descendingComparator(a, b, orderBy);
  };

  const stableSort = (array, comparator) => {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
      const order = comparator(a[0], b[0]);
      if (order !== 0) return order;
      return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
  };

  // Pagination functions
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleOpenDialog = (loan = null) => {
    if (loan) {
      setEditingLoan(loan);
      
      // Check if farmer data is available
      if (loan.farmer) {
        setSelectedFarmer(loan.farmer); // Set the full farmer object
        setFormData({
          farmerId: loan.farmer.id || '',
          loanAmount: loan.loanAmount || '',
          interestRate: loan.interestRate || '2.0',
          loanDate: loan.loanDate || new Date().toISOString().split('T')[0],
          dueDate: loan.dueDate || '',
          purpose: loan.purpose || '',
          notes: loan.notes || ''
        });
      } else {
        console.warn('Loan has no farmer data:', loan);
        setSelectedFarmer(null);
        setFormData({
          farmerId: '',
          loanAmount: loan.loanAmount || '',
          interestRate: loan.interestRate || '2.0',
          loanDate: loan.loanDate || new Date().toISOString().split('T')[0],
          dueDate: loan.dueDate || '',
          purpose: loan.purpose || '',
          notes: loan.notes || ''
        });
      }
    } else {
      setEditingLoan(null);
      setSelectedFarmer(null);
      setFormData({
        farmerId: '',
        loanAmount: '',
        interestRate: '2.0',
        loanDate: new Date().toISOString().split('T')[0],
        dueDate: '',
        purpose: '',
        notes: ''
      });
    }
    setOpenDialog(true);
  };

  const handleOpenFarmerSelectionDialog = () => {
    // When editing, exclude the current farmer from the selection
    const excludeFarmerId = editingLoan ? (editingLoan.farmer?.id || null) : null;
    setOpenFarmerSelectionDialog(true);
  };

  const handleFarmerSelect = (farmer) => {
    setSelectedFarmer(farmer);
    setFormData(prev => ({
      ...prev,
      farmerId: farmer.id
    }));
    setOpenFarmerSelectionDialog(false);
  };

  const handleOpenPaymentDialog = (loan) => {
    if (!loan || !loan.id) {
      setError('Cannot open payment: Invalid loan data');
      return;
    }
    
    setSelectedLoan(loan);
    setPaymentData({
      amount: loan.remainingAmount > 0 ? loan.remainingAmount : '',
      paymentMethod: 'CASH',
      referenceNo: '',
      notes: ''
    });
    setOpenPaymentDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingLoan(null);
    setSelectedFarmer(null);
  };

  const handleClosePaymentDialog = () => {
    setOpenPaymentDialog(false);
    setSelectedLoan(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePaymentInputChange = (e) => {
    const { name, value } = e.target;
    setPaymentData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async () => {
    try {
      setError(null);
      setSuccess(null);
      
      if (!formData.farmerId || !selectedFarmer) {
        throw new Error('Please select a farmer');
      }

      if (!formData.loanAmount) {
        throw new Error('Please enter loan amount');
      }

      const loanData = {
        farmer: { id: formData.farmerId },
        loanAmount: parseFloat(formData.loanAmount),
        interestRate: parseFloat(formData.interestRate),
        loanDate: formData.loanDate,
        dueDate: formData.dueDate || null,
        purpose: formData.purpose,
        notes: formData.notes
      };

      if (editingLoan) {
        await loanService.updateLoan(editingLoan.id, loanData);
        setSuccess('Loan updated successfully!');
      } else {
        await loanService.createLoan(loanData);
        setSuccess('Loan created successfully!');
      }
      
      await fetchData();
      setTimeout(() => handleCloseDialog(), 1000);
    } catch (error) {
      console.error('Error saving loan:', error);
      setError(error.response?.data?.message || error.message || 'Failed to save loan.');
    }
  };

  const handlePaymentSubmit = async () => {
    try {
      setError(null);
      setSuccess(null);
      
      if (!paymentData.amount || parseFloat(paymentData.amount) <= 0) {
        throw new Error('Please enter a valid amount');
      }

      if (!selectedLoan || !selectedLoan.id) {
        throw new Error('No loan selected');
      }

      await loanService.processCashPayment(
        selectedLoan.id,
        parseFloat(paymentData.amount),
        paymentData.paymentMethod,
        paymentData.referenceNo,
        paymentData.notes
      );
      
      setSuccess('Payment processed successfully!');
      await fetchData();
      setTimeout(() => handleClosePaymentDialog(), 1000);
    } catch (error) {
      console.error('Error processing payment:', error);
      setError(error.response?.data?.message || error.message || 'Failed to process payment.');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this loan?')) {
      try {
        setError(null);
        await loanService.deleteLoan(id);
        await fetchData();
        setSuccess('Loan deleted successfully!');
      } catch (error) {
        console.error('Error deleting loan:', error);
        setError('Failed to delete loan. Please try again.');
      }
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ACTIVE': return { bg: '#e8f5e8', color: '#00a859' };
      case 'PAID': return { bg: '#e3f2fd', color: '#0066b3' };
      case 'OVERDUE': return { bg: '#ffeaea', color: '#dc3545' };
      case 'DEFAULTED': return { bg: '#fff3cd', color: '#856404' };
      default: return { bg: '#f5f5f5', color: '#666' };
    }
  };

  const filteredLoans = loans.filter((loan) => {
    const matchesSearch = 
      (loan.loanNumber || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (loan.farmer?.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (loan.farmer?.farmerCode || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (loan.purpose || '').toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filter === 'all') return matchesSearch;
    return matchesSearch && loan.status === filter;
  });

  // Prepare sorted and paginated data
  const sortedLoans = stableSort(filteredLoans, getComparator(order, orderBy));
  const paginatedLoans = sortedLoans.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  const calculateStats = () => {
    const totalActive = loans.filter(l => l.status === 'ACTIVE').length;
    const totalAmount = loans
      .filter(l => l.status === 'ACTIVE')
      .reduce((sum, loan) => sum + parseFloat(loan.remainingAmount || 0), 0);
    const totalPaid = loans
      .filter(l => l.status === 'PAID')
      .reduce((sum, loan) => sum + parseFloat(loan.loanAmount || 0), 0);
    
    return { totalActive, totalAmount, totalPaid };
  };

  const stats = calculateStats();

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      {/* Error and Success Alerts */}
      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {success && (
        <Alert severity="success" sx={{ mb: 3 }} onClose={() => setSuccess(null)}>
          {success}
        </Alert>
      )}

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={4}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #0066b3 0%, #0083d4 100%)',
            color: 'white',
            borderRadius: 2
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" fontWeight="bold">
                    {stats.totalActive}
                  </Typography>
                  <Typography variant="body2">Active Loans</Typography>
                </Box>
                <MoneyIcon sx={{ fontSize: 48, opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)',
            color: 'white',
            borderRadius: 2
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" fontWeight="bold">
                    ₹{stats.totalAmount.toLocaleString('en-IN')}
                  </Typography>
                  <Typography variant="body2">Total Due Amount</Typography>
                </Box>
                <TrendingIcon sx={{ fontSize: 48, opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #ff6b00 0%, #ff8c33 100%)',
            color: 'white',
            borderRadius: 2
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" fontWeight="bold">
                    ₹{stats.totalPaid.toLocaleString('en-IN')}
                  </Typography>
                  <Typography variant="body2">Total Loans Paid</Typography>
                </Box>
                <ReceiptIcon sx={{ fontSize: 48, opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Action Bar */}
      <Card sx={{ mb: 3, borderRadius: 2, boxShadow: '0 2px 15px rgba(0,0,0,0.08)' }}>
        <CardContent sx={{ p: 2 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                placeholder="Search loans..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon sx={{ color: '#666' }} />
                    </InputAdornment>
                  ),
                  sx: {
                    borderRadius: 2,
                    backgroundColor: 'white'
                  }
                }}
                variant="outlined"
                size="small"
              />
            </Grid>
            
            <Grid item xs={12} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel>Filter by Status</InputLabel>
                <Select
                  value={filter}
                  label="Filter by Status"
                  onChange={(e) => setFilter(e.target.value)}
                  sx={{ borderRadius: 2 }}
                >
                  <MenuItem value="all">All Loans</MenuItem>
                  <MenuItem value="ACTIVE">Active</MenuItem>
                  <MenuItem value="PAID">Paid</MenuItem>
                  <MenuItem value="OVERDUE">Overdue</MenuItem>
                  <MenuItem value="DEFAULTED">Defaulted</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} md={2}>
              <Button
                fullWidth
                variant="outlined"
                startIcon={<DownloadIcon />}
                onClick={() => {/* Export functionality */}}
                sx={{
                  textTransform: 'none',
                  borderRadius: 2,
                  borderColor: '#0066b3',
                  color: '#0066b3'
                }}
              >
                Export
              </Button>
            </Grid>
            
            <Grid item xs={12} md={3}>
              <Button
                fullWidth
                variant="contained"
                startIcon={<AddIcon />}
                onClick={() => handleOpenDialog()}
                sx={{
                  textTransform: 'none',
                  borderRadius: 2,
                  background: 'linear-gradient(135deg, #0066b3 0%, #0083d4 100%)'
                }}
              >
                Add New Loan
              </Button>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Loans Table with Sorting and Pagination */}
      <Paper sx={{ width: '100%', overflow: 'hidden' }}>
        <TableContainer>
          <Table>
            <TableHead sx={{ backgroundColor: '#f8f9fa' }}>
              <TableRow>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  <TableSortLabel
                    active={orderBy === 'loanNumber'}
                    direction={orderBy === 'loanNumber' ? order : 'asc'}
                    onClick={() => handleRequestSort('loanNumber')}
                  >
                    Loan No
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  <TableSortLabel
                    active={orderBy === 'farmer.name'}
                    direction={orderBy === 'farmer.name' ? order : 'asc'}
                    onClick={() => handleRequestSort('farmer.name')}
                  >
                    Farmer
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  <TableSortLabel
                    active={orderBy === 'loanAmount'}
                    direction={orderBy === 'loanAmount' ? order : 'asc'}
                    onClick={() => handleRequestSort('loanAmount')}
                  >
                    Loan Amount
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  <TableSortLabel
                    active={orderBy === 'remainingAmount'}
                    direction={orderBy === 'remainingAmount' ? order : 'asc'}
                    onClick={() => handleRequestSort('remainingAmount')}
                  >
                    Remaining
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  <TableSortLabel
                    active={orderBy === 'interestRate'}
                    direction={orderBy === 'interestRate' ? order : 'asc'}
                    onClick={() => handleRequestSort('interestRate')}
                  >
                    Interest Rate
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  <TableSortLabel
                    active={orderBy === 'loanDate'}
                    direction={orderBy === 'loanDate' ? order : 'asc'}
                    onClick={() => handleRequestSort('loanDate')}
                  >
                    Loan Date
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }}>
                  <TableSortLabel
                    active={orderBy === 'status'}
                    direction={orderBy === 'status' ? order : 'asc'}
                    onClick={() => handleRequestSort('status')}
                  >
                    Status
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: '600', color: '#004b87', py: 2 }} align="center">
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedLoans.length > 0 ? (
                paginatedLoans.map((loan) => {
                  const statusColor = getStatusColor(loan.status);
                  return (
                    <TableRow key={loan.id} hover>
                      <TableCell sx={{ py: 1.5 }}>
                        <Typography variant="body2" sx={{ 
                          fontWeight: '600', 
                          backgroundColor: '#f0f8ff', 
                          color: '#0066b3',
                          px: 1.5,
                          py: 0.5,
                          borderRadius: 1,
                          display: 'inline-block'
                        }}>
                          {loan.loanNumber || 'N/A'}
                        </Typography>
                      </TableCell>
                      
                      <TableCell sx={{ py: 1.5 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <PersonIcon fontSize="small" sx={{ color: '#666' }} />
                          <Box>
                            <Typography variant="body2" fontWeight="medium">
                              {loan.farmer?.name || 'Unknown'}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {loan.farmer?.farmerCode || ''}
                            </Typography>
                          </Box>
                        </Box>
                      </TableCell>
                      
                      <TableCell sx={{ py: 1.5 }}>
                        <Typography variant="body1" fontWeight="medium">
                          ₹{parseFloat(loan.loanAmount || 0).toLocaleString('en-IN')}
                        </Typography>
                      </TableCell>
                      
                      <TableCell sx={{ py: 1.5 }}>
                        <Typography variant="body1" fontWeight="medium" color="#dc3545">
                          ₹{parseFloat(loan.remainingAmount || 0).toLocaleString('en-IN')}
                        </Typography>
                      </TableCell>
                      
                      <TableCell sx={{ py: 1.5 }}>
                        <Chip
                          label={`${loan.interestRate}%`}
                          size="small"
                          sx={{
                            backgroundColor: '#e3f2fd',
                            color: '#0066b3',
                            fontWeight: '500'
                          }}
                        />
                      </TableCell>
                      
                      <TableCell sx={{ py: 1.5 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <CalendarIcon fontSize="small" sx={{ color: '#666', fontSize: 16 }} />
                          <Typography variant="body2">
                            {loan.loanDate ? new Date(loan.loanDate).toLocaleDateString() : 'N/A'}
                          </Typography>
                        </Box>
                        {loan.dueDate && (
                          <Typography variant="caption" color="text.secondary">
                            Due: {new Date(loan.dueDate).toLocaleDateString()}
                          </Typography>
                        )}
                      </TableCell>
                      
                      <TableCell sx={{ py: 1.5 }}>
                        <Chip
                          label={loan.status || 'UNKNOWN'}
                          size="small"
                          sx={{
                            backgroundColor: statusColor.bg,
                            color: statusColor.color,
                            fontWeight: '500'
                          }}
                        />
                      </TableCell>
                      
                      <TableCell align="center" sx={{ py: 1.5 }}>
                        <Box sx={{ display: 'flex', gap: 1, justifyContent: 'center' }}>
                          {loan.status === 'ACTIVE' && loan.remainingAmount > 0 && (
                            <Tooltip title="Receive Payment">
                              <IconButton
                                size="small"
                                onClick={() => handleOpenPaymentDialog(loan)}
                                sx={{ 
                                  backgroundColor: 'rgba(0, 166, 89, 0.1)',
                                  color: '#00a859'
                                }}
                              >
                                <PaymentIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          )}
                          
                          <Tooltip title="View Transactions">
                            <IconButton
                              size="small"
                              onClick={() => {/* Navigate to transactions */}}
                              sx={{ 
                                backgroundColor: 'rgba(0, 102, 179, 0.1)',
                                color: '#0066b3'
                              }}
                            >
                              <HistoryIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          
                          <Tooltip title="Edit">
                            <IconButton
                              size="small"
                              onClick={() => handleOpenDialog(loan)}
                              sx={{ 
                                backgroundColor: 'rgba(255, 193, 7, 0.1)',
                                color: '#ffc107'
                              }}
                            >
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          
                          {loan.status === 'ACTIVE' && (
                            <Tooltip title="Delete">
                              <IconButton
                                size="small"
                                onClick={() => handleDelete(loan.id)}
                                sx={{ 
                                  backgroundColor: 'rgba(220, 53, 69, 0.1)',
                                  color: '#dc3545'
                                }}
                              >
                                <DeleteIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          )}
                        </Box>
                      </TableCell>
                    </TableRow>
                  );
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={8} align="center" sx={{ py: 4 }}>
                    <Typography variant="body1" color="text.secondary">
                      No loans found
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        
        {/* Pagination */}
        <TablePagination
          rowsPerPageOptions={[5, 10, 25, 50]}
          component="div"
          count={filteredLoans.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          sx={{
            borderTop: '1px solid rgba(224, 224, 224, 1)',
          }}
        />
      </Paper>

      {/* Add/Edit Loan Dialog - UPDATED WITH FARMER SELECTION */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle sx={{ color: '#004b87', borderBottom: '1px solid #eee', pb: 2 }}>
          {editingLoan ? 'Edit Loan Details' : 'Add New Loan'}
        </DialogTitle>
        <DialogContent sx={{ pt: 3 }}>
          <Grid container spacing={2}>
            {/* Farmer Selection */}
            <Grid item xs={12}>
              <Box sx={{ mb: 2 }}>
                <Typography variant="subtitle2" sx={{ mb: 1, color: '#004b87' }}>
                  Select Farmer *
                </Typography>
                {selectedFarmer ? (
                  <Card variant="outlined" sx={{ p: 2, borderRadius: 2, backgroundColor: '#f8f9fa' }}>
                    <Grid container alignItems="center" spacing={2}>
                      <Grid item>
                        <PersonIcon sx={{ fontSize: 40, color: '#0066b3' }} />
                      </Grid>
                      <Grid item xs>
                        <Box>
                          <Typography variant="body1" fontWeight="medium">
                            {selectedFarmer.name}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {selectedFarmer.fatherName} • {selectedFarmer.farmerCode}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {selectedFarmer.mobile} • {selectedFarmer.village}, {selectedFarmer.district}
                          </Typography>
                        </Box>
                      </Grid>
                      <Grid item>
                        <Box sx={{ textAlign: 'right' }}>
                          <Typography variant="body2" color="text.secondary">
                            Current Balance
                          </Typography>
                          <Typography 
                            variant="h6" 
                            fontWeight="bold"
                            color={selectedFarmer.balanceDue > 0 ? '#dc3545' : '#00a859'}
                          >
                            ₹{parseFloat(selectedFarmer.balanceDue || 0).toLocaleString('en-IN')}
                          </Typography>
                        </Box>
                      </Grid>
                      <Grid item>
                        <Button
                          size="small"
                          variant="outlined"
                          onClick={handleOpenFarmerSelectionDialog}
                          startIcon={<PersonAddIcon />}
                        >
                          Change
                        </Button>
                      </Grid>
                    </Grid>
                  </Card>
                ) : (
                  <Button
                    fullWidth
                    variant="outlined"
                    onClick={handleOpenFarmerSelectionDialog}
                    startIcon={<PersonAddIcon />}
                    sx={{
                      py: 2,
                      borderRadius: 2,
                      borderStyle: 'dashed',
                      borderColor: '#ccc',
                      '&:hover': {
                        borderColor: '#0066b3',
                        backgroundColor: 'rgba(0, 102, 179, 0.04)'
                      }
                    }}
                  >
                    Click to Select Farmer
                  </Button>
                )}
              </Box>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Loan Amount (₹) *"
                name="loanAmount"
                type="number"
                value={formData.loanAmount}
                onChange={handleInputChange}
                required
                size="small"
                InputProps={{
                  startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                }}
              />
            </Grid>
            
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Interest Rate (%) *"
                name="interestRate"
                type="number"
                value={formData.interestRate}
                onChange={handleInputChange}
                required
                size="small"
                InputProps={{
                  endAdornment: <InputAdornment position="end">%</InputAdornment>,
                }}
              />
            </Grid>
            
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Loan Date *"
                name="loanDate"
                type="date"
                value={formData.loanDate}
                onChange={handleInputChange}
                required
                size="small"
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Due Date (Optional)"
                name="dueDate"
                type="date"
                value={formData.dueDate}
                onChange={handleInputChange}
                size="small"
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Purpose (Optional)"
                name="purpose"
                value={formData.purpose}
                onChange={handleInputChange}
                placeholder="e.g., Crop investment, Medical expenses, etc."
                size="small"
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Notes (Optional)"
                name="notes"
                value={formData.notes}
                onChange={handleInputChange}
                multiline
                rows={2}
                size="small"
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button onClick={handleCloseDialog} sx={{ color: '#666' }}>
            Cancel
          </Button>
          <Button 
            variant="contained" 
            onClick={handleSubmit}
            disabled={!selectedFarmer}
            sx={{ 
              background: selectedFarmer ? 
                'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)' : 
                'linear-gradient(135deg, #ccc 0%, #ddd 100%)'
            }}
          >
            {editingLoan ? 'Update Loan' : 'Create Loan'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Payment Dialog */}
      <Dialog open={openPaymentDialog} onClose={handleClosePaymentDialog} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ color: '#004b87', borderBottom: '1px solid #eee', pb: 2 }}>
          Receive Loan Payment
        </DialogTitle>
        <DialogContent sx={{ pt: 3 }}>
          {selectedLoan && (
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle2" color="text.secondary">Loan Details</Typography>
              <Box sx={{ 
                p: 2, 
                backgroundColor: '#f8f9fa', 
                borderRadius: 1,
                mt: 1 
              }}>
                <Grid container spacing={1}>
                  <Grid item xs={6}>
                    <Typography variant="caption" color="text.secondary">Loan No:</Typography>
                    <Typography variant="body2" fontWeight="medium">{selectedLoan.loanNumber || 'N/A'}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="caption" color="text.secondary">Farmer:</Typography>
                    <Typography variant="body2" fontWeight="medium">{selectedLoan.farmer?.name || 'Unknown'}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="caption" color="text.secondary">Remaining Balance:</Typography>
                    <Typography variant="body2" fontWeight="bold" color="#dc3545">
                      ₹{parseFloat(selectedLoan.remainingAmount || 0).toLocaleString('en-IN')}
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="caption" color="text.secondary">Interest Rate:</Typography>
                    <Typography variant="body2">{selectedLoan.interestRate}%</Typography>
                  </Grid>
                </Grid>
              </Box>
            </Box>
          )}
          
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Payment Amount (₹) *"
                name="amount"
                type="number"
                value={paymentData.amount}
                onChange={handlePaymentInputChange}
                required
                size="small"
                InputProps={{
                  startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <FormControl fullWidth size="small">
                <InputLabel>Payment Method *</InputLabel>
                <Select
                  name="paymentMethod"
                  value={paymentData.paymentMethod}
                  label="Payment Method *"
                  onChange={handlePaymentInputChange}
                >
                  <MenuItem value="CASH">Cash</MenuItem>
                  <MenuItem value="BANK_TRANSFER">Bank Transfer</MenuItem>
                  <MenuItem value="UPI">UPI</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            {paymentData.paymentMethod !== 'CASH' && (
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Reference Number"
                  name="referenceNo"
                  value={paymentData.referenceNo}
                  onChange={handlePaymentInputChange}
                  size="small"
                  placeholder="Transaction ID, UPI Ref, etc."
                />
              </Grid>
            )}
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Notes (Optional)"
                name="notes"
                value={paymentData.notes}
                onChange={handlePaymentInputChange}
                multiline
                rows={2}
                size="small"
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button onClick={handleClosePaymentDialog} sx={{ color: '#666' }}>
            Cancel
          </Button>
          <Button 
            variant="contained" 
            onClick={handlePaymentSubmit}
            sx={{ 
              background: 'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)'
            }}
          >
            Process Payment
          </Button>
        </DialogActions>
      </Dialog>

      {/* Farmer Selection Dialog */}
      <FarmerSelectionDialog
        open={openFarmerSelectionDialog}
        onClose={() => setOpenFarmerSelectionDialog(false)}
        onSelectFarmer={handleFarmerSelect}
        excludeFarmerId={editingLoan ? (editingLoan.farmer?.id || null) : null}
      />
    </Box>
  );
};

export default Loans;