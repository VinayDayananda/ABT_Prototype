import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Grid,
  IconButton,
  Chip,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  CircularProgress,
  TableSortLabel, // Added for sorting
  TablePagination, // Added for pagination
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  LocationOn as LocationIcon,
} from '@mui/icons-material';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { tenderRateService } from '../services/tenderRateService';
import { format } from 'date-fns';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const TenderRates = () => {
  const [tenderRates, setTenderRates] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingRate, setEditingRate] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    market: 'TIPTUR',
    rateDate: format(new Date(), 'yyyy-MM-dd'),
    ratePerQuintal: '',
  });

  // Sorting state
  const [order, setOrder] = useState('desc');
  const [orderBy, setOrderBy] = useState('rateDate');
  
  // Pagination state
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  useEffect(() => {
    fetchTenderRates();
  }, []);

  const fetchTenderRates = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await tenderRateService.getAllTenderRates();
      setTenderRates(response.data);
    } catch (error) {
      console.error('Error fetching tender rates:', error);
      setError('Failed to load tender rates. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (rate = null) => {
    if (rate) {
      setEditingRate(rate);
      setFormData({
        market: rate.market,
        rateDate: format(new Date(rate.rateDate), 'yyyy-MM-dd'),
        ratePerQuintal: rate.ratePerQuintal,
      });
    } else {
      setEditingRate(null);
      setFormData({
        market: 'TIPTUR',
        rateDate: format(new Date(), 'yyyy-MM-dd'),
        ratePerQuintal: '',
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingRate(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async () => {
    try {
      setError(null);
      if (editingRate) {
        await tenderRateService.updateTenderRate(editingRate.id, formData);
      } else {
        await tenderRateService.createTenderRate(formData);
      }
      await fetchTenderRates();
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving tender rate:', error);
      setError('Failed to save tender rate. Please try again.');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this tender rate?')) {
      try {
        setError(null);
        await tenderRateService.deleteTenderRate(id);
        await fetchTenderRates();
      } catch (error) {
        console.error('Error deleting tender rate:', error);
        setError('Failed to delete tender rate. Please try again.');
      }
    }
  };

  // Sorting functions
  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const descendingComparator = (a, b, orderBy) => {
    if (b[orderBy] < a[orderBy]) {
      return -1;
    }
    if (b[orderBy] > a[orderBy]) {
      return 1;
    }
    return 0;
  };

  const getComparator = (order, orderBy) => {
    return order === 'desc'
      ? (a, b) => descendingComparator(a, b, orderBy)
      : (a, b) => -descendingComparator(a, b, orderBy);
  };

  const stableSort = (array, comparator) => {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
      const order = comparator(a[0], b[0]);
      if (order !== 0) return order;
      return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
  };

  // Pagination functions
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Prepare sorted and paginated data
  const sortedRates = stableSort(tenderRates, getComparator(order, orderBy));
  const paginatedRates = sortedRates.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  // Prepare chart data
  const tipturRates = tenderRates.filter(rate => rate.market === 'TIPTUR').sort((a, b) => new Date(a.rateDate) - new Date(b.rateDate));
  const arsikereRates = tenderRates.filter(rate => rate.market === 'ARSIKERE').sort((a, b) => new Date(a.rateDate) - new Date(b.rateDate));

  const tipturChartData = {
    labels: tipturRates.map(rate => format(new Date(rate.rateDate), 'dd/MM')),
    datasets: [{
      label: 'Tiptur Rate (₹/Quintal)',
      data: tipturRates.map(rate => rate.ratePerQuintal),
      borderColor: '#0066b3',
      backgroundColor: 'rgba(0, 102, 179, 0.1)',
      borderWidth: 3,
      fill: true,
      tension: 0.4,
    }],
  };

  const arsikereChartData = {
    labels: arsikereRates.map(rate => format(new Date(rate.rateDate), 'dd/MM')),
    datasets: [{
      label: 'Arsikere Rate (₹/Quintal)',
      data: arsikereRates.map(rate => rate.ratePerQuintal),
      borderColor: '#00a859',
      backgroundColor: 'rgba(0, 168, 89, 0.1)',
      borderWidth: 3,
      fill: true,
      tension: 0.4,
    }],
  };

  const calculateChange = (rate, allRates) => {
    const marketRates = allRates.filter(r => r.market === rate.market)
      .sort((a, b) => new Date(a.rateDate) - new Date(b.rateDate));
    
    const currentIndex = marketRates.findIndex(r => r.id === rate.id);
    if (currentIndex === 0) return 0;
    
    const current = marketRates[currentIndex].ratePerQuintal;
    const previous = marketRates[currentIndex - 1].ratePerQuintal;
    return current - previous;
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ color: '#004b87' }}>
          <TrendingUpIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
          Tender Rate Management
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
          sx={{ background: 'linear-gradient(135deg, #0066b3 0%, #0083d4 100%)' }}
        >
          Add New Rate
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Charts Grid */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#004b87' }}>
              <LocationIcon sx={{ mr: 1 }} />
              Tiptur Market Rates (Mon & Thu)
            </Typography>
            <Box sx={{ height: 300 }}>
              <Line
                data={tipturChartData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'top',
                    },
                  },
                  scales: {
                    y: {
                      beginAtZero: false,
                      grid: {
                        color: 'rgba(0,0,0,0.05)',
                      },
                    },
                    x: {
                      grid: {
                        color: 'rgba(0,0,0,0.05)',
                      },
                    },
                  },
                }}
              />
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', color: '#004b87' }}>
              <LocationIcon sx={{ mr: 1 }} />
              Arsikere Market Rates (Tue & Fri)
            </Typography>
            <Box sx={{ height: 300 }}>
              <Line
                data={arsikereChartData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'top',
                    },
                  },
                  scales: {
                    y: {
                      beginAtZero: false,
                      grid: {
                        color: 'rgba(0,0,0,0.05)',
                      },
                    },
                    x: {
                      grid: {
                        color: 'rgba(0,0,0,0.05)',
                      },
                    },
                  },
                }}
              />
            </Box>
          </Paper>
        </Grid>
      </Grid>

      {/* Tender Rates Table */}
      <Paper sx={{ width: '100%', overflow: 'hidden' }}>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ bgcolor: '#f8f9fa' }}>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  <TableSortLabel
                    active={orderBy === 'rateDate'}
                    direction={orderBy === 'rateDate' ? order : 'asc'}
                    onClick={() => handleRequestSort('rateDate')}
                  >
                    Date
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  <TableSortLabel
                    active={orderBy === 'market'}
                    direction={orderBy === 'market' ? order : 'asc'}
                    onClick={() => handleRequestSort('market')}
                  >
                    Market
                  </TableSortLabel>
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  <TableSortLabel
                    active={orderBy === 'ratePerQuintal'}
                    direction={orderBy === 'ratePerQuintal' ? order : 'asc'}
                    onClick={() => handleRequestSort('ratePerQuintal')}
                  >
                    Rate (₹/Quintal)
                  </TableSortLabel>
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  Change
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#004b87' }}>
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedRates.length > 0 ? (
                paginatedRates.map((rate) => {
                  const change = calculateChange(rate, tenderRates);
                  
                  return (
                    <TableRow key={rate.id} hover>
                      <TableCell>
                        {format(new Date(rate.rateDate), 'dd/MM/yyyy')}
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={rate.market}
                          size="small"
                          sx={{
                            backgroundColor: rate.market === 'TIPTUR' ? '#e3f2fd' : '#e8f5e8',
                            color: rate.market === 'TIPTUR' ? '#0066b3' : '#00a859',
                            fontWeight: 'medium',
                          }}
                        />
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body1" fontWeight="bold">
                          ₹{parseFloat(rate.ratePerQuintal).toLocaleString()}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          ₹{(rate.ratePerQuintal / 100).toFixed(2)}/kg
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                          {change !== 0 && (
                            <>
                              {change > 0 ? (
                                <TrendingUpIcon sx={{ color: '#00a859', mr: 0.5 }} />
                              ) : (
                                <TrendingDownIcon sx={{ color: '#dc3545', mr: 0.5 }} />
                              )}
                              <Typography
                                variant="body2"
                                sx={{ color: change > 0 ? '#00a859' : '#dc3545' }}
                              >
                                {change > 0 ? '+' : ''}{change}
                              </Typography>
                            </>
                          )}
                          {change === 0 && (
                            <Typography variant="body2" color="text.secondary">
                              No change
                            </Typography>
                          )}
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: 1 }}>
                          <IconButton
                            color="primary"
                            onClick={() => handleOpenDialog(rate)}
                            sx={{ 
                              backgroundColor: 'rgba(0, 102, 179, 0.1)',
                              '&:hover': { backgroundColor: 'rgba(0, 102, 179, 0.2)' }
                            }}
                            size="small"
                          >
                            <EditIcon fontSize="small" />
                          </IconButton>
                          <IconButton
                            color="error"
                            onClick={() => handleDelete(rate.id)}
                            sx={{ 
                              backgroundColor: 'rgba(220, 53, 69, 0.1)',
                              '&:hover': { backgroundColor: 'rgba(220, 53, 69, 0.2)' }
                          }}
                            size="small"
                          >
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Box>
                      </TableCell>
                    </TableRow>
                  );
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={5} align="center" sx={{ py: 4 }}>
                    <Typography variant="body1" color="text.secondary">
                      No tender rates found
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25, 50]}
          component="div"
          count={tenderRates.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          sx={{
            borderTop: '1px solid rgba(224, 224, 224, 1)',
          }}
        />
      </Paper>

      {/* Add/Edit Tender Rate Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ color: '#004b87' }}>
          {editingRate ? 'Edit Tender Rate' : 'Add New Tender Rate'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <FormControl fullWidth size="small">
                <InputLabel>Market</InputLabel>
                <Select
                  name="market"
                  value={formData.market}
                  onChange={handleInputChange}
                  label="Market"
                >
                  <MenuItem value="TIPTUR">Tiptur Market</MenuItem>
                  <MenuItem value="ARSIKERE">Arsikere Market</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                type="date"
                label="Date"
                name="rateDate"
                value={formData.rateDate}
                onChange={handleInputChange}
                InputLabelProps={{ shrink: true }}
                size="small"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                type="number"
                label="Rate per Quintal (₹)"
                name="ratePerQuintal"
                value={formData.ratePerQuintal}
                onChange={handleInputChange}
                size="small"
                helperText={`₹${(formData.ratePerQuintal / 100 || 0).toFixed(2)} per kg`}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} sx={{ color: '#666' }}>
            Cancel
          </Button>
          <Button 
            variant="contained" 
            onClick={handleSubmit}
            sx={{ background: 'linear-gradient(135deg, #00a859 0%, #00cc6d 100%)' }}
          >
            {editingRate ? 'Update' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default TenderRates;