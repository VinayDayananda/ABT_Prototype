// Theme configurations only

export const themes = {
  blue: {
    name: 'Blue Ocean',
    colors: {
      primary: '#0066b3',
      primaryLight: '#0083d4',
      primaryDark: '#004b87',
      secondary: '#00a859',
      secondaryLight: '#00cc6d',
      secondaryDark: '#00994d',
      accent: '#ff6b00',
      danger: '#ff4444',
      warning: '#ffb300',
      info: '#17a2b8',
      background: '#f5f7fa',
      paper: '#ffffff',
      text: '#333333',
      textSecondary: '#666666',
      border: '#e0e0e0',
      tableHeader: '#f0f8ff',
      success: '#00a859',
    },
    gradients: {
      primary: 'linear-gradient(135deg, #004b87 0%, #0066b3 50%, #0083d4 100%)',
      secondary: 'linear-gradient(135deg, #00994d 0%, #00a859 50%, #00cc6d 100%)',
      header: 'linear-gradient(135deg, #004b87 0%, #0066b3 100%)',
    }
  },
  orange: {
    name: 'Sunset Orange',
    colors: {
      primary: '#ff6b00',
      primaryLight: '#ff8f33',
      primaryDark: '#cc5600',
      secondary: '#1a73e8',
      secondaryLight: '#4d8ff0',
      secondaryDark: '#0d5ec2',
      accent: '#00bcd4',
      danger: '#f44336',
      warning: '#ffc107',
      info: '#2196f3',
      background: '#fff8f3',
      paper: '#ffffff',
      text: '#333333',
      textSecondary: '#666666',
      border: '#ffd9c2',
      tableHeader: '#fff3e6',
      success: '#4caf50',
    },
    gradients: {
      primary: 'linear-gradient(135deg, #cc5600 0%, #ff6b00 50%, #ff8f33 100%)',
      secondary: 'linear-gradient(135deg, #0d5ec2 0%, #1a73e8 50%, #4d8ff0 100%)',
      header: 'linear-gradient(135deg, #cc5600 0%, #ff6b00 100%)',
    }
  },
  green: {
    name: 'Green Forest',
    colors: {
      primary: '#2e7d32',
      primaryLight: '#4caf50',
      primaryDark: '#1b5e20',
      secondary: '#ff9800',
      secondaryLight: '#ffb74d',
      secondaryDark: '#f57c00',
      accent: '#9c27b0',
      danger: '#e53935',
      warning: '#ffb300',
      info: '#039be5',
      background: '#f9f9f9',
      paper: '#ffffff',
      text: '#2c3e50',
      textSecondary: '#7f8c8d',
      border: '#e0e0e0',
      tableHeader: '#f1f8e9',
      success: '#43a047',
    },
    gradients: {
      primary: 'linear-gradient(135deg, #1b5e20 0%, #2e7d32 50%, #4caf50 100%)',
      secondary: 'linear-gradient(135deg, #f57c00 0%, #ff9800 50%, #ffb74d 100%)',
      header: 'linear-gradient(135deg, #1b5e20 0%, #2e7d32 100%)',
    }
  },
  purple: {
    name: 'Purple Royal',
    colors: {
      primary: '#673ab7',
      primaryLight: '#9575cd',
      primaryDark: '#4527a0',
      secondary: '#ff4081',
      secondaryLight: '#ff79b0',
      secondaryDark: '#f50057',
      accent: '#00bcd4',
      danger: '#f44336',
      warning: '#ff9800',
      info: '#2196f3',
      background: '#fafafa',
      paper: '#ffffff',
      text: '#424242',
      textSecondary: '#757575',
      border: '#e0e0e0',
      tableHeader: '#f3e5f5',
      success: '#4caf50',
    },
    gradients: {
      primary: 'linear-gradient(135deg, #4527a0 0%, #673ab7 50%, #9575cd 100%)',
      secondary: 'linear-gradient(135deg, #f50057 0%, #ff4081 50%, #ff79b0 100%)',
      header: 'linear-gradient(135deg, #4527a0 0%, #673ab7 100%)',
    }
  },
  corporate: {
    name: 'Corporate Blue',
    colors: {
      primary: '#1565c0',
      primaryLight: '#42a5f5',
      primaryDark: '#0d47a1',
      secondary: '#f57c00',
      secondaryLight: '#ffb74d',
      secondaryDark: '#e65100',
      accent: '#7b1fa2',
      danger: '#d32f2f',
      warning: '#fbc02d',
      info: '#0288d1',
      background: '#f8f9fa',
      paper: '#ffffff',
      text: '#263238',
      textSecondary: '#607d8b',
      border: '#cfd8dc',
      tableHeader: '#e3f2fd',
      success: '#388e3c',
    },
    gradients: {
      primary: 'linear-gradient(135deg, #0d47a1 0%, #1565c0 50%, #42a5f5 100%)',
      secondary: 'linear-gradient(135deg, #e65100 0%, #f57c00 50%, #ffb74d 100%)',
      header: 'linear-gradient(135deg, #0d47a1 0%, #1565c0 100%)',
    }
  }
};

// Theme configuration function
export const getThemeConfig = (themeName = 'blue') => {
  const theme = themes[themeName] || themes.blue;
  return {
    palette: {
      mode: 'light', // Always light mode now
      primary: {
        main: theme.colors.primary,
        light: theme.colors.primaryLight,
        dark: theme.colors.primaryDark,
        contrastText: '#ffffff',
      },
      secondary: {
        main: theme.colors.secondary,
        light: theme.colors.secondaryLight,
        dark: theme.colors.secondaryDark,
        contrastText: '#ffffff',
      },
      error: {
        main: theme.colors.danger,
      },
      warning: {
        main: theme.colors.warning,
      },
      info: {
        main: theme.colors.info,
      },
      success: {
        main: theme.colors.success,
      },
      background: {
        default: theme.colors.background,
        paper: theme.colors.paper,
      },
      text: {
        primary: theme.colors.text,
        secondary: theme.colors.textSecondary,
      },
      divider: theme.colors.border,
    },
    typography: {
      fontFamily: '"Inter", "Segoe UI", Tahoma, Geneva, Verdana, sans-serif',
      h1: {
        fontWeight: 700,
        fontSize: '2.5rem',
        lineHeight: 1.2,
      },
      h2: {
        fontWeight: 700,
        fontSize: '2rem',
        lineHeight: 1.3,
      },
      h3: {
        fontWeight: 600,
        fontSize: '1.75rem',
        lineHeight: 1.3,
      },
      h4: {
        fontWeight: 600,
        fontSize: '1.5rem',
        lineHeight: 1.4,
      },
      h5: {
        fontWeight: 600,
        fontSize: '1.25rem',
        lineHeight: 1.4,
      },
      h6: {
        fontWeight: 600,
        fontSize: '1rem',
        lineHeight: 1.4,
      },
      subtitle1: {
        fontSize: '0.875rem',
        fontWeight: 500,
        lineHeight: 1.6,
      },
      body1: {
        fontSize: '0.875rem',
        lineHeight: 1.6,
      },
      button: {
        textTransform: 'none',
        fontWeight: 500,
        fontSize: '0.875rem',
      },
    },
    shape: {
      borderRadius: 12,
    },
    components: {
      MuiCssBaseline: {
        styleOverrides: {
          body: {
            transition: 'all 0.3s ease',
            fontFamily: '"Inter", "Segoe UI", Tahoma, Geneva, Verdana, sans-serif',
          },
        },
      },
      MuiButton: {
        styleOverrides: {
          root: {
            borderRadius: 10,
            fontWeight: 600,
            textTransform: 'none',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            padding: '8px 20px',
            '&:hover': {
              transform: 'translateY(-2px)',
              boxShadow: `0 6px 20px ${theme.colors.primary}40`,
            },
          },
          contained: {
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
            background: theme.gradients.primary,
            color: 'white',
            '&:hover': {
              background: theme.gradients.primary,
              boxShadow: `0 8px 25px ${theme.colors.primary}60`,
            },
          },
          outlined: {
            borderWidth: '2px',
            fontWeight: 500,
            '&:hover': {
              borderWidth: '2px',
              backgroundColor: `${theme.colors.primary}10`,
            },
          },
          sizeLarge: {
            padding: '12px 28px',
            fontSize: '1rem',
          },
        },
        defaultProps: {
          disableElevation: true,
        },
      },
      MuiCard: {
        styleOverrides: {
          root: {
            borderRadius: 16,
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.08)',
            border: `1px solid ${theme.colors.border}`,
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            background: theme.colors.paper,
            overflow: 'hidden',
            '&:hover': {
              boxShadow: '0 8px 30px rgba(0, 0, 0, 0.12)',
              transform: 'translateY(-4px)',
            },
          },
        },
      },
      MuiPaper: {
        styleOverrides: {
          root: {
            borderRadius: 12,
            backgroundImage: 'none',
          },
        },
      },
      MuiAppBar: {
        styleOverrides: {
          root: {
            background: theme.gradients.header,
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
            backdropFilter: 'blur(10px)',
            border: 'none',
            zIndex: 1201,
          },
        },
      },
      MuiTableCell: {
        styleOverrides: {
          head: {
            fontWeight: 700,
            backgroundColor: theme.colors.tableHeader,
            color: theme.colors.text,
            fontSize: '0.9rem',
            borderBottom: `2px solid ${theme.colors.primary}30`,
            padding: '16px',
          },
          body: {
            borderBottom: `1px solid ${theme.colors.border}`,
            fontSize: '0.875rem',
            padding: '14px 16px',
          },
        },
      },
      MuiTableRow: {
        styleOverrides: {
          root: {
            transition: 'background-color 0.2s ease',
            '&:hover': {
              backgroundColor: `${theme.colors.primary}08 !important`,
            },
            '&.Mui-selected': {
              backgroundColor: `${theme.colors.primary}12`,
              '&:hover': {
                backgroundColor: `${theme.colors.primary}16`,
              },
            },
          },
        },
      },
      MuiTextField: {
        defaultProps: {
          size: 'small',
        },
        styleOverrides: {
          root: {
            '& .MuiOutlinedInput-root': {
              borderRadius: 10,
              transition: 'all 0.3s ease',
              '&:hover': {
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: theme.colors.primary,
                },
              },
              '&.Mui-focused': {
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: theme.colors.primary,
                  borderWidth: 2,
                },
              },
            },
          },
        },
      },
      MuiSelect: {
        defaultProps: {
          size: 'small',
        },
        styleOverrides: {
          root: {
            borderRadius: 10,
          },
        },
      },
      MuiDialog: {
        styleOverrides: {
          paper: {
            borderRadius: 20,
            background: theme.colors.paper,
          },
        },
      },
      MuiMenu: {
        styleOverrides: {
          paper: {
            borderRadius: 12,
            marginTop: 8,
            boxShadow: '0 10px 40px rgba(0, 0, 0, 0.15)',
            border: `1px solid ${theme.colors.border}`,
            minWidth: 200,
          },
        },
      },
      MuiChip: {
        styleOverrides: {
          root: {
            borderRadius: 8,
            fontWeight: 600,
            fontSize: '0.75rem',
          },
        },
      },
      MuiAvatar: {
        styleOverrides: {
          root: {
            border: `3px solid white`,
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
          },
        },
      },
      MuiDivider: {
        styleOverrides: {
          root: {
            borderColor: theme.colors.border,
          },
        },
      },
      MuiTooltip: {
        styleOverrides: {
          tooltip: {
            borderRadius: 8,
            fontSize: '0.75rem',
            padding: '8px 12px',
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
          },
        },
      },
    },
  };
};