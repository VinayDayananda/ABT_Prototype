-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: ambika_traders
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `farmers`
--

DROP TABLE IF EXISTS `farmers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `farmers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `farmer_code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `address` text,
  `village` varchar(100) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `account_number` varchar(30) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `upi_id` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `total_copra_sold` decimal(10,2) DEFAULT '0.00',
  `total_amount_paid` decimal(12,2) DEFAULT '0.00',
  `balance_due` decimal(12,2) DEFAULT '0.00',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `father_name` varchar(255) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `taluk` varchar(100) DEFAULT NULL,
  `hobli` varchar(100) DEFAULT NULL,
  `total_loan_balance` decimal(12,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `farmer_code` (`farmer_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `farmers`
--

LOCK TABLES `farmers` WRITE;
/*!40000 ALTER TABLE `farmers` DISABLE KEYS */;
INSERT INTO `farmers` VALUES (1,'FR001','Shivanna G','9876543210',NULL,'Halebeedu','Canara Bank','123456789012','CNRB0001234','shivanna@upi',NULL,2450.50,3675750.00,125000.00,'2025-12-10 18:49:08','siddalingappa','','','',125000.00),(2,'FR002','Lakshmamma','8765432109',NULL,'Arsikere','State Bank of India','987654321098','SBIN0012345','lakshmi.okaxis',NULL,1890.00,2835000.00,45000.00,'2025-12-10 18:49:08','kenchayya','','','',25100.00),(3,'FR003','Kumaraswamy','7654321098',NULL,'Tiptur','Karnataka Bank','456789123456','KARB0000456','kumar@phonepe',NULL,3200.75,4801125.00,89000.00,'2025-12-10 18:49:08','Chandrappa','','','',0.00),(4,'FR004','Manjula','8901234567',NULL,'Channarayapatna','Axis Bank','789456123000','UTIB0000789','manjula@upi',NULL,1560.25,2340375.00,0.00,'2025-12-10 18:49:08','Chandranna','','','',0.00),(5,'FR005','Rangappa','9012345678',NULL,'Hassan','HDFC Bank','321654987000','HDFC0003210','ranga@hdfc',NULL,2780.00,4170000.00,210000.00,'2025-12-10 18:49:08','Ramanna','','','',85300.00),(6,'FR006','Vinay D','9736552646','s/o dayananda, Nemmadi nilaya.Hu','Hullekere','HDFC Bank','87894566125','HDFC0003210','9738282546',NULL,0.00,0.00,0.00,'2025-12-10 18:51:11','Dayanand','Tumkur','Turuvekere','Dandinashivara',100000.00);
/*!40000 ALTER TABLE `farmers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_transactions`
--

DROP TABLE IF EXISTS `loan_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loan_transactions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `loan_id` bigint NOT NULL,
  `transaction_type` enum('LOAN_DISBURSEMENT','COPRA_PAYMENT','CASH_PAYMENT','INTEREST_CALCULATION','ADJUSTMENT') NOT NULL,
  `transaction_date` date NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `interest_amount` decimal(12,2) DEFAULT '0.00',
  `principal_amount` decimal(12,2) DEFAULT '0.00',
  `remaining_balance` decimal(12,2) NOT NULL,
  `purchase_id` bigint DEFAULT NULL,
  `payment_method` enum('CASH','BANK_TRANSFER','UPI','COPRA_DEDUCTION') DEFAULT 'CASH',
  `reference_no` varchar(100) DEFAULT NULL,
  `notes` text,
  `created_by` bigint DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_loan_transaction` (`loan_id`,`transaction_date`),
  CONSTRAINT `loan_transactions_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loan_transactions_ibfk_2` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE SET NULL,
  CONSTRAINT `loan_transactions_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_transactions`
--

LOCK TABLES `loan_transactions` WRITE;
/*!40000 ALTER TABLE `loan_transactions` DISABLE KEYS */;
INSERT INTO `loan_transactions` VALUES (1,1,'LOAN_DISBURSEMENT','2024-12-13',10000.00,0.00,10000.00,10000.00,NULL,'CASH',NULL,'Initial loan disbursement',NULL,'2025-12-13 15:57:56'),(2,1,'LOAN_DISBURSEMENT','2025-11-01',50000.00,0.00,50000.00,50000.00,NULL,'BANK_TRANSFER','DISB-001','Loan amount disbursed to farmer Shivanna',1,'2025-12-13 18:16:49'),(3,2,'LOAN_DISBURSEMENT','2025-10-15',30000.00,0.00,30000.00,30000.00,NULL,'CASH','DISB-002','Cash loan given to Lakshmamma',1,'2025-12-13 18:16:49'),(4,3,'LOAN_DISBURSEMENT','2025-09-10',100000.00,0.00,100000.00,100000.00,NULL,'BANK_TRANSFER','DISB-003','Land development loan to Rangappa',1,'2025-12-13 18:16:49'),(5,4,'LOAN_DISBURSEMENT','2025-08-20',25000.00,0.00,25000.00,25000.00,NULL,'UPI','DISB-004','Medical emergency loan',2,'2025-12-13 18:16:49'),(6,5,'LOAN_DISBURSEMENT','2025-12-01',75000.00,0.00,75000.00,75000.00,NULL,'BANK_TRANSFER','DISB-005','Harvesting labor loan',1,'2025-12-13 18:16:49'),(7,1,'COPRA_PAYMENT','2025-12-02',10000.00,200.00,9800.00,40200.00,1,'COPRA_DEDUCTION','COPRA-001','Deducted from purchase PUR20251201',2,'2025-12-13 18:16:49'),(8,2,'COPRA_PAYMENT','2025-11-28',5000.00,100.00,4900.00,25100.00,2,'COPRA_DEDUCTION','COPRA-002','Partial payment from purchase',2,'2025-12-13 18:16:49'),(9,3,'COPRA_PAYMENT','2025-12-03',15000.00,300.00,14700.00,85300.00,5,'COPRA_DEDUCTION','COPRA-003','Loan repayment from copra sale',2,'2025-12-13 18:16:49'),(10,4,'CASH_PAYMENT','2025-11-15',10000.00,200.00,9800.00,15200.00,NULL,'CASH','CASH-001','Partial cash repayment',2,'2025-12-13 18:16:49'),(11,4,'CASH_PAYMENT','2025-11-30',15200.00,304.00,14896.00,0.00,NULL,'UPI','CASH-002','Final repayment - loan closed',1,'2025-12-13 18:16:49'),(12,1,'INTEREST_CALCULATION','2025-12-01',1000.00,1000.00,0.00,51000.00,NULL,NULL,'INT-001','Monthly interest for Nov 2025',3,'2025-12-13 18:16:49'),(13,2,'INTEREST_CALCULATION','2025-11-15',600.00,600.00,0.00,30600.00,NULL,NULL,'INT-002','Monthly interest calculation',3,'2025-12-13 18:16:49'),(14,3,'INTEREST_CALCULATION','2025-12-10',2000.00,2000.00,0.00,102000.00,NULL,NULL,'INT-003','Quarterly interest calculation',3,'2025-12-13 18:16:49'),(15,7,'LOAN_DISBURSEMENT','2024-12-13',100000.00,0.00,100000.00,100000.00,NULL,'CASH',NULL,'Initial loan disbursement',NULL,'2025-12-13 19:17:21');
/*!40000 ALTER TABLE `loan_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loans`
--

DROP TABLE IF EXISTS `loans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loans` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `loan_number` varchar(30) NOT NULL,
  `farmer_id` bigint NOT NULL,
  `loan_amount` decimal(12,2) NOT NULL,
  `interest_rate` decimal(5,2) DEFAULT '2.00',
  `loan_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('ACTIVE','PAID','OVERDUE','DEFAULTED') DEFAULT 'ACTIVE',
  `remaining_amount` decimal(12,2) NOT NULL,
  `total_interest` decimal(12,2) DEFAULT '0.00',
  `purpose` varchar(255) DEFAULT NULL,
  `notes` text,
  `created_by` bigint DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `loan_number` (`loan_number`),
  KEY `created_by` (`created_by`),
  KEY `idx_farmer_status` (`farmer_id`,`status`),
  KEY `idx_loan_date` (`loan_date`),
  CONSTRAINT `loans_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loans_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loans`
--

LOCK TABLES `loans` WRITE;
/*!40000 ALTER TABLE `loans` DISABLE KEYS */;
INSERT INTO `loans` VALUES (1,'LN202500001',1,10000.00,2.00,'2024-12-13',NULL,'ACTIVE',10000.00,0.00,'family health issue','thanks',NULL,'2025-12-13 15:57:56','2025-12-13 15:57:56'),(2,'LN-001',1,50000.00,2.00,'2025-11-01','2026-05-01','ACTIVE',50000.00,0.00,'Agricultural Equipment Purchase','Tractor repair and new implements',1,'2025-12-13 18:16:49','2025-12-13 18:16:49'),(3,'LN-002',2,30000.00,2.00,'2025-10-15','2026-04-15','ACTIVE',30000.00,0.00,'Coconut Farm Maintenance','Fertilizers and pesticides',1,'2025-12-13 18:16:49','2025-12-13 18:16:49'),(4,'LN-003',5,100000.00,2.00,'2025-09-10','2026-03-10','ACTIVE',100000.00,0.00,'Land Development','Land leveling and irrigation setup',1,'2025-12-13 18:16:49','2025-12-13 18:16:49'),(5,'LN-004',3,25000.00,2.00,'2025-08-20','2026-02-20','PAID',0.00,500.00,'Medical Emergency','Hospital expenses fully repaid',2,'2025-12-13 18:16:49','2025-12-13 18:16:49'),(6,'LN-005',1,75000.00,2.00,'2025-12-01','2026-06-01','ACTIVE',75000.00,0.00,'Coconut Harvesting Labor','Hiring labor for harvest season',1,'2025-12-13 18:16:49','2025-12-13 18:16:49'),(7,'LN202500007',5,100000.00,2.00,'2024-12-13',NULL,'ACTIVE',100000.00,0.00,'family health issue','he will give after deepavali',NULL,'2025-12-13 19:17:21','2025-12-14 18:59:44');
/*!40000 ALTER TABLE `loans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `merchants`
--

DROP TABLE IF EXISTS `merchants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `merchants` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `merchant_code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `company_name` varchar(150) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `address` text,
  `total_purchased` decimal(10,2) DEFAULT '0.00',
  `total_paid` decimal(12,2) DEFAULT '0.00',
  `balance_due` decimal(12,2) DEFAULT '0.00',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `bank_name` varchar(100) DEFAULT NULL,
  `account_number` varchar(30) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `merchant_code` (`merchant_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merchants`
--

LOCK TABLES `merchants` WRITE;
/*!40000 ALTER TABLE `merchants` DISABLE KEYS */;
INSERT INTO `merchants` VALUES (1,'MR001','Rajesh Mehta','Mehta Traders','9123456789','Mandya',4850.00,7507500.00,180000.00,'2025-12-10 18:49:08','','',''),(2,'MR002','Ganesh Bhai','VP Traders','8234567890','Tiptur',6200.50,9610775.00,320000.00,'2025-12-10 18:49:08','HDFC Bank','878511212165','HDFC000328'),(3,'MR003','Anand Agencies','Anand Copra Suppliers','7345678901','Tiptur',3100.00,4960000.00,0.00,'2025-12-10 18:49:08','SBI','464678451','SB78548'),(4,'MR004','Vijay Traders','Vijay Dry Copra Mart','8456789012','Mysore',2900.25,4490387.50,125000.00,'2025-12-10 18:49:08','','',''),(5,'MR005','Shivaprasad ','Siri Coconut Oil Industries','9736552647','s/o sadanna, Hullekere,Turuvekere,Tumkur',0.00,0.00,0.00,'2025-12-10 19:01:44',NULL,NULL,NULL),(6,'MR006','Sadanna','SRS Traders','6866558899','Tiptur',0.00,0.00,0.00,'2025-12-12 17:37:08','Vijaya Bank','365896476','VIJA25463');
/*!40000 ALTER TABLE `merchants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `farmer_id` bigint NOT NULL,
  `purchase_id` bigint DEFAULT NULL,
  `payment_date` date NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_method` enum('CASH','BANK_TRANSFER','UPI') NOT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `notes` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `farmer_id` (`farmer_id`),
  KEY `purchase_id` (`purchase_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`id`),
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,1,1,'2025-12-02',50000.00,'BANK_TRANSFER','SBI123456789',NULL,'2025-12-10 18:49:08'),(2,2,2,'2025-11-28',30000.00,'UPI','UPI987654321',NULL,'2025-12-10 18:49:08'),(3,3,3,'2025-11-26',80000.00,'CASH',NULL,NULL,'2025-12-10 18:49:08'),(4,5,5,'2025-12-03',60000.00,'UPI','PHONEPE12345',NULL,'2025-12-10 18:49:08');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_items`
--

DROP TABLE IF EXISTS `purchase_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_type` varchar(20) NOT NULL COMMENT 'COPRA, CHURU_HOLU, COWTU',
  `number_of_bags` int DEFAULT NULL,
  `weight_per_bag` decimal(8,2) DEFAULT NULL,
  `extra_quantity` decimal(8,2) DEFAULT '0.00',
  `quality_deduction` decimal(8,2) DEFAULT '0.00',
  `net_weight` decimal(8,2) NOT NULL,
  `rate_per_kg` decimal(10,2) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `purchase_id` bigint NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_purchase_id` (`purchase_id`),
  KEY `idx_product_type` (`product_type`),
  CONSTRAINT `fk_purchase_items_purchase` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_items`
--

LOCK TABLES `purchase_items` WRITE;
/*!40000 ALTER TABLE `purchase_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchases` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `purchase_id` varchar(30) NOT NULL,
  `farmer_id` bigint NOT NULL,
  `purchase_date` date NOT NULL,
  `weight_kg` decimal(8,2) NOT NULL,
  `weight_quintal` decimal(8,2) GENERATED ALWAYS AS ((`weight_kg` / 100)) STORED,
  `rate_per_quintal` int NOT NULL DEFAULT '0',
  `total_amount` decimal(12,2) GENERATED ALWAYS AS ((`weight_quintal` * `rate_per_quintal`)) STORED,
  `advance_paid` decimal(10,2) DEFAULT '0.00',
  `payment_method` enum('CASH','BANK_TRANSFER','UPI') DEFAULT 'CASH',
  `tender_option` enum('SELL_TODAY','WAIT_NEXT_TENDER') DEFAULT 'WAIT_NEXT_TENDER',
  `notes` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `loan_deduction` decimal(12,2) DEFAULT '0.00',
  `commission` decimal(12,2) DEFAULT '0.00',
  `net_payment` decimal(12,2) DEFAULT '0.00',
  `loan_id` bigint DEFAULT NULL,
  `payment_reference` varchar(100) DEFAULT NULL,
  `amount_paid` decimal(12,2) DEFAULT '0.00',
  `balance_amount` decimal(12,2) DEFAULT '0.00',
  `loan_payment_type` varchar(20) DEFAULT NULL,
  `total_weight_kg` decimal(10,2) DEFAULT '0.00',
  `total_weight_quintal` decimal(10,2) DEFAULT '0.00',
  `commission_rate` decimal(5,2) DEFAULT '2.00',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `commission_amount` decimal(12,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchase_id` (`purchase_id`),
  KEY `farmer_id` (`farmer_id`),
  KEY `loan_id` (`loan_id`),
  CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `purchases_ibfk_2` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` (`id`, `purchase_id`, `farmer_id`, `purchase_date`, `weight_kg`, `rate_per_quintal`, `advance_paid`, `payment_method`, `tender_option`, `notes`, `created_at`, `loan_deduction`, `commission`, `net_payment`, `loan_id`, `payment_reference`, `amount_paid`, `balance_amount`, `loan_payment_type`, `total_weight_kg`, `total_weight_quintal`, `commission_rate`, `updated_at`, `commission_amount`) VALUES (1,'PUR20251201',1,'2025-12-01',450.50,15000,50000.00,'BANK_TRANSFER','WAIT_NEXT_TENDER',NULL,'2025-12-10 18:49:08',10000.00,0.00,57575.00,1,NULL,0.00,0.00,NULL,0.00,0.00,2.00,'2025-12-14 18:15:57',0.00),(2,'PUR20251128',2,'2025-11-28',320.00,14800,30000.00,'UPI','SELL_TODAY',NULL,'2025-12-10 18:49:08',5000.00,0.00,42360.00,2,NULL,0.00,0.00,NULL,0.00,0.00,2.00,'2025-12-14 18:15:57',0.00),(3,'PUR20251125',3,'2025-11-25',680.75,14950,80000.00,'CASH','WAIT_NEXT_TENDER',NULL,'2025-12-10 18:49:08',0.00,0.00,0.00,NULL,NULL,0.00,0.00,NULL,0.00,0.00,2.00,'2025-12-14 18:15:57',0.00),(4,'PUR20251120',4,'2025-11-20',290.25,15100,45000.00,'BANK_TRANSFER','WAIT_NEXT_TENDER',NULL,'2025-12-10 18:49:08',0.00,0.00,0.00,NULL,NULL,0.00,0.00,NULL,0.00,0.00,2.00,'2025-12-14 18:15:57',0.00),(5,'PUR20251202',5,'2025-12-02',510.00,15050,60000.00,'UPI','SELL_TODAY',NULL,'2025-12-10 18:49:08',15000.00,0.00,61755.00,3,NULL,0.00,0.00,NULL,0.00,0.00,2.00,'2025-12-14 18:15:57',0.00);
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sale_id` varchar(30) NOT NULL,
  `merchant_id` bigint NOT NULL,
  `sale_date` date NOT NULL,
  `weight_kg` decimal(8,2) NOT NULL,
  `rate_per_quintal` int NOT NULL,
  `total_amount` decimal(12,2) GENERATED ALWAYS AS (((`weight_kg` / 100) * `rate_per_quintal`)) STORED,
  `purchase_rate_avg` int NOT NULL,
  `profit` decimal(12,2) GENERATED ALWAYS AS ((`total_amount` - ((`weight_kg` / 100) * `purchase_rate_avg`))) STORED,
  `payment_method` enum('CASH','BANK_TRANSFER','UPI') DEFAULT 'BANK_TRANSFER',
  `notes` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sale_id` (`sale_id`),
  KEY `merchant_id` (`merchant_id`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` (`id`, `sale_id`, `merchant_id`, `sale_date`, `weight_kg`, `rate_per_quintal`, `purchase_rate_avg`, `payment_method`, `notes`, `created_at`) VALUES (1,'SAL20251202',1,'2025-12-02',850.00,15500,14920,'BANK_TRANSFER',NULL,'2025-12-10 18:49:08'),(2,'SAL20251129',2,'2025-11-29',1200.50,15400,14850,'BANK_TRANSFER',NULL,'2025-12-10 18:49:08'),(3,'SAL20251126',3,'2025-11-26',600.00,15600,15000,'CASH',NULL,'2025-12-10 18:49:08'),(4,'SAL20251201',4,'2025-12-01',490.25,15350,14980,'UPI',NULL,'2025-12-10 18:49:08');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tender_rates`
--

DROP TABLE IF EXISTS `tender_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tender_rates` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `market` enum('TIPTUR','ARSIKERE') NOT NULL,
  `rate_date` date NOT NULL,
  `rate_per_quintal` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_market_date` (`market`,`rate_date`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tender_rates`
--

LOCK TABLES `tender_rates` WRITE;
/*!40000 ALTER TABLE `tender_rates` DISABLE KEYS */;
INSERT INTO `tender_rates` VALUES (1,'TIPTUR','2025-12-01',15200,'2025-12-10 18:49:08'),(2,'TIPTUR','2025-11-27',14900,'2025-12-10 18:49:08'),(3,'TIPTUR','2025-11-24',15100,'2025-12-10 18:49:08'),(4,'ARSIKERE','2025-12-02',15050,'2025-12-10 18:49:08'),(5,'ARSIKERE','2025-11-28',14800,'2025-12-10 18:49:08'),(6,'ARSIKERE','2025-11-25',14950,'2025-12-10 18:49:08'),(7,'TIPTUR','2025-12-04',28400,'2025-12-10 19:02:52'),(8,'ARSIKERE','2025-12-05',28200,'2025-12-10 19:03:04'),(9,'TIPTUR','2025-12-08',28600,'2025-12-10 19:03:18'),(10,'ARSIKERE','2025-12-09',28500,'2025-12-13 22:43:15'),(11,'TIPTUR','2025-12-11',28080,'2025-12-13 22:43:29'),(12,'ARSIKERE','2025-12-12',27800,'2025-12-13 22:43:40');
/*!40000 ALTER TABLE `tender_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `role` enum('admin','manager','accountant','owner') DEFAULT 'manager',
  `avatar` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','password123','Vinay Kumar','admin',NULL,'2025-12-10 18:49:08'),(2,'manager1','manager123','Ramesh Gowda','manager',NULL,'2025-12-10 18:49:08'),(3,'accountant','acc123','Lakshmi Bai','accountant',NULL,'2025-12-10 18:49:08'),(4,'owner','owner123','Shivanna Gowda','owner',NULL,'2025-12-10 18:49:08');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ambika_traders'
--

--
-- Dumping routines for database 'ambika_traders'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-15 10:47:44
